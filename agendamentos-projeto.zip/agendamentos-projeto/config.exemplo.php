<?php
// Configuração do Portal de Agendamentos.
// Ajuste os dados do MySQL antes de abrir o install.php.
return [
    // Segundos entre as consultas da agenda ao vivo (3 a 300; padrão 8).
    // 'agenda_intervalo' => 8,

    'db' => [
        'host' => 'localhost',
        'port' => 3306,
        'nome' => 'agendamentos',   // nome do banco (o instalador cria se não existir)
        'usuario' => 'root',
        'senha' => '',
    ],
    // Importação de NF-e: CNPJ (só números) do destinatário → empresa. Opcional; sem isso o sistema tenta pelo nome.
    'cnpj_empresas' => [
        // '12345678000190' => 'GREEN MED',
        // '98765432000110' => 'ESTEVIA',
        // '11222333000144' => 'ESSENCIAL',
    ],
    'forcar_https' => true,         // redireciona http → https (ignorado em localhost)
    'timezone' => 'America/Sao_Paulo',
    'por_pagina' => 50,             // linhas por página na aba Registros
];
