<?php
require __DIR__ . '/inc/bootstrap.php';
require __DIR__ . '/inc/layout.php';
exigir_login();

$erro = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validar();
    $atual = (string)($_POST['atual'] ?? '');
    $nova = (string)($_POST['nova'] ?? '');
    $conf = (string)($_POST['confirmar'] ?? '');
    $hash = q('SELECT senha_hash FROM usuarios WHERE id = ?', [usuario()['id']])->fetchColumn();
    if (!password_verify($atual, (string)$hash)) $erro = 'A senha atual está incorreta.';
    elseif ($msg = senha_invalida($nova, usuario()['login'])) $erro = $msg;
    elseif ($nova === $atual) $erro = 'A nova senha precisa ser diferente da atual.';
    elseif ($nova !== $conf) $erro = 'A confirmação não bate com a nova senha.';
    else {
        q('UPDATE usuarios SET trocar_senha = 0, senha_hash = ? WHERE id = ?', [password_hash($nova, PASSWORD_DEFAULT), usuario()['id']]);
        flash('Senha alterada.');
        redirecionar('index.php');
    }
}
topo('Alterar senha');
?>
<form class="card formcard narrow" method="post">
  <?= csrf_campo() ?>
  <div class="cardhead"><h1>Alterar minha senha</h1></div>
  <?php if ($erro): ?><div class="flash erro"><?= e($erro) ?></div><?php endif; ?>
  <div class="form1">
    <div class="field"><label for="atual">Senha atual</label><input id="atual" name="atual" type="password" required autocomplete="current-password"></div>
    <div class="field"><label for="nova">Nova senha</label><input id="nova" name="nova" type="password" required minlength="6" autocomplete="new-password"><small class="muted">Pelo menos 6 caracteres, com 1 letra e 1 número.</small></div>
    <div class="field"><label for="confirmar">Confirmar nova senha</label><input id="confirmar" name="confirmar" type="password" required minlength="6" autocomplete="new-password"></div>
  </div>
  <div class="cardfoot"><span class="sp"></span><?php if (!(int)(usuario()['trocar_senha'] ?? 0)): ?><a class="btn" href="index.php">Cancelar</a><?php endif; ?><button class="btn primary" type="submit">Salvar senha</button></div>
</form>
<?php rodape();
