<?php
// Calendário: visão do mês (quantas notas por dia, dias cheios em destaque) e da semana (notas de cada dia,
// com arrastar para reagendar e a bandeja de notas sem data / atrasadas / que chegaram no ES).
require __DIR__ . '/inc/bootstrap.php';
require __DIR__ . '/inc/layout.php';
exigir_login();

$fp = agenda_fp($EMP); // antes das consultas: se algo mudar durante a montagem, a próxima consulta ao vivo corrige
$h = hoje();
$ver = ($_GET['ver'] ?? '') === 'semana' ? 'semana' : 'mes';
$d = (string)($_GET['d'] ?? '');
$ref = preg_match('/^\d{4}-\d{2}-\d{2}$/', $d) && checkdate((int)substr($d, 5, 2), (int)substr($d, 8, 2), (int)substr($d, 0, 4)) ? $d : $h;
$wEmp = $EMP !== '' ? ' AND empresa = :emp' : '';
$pEmp = $EMP !== '' ? [':emp' => $EMP] : [];
$podeMover = pode_editar();
$volta = 'calendario.php?' . http_build_query(['ver' => $ver, 'd' => $ref]);
$url = fn(string $v, string $dia) => 'calendario.php?' . http_build_query(['ver' => $v, 'd' => $dia]);
$sem = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
// A nota pode mudar de dia? (aguardando; nota do ES só depois de chegar lá)
$movel = fn(array $r) => $podeMover && $r['entregue'] === 'N' && !($r['uf'] === 'ES' && !$r['chegou_es_em']);

if ($ver === 'mes') {
    $ini = date('Y-m-01', strtotime($ref));
    $fim = date('Y-m-t', strtotime($ref));
    $gIni = soma_dias($ini, -(int)date('w', strtotime($ini)));        // domingo antes do dia 1
    $gFim = soma_dias($fim, 6 - (int)date('w', strtotime($fim)));     // sábado depois do último dia
    $dias = [];
    foreach (q("SELECT data_receber AS d, COUNT(*) AS n, SUM(entregue = 'N') AS pend, SUM(entregue <> 'N') AS feitas,
                COALESCE(SUM(volumes_num), 0) AS vol, SUM(divergencia IS NOT NULL) AS diverg
                FROM agendamentos WHERE data_receber BETWEEN :a AND :b$wEmp GROUP BY data_receber", [':a' => $gIni, ':b' => $gFim] + $pEmp)->fetchAll() as $x) {
        $dias[$x['d']] = $x;
    }
    $doMes = array_filter($dias, fn($x) => $x['d'] >= $ini && $x['d'] <= $fim);
    $maxN = max([1] + array_map(fn($x) => (int)$x['n'], $doMes));
    $totN = array_sum(array_column($doMes, 'n'));
    $totV = array_sum(array_column($doMes, 'vol'));
    $cheio = $doMes ? array_reduce($doMes, fn($a, $x) => !$a || (int)$x['n'] > (int)$a['n'] ? $x : $a) : null;
    $titulo = ucfirst(MESES[(int)date('n', strtotime($ref)) - 1]) . ' de ' . date('Y', strtotime($ref));
    $ant = date('Y-m-d', strtotime($ini . ' -1 month'));
    $prox = date('Y-m-d', strtotime($ini . ' +1 month'));
} else {
    $ini = soma_dias($ref, -(int)date('w', strtotime($ref)));
    $fim = soma_dias($ini, 6);
    $notas = q("SELECT id, fornecedor, transportadora, nota_fiscal, volumes, volumes_num, empresa, uf, entregue, divergencia, data_receber, chegou_es_em
                FROM agendamentos WHERE data_receber BETWEEN :a AND :b$wEmp
                ORDER BY data_receber, entregue <> 'N', transportadora IS NULL, transportadora, fornecedor", [':a' => $ini, ':b' => $fim] + $pEmp)->fetchAll();
    $porDia = [];
    foreach ($notas as $r) $porDia[$r['data_receber']][] = $r;
    // "25 a 31 de outubro" ou, virando o mês, "29 set a 5 out"
    $mesIni = (int)date('n', strtotime($ini)); $mesFim = (int)date('n', strtotime($fim));
    $titulo = $mesIni === $mesFim
        ? (int)date('j', strtotime($ini)) . ' a ' . (int)date('j', strtotime($fim)) . ' de ' . MESES[$mesFim - 1]
        : (int)date('j', strtotime($ini)) . ' ' . mb_substr(MESES[$mesIni - 1], 0, 3) . ' a ' . (int)date('j', strtotime($fim)) . ' ' . mb_substr(MESES[$mesFim - 1], 0, 3);
    $ant = soma_dias($ini, -7);
    $prox = soma_dias($ini, 7);
    // Bandeja: o que ainda não tem dia (ou já passou) para arrastar para um dia da semana.
    $bandeja = [];
    if ($podeMover) {
        $campos = 'id, fornecedor, transportadora, nota_fiscal, volumes, volumes_num, empresa, uf, entregue, divergencia, data_receber, chegou_es_em';
        $bandeja = [
            'es' => ['Chegaram no ES', q("SELECT $campos FROM agendamentos WHERE entregue = 'N' AND uf = 'ES' AND chegou_es_em IS NOT NULL AND data_receber IS NULL$wEmp ORDER BY chegou_es_em LIMIT 100", $pEmp)->fetchAll()],
            'semdata' => ['Sem data', q("SELECT $campos FROM agendamentos WHERE entregue = 'N' AND data_receber IS NULL AND uf <> 'ES'$wEmp ORDER BY fornecedor LIMIT 100", $pEmp)->fetchAll()],
            'atrasados' => ['Atrasadas', q("SELECT $campos FROM agendamentos WHERE entregue = 'N' AND data_receber < :h$wEmp ORDER BY data_receber DESC LIMIT 100", [':h' => $h] + $pEmp)->fetchAll()],
        ];
    }
}

/** Um cartão de nota na semana / bandeja. */
$cartao = function (array $r) use ($movel, $volta, $h): string {
    $pode = $movel($r);
    $emp = 'e-' . strtolower(str_replace(' ', '-', $r['empresa'] ?? ''));
    $cls = 'cal-nota ' . $emp . ($r['entregue'] !== 'N' ? ' feita' : '') . ($r['divergencia'] ? ' div' : '') . ($pode ? ' movel' : '');
    $sub = array_filter([$r['nota_fiscal'] ? 'NF ' . $r['nota_fiscal'] : '', $r['volumes'] ? $r['volumes'] . ' vol' : '', titulo($r['transportadora']), $r['uf'] === 'ES' ? 'ES' : '']);
    $estado = $r['entregue'] !== 'N' ? ($r['divergencia'] ? '<i class="cal-st div" title="Recebida com divergência">!</i>' : '<i class="cal-st ok" title="Recebida">✓</i>') : '';
    $h1 = '<div class="' . $cls . '" data-id="' . (int)$r['id'] . '" data-de="' . e((string)$r['data_receber']) . '"' . ($pode ? ' draggable="true"' : '') . '>'
        . '<a href="agendamento.php?id=' . (int)$r['id'] . '">' . $estado . e(titulo($r['fornecedor']) ?: 'Fornecedor não informado') . '</a>'
        . '<small>' . e(implode(' · ', $sub)) . '</small>';
    if ($pode) {
        $h1 .= '<details class="cal-mover"><summary>Mudar dia</summary><form method="post" action="acao.php">' . csrf_campo()
            . '<input type="hidden" name="acao" value="reagendar"><input type="hidden" name="id" value="' . (int)$r['id'] . '">'
            . '<input type="hidden" name="de" value="' . e((string)$r['data_receber']) . '"><input type="hidden" name="volta" value="' . e($volta) . '">'
            . '<input type="date" name="data_receber" min="' . $h . '" value="' . e($r['data_receber'] && $r['data_receber'] >= $h ? $r['data_receber'] : soma_dias($h, 1)) . '" required aria-label="Novo dia">'
            . '<button class="btn sm primary" type="submit">Mover</button></form></details>';
    }
    return $h1 . '</div>';
};

topo('Calendário', 'calendario', true);
?>
<section class="cal" id="cal" data-ver="<?= $ver ?>" data-fp="<?= e($fp) ?>" data-intervalo="<?= (int)($CONFIG['agenda_intervalo'] ?? 8) ?>">
  <div class="cal-topo">
    <div class="cal-nav">
      <a class="btn ghost cal-seta" href="<?= e($url($ver, $ant)) ?>" aria-label="<?= $ver === 'mes' ? 'Mês anterior' : 'Semana anterior' ?>"><?= icone('voltar', 16) ?></a>
      <h1><?= e($titulo) ?></h1>
      <a class="btn ghost cal-seta prox" href="<?= e($url($ver, $prox)) ?>" aria-label="<?= $ver === 'mes' ? 'Próximo mês' : 'Próxima semana' ?>"><?= icone('voltar', 16) ?></a>
      <a class="btn sm" href="<?= e($url($ver, $h)) ?>">Hoje</a>
    </div>
    <div class="seg" role="group" aria-label="Visão">
      <a href="<?= e($url('mes', $ref)) ?>" aria-pressed="<?= $ver === 'mes' ? 'true' : 'false' ?>">Mês</a>
      <a href="<?= e($url('semana', $ref)) ?>" aria-pressed="<?= $ver === 'semana' ? 'true' : 'false' ?>">Semana</a>
    </div>
  </div>

<?php if ($ver === 'mes'): ?>
  <p class="cal-resumo muted"><?= $totN ? plural($totN, 'nota', 'notas') . ' no mês' . ($totV ? ' · ' . n($totV) . ' volumes' : '') . ($cheio ? ' · dia mais cheio: ' . e(dia_curto($cheio['d'])) . ' (' . plural((int)$cheio['n'], 'nota', 'notas') . ')' : '') : 'Nenhuma nota neste mês.' ?></p>
  <div class="cal-mes" role="grid" aria-label="<?= e($titulo) ?>">
    <?php foreach ($sem as $s): ?><div class="cal-dsem" role="columnheader"><?= $s ?></div><?php endforeach; ?>
    <?php for ($dia = $gIni; $dia <= $gFim; $dia = soma_dias($dia, 1)):
        $x = $dias[$dia] ?? null;
        $n = $x ? (int)$x['n'] : 0;
        $nivel = $n ? min(4, (int)ceil(4 * $n / $maxN)) : 0;
        $passado = $dia < $h;
        $cls = 'cal-cel nivel-' . $nivel . ($dia < $ini || $dia > $fim ? ' fora' : '') . ($dia === $h ? ' hoje' : '') . ($passado ? ' passado' : '') . (in_array((int)date('w', strtotime($dia)), [0, 6], true) ? ' fds' : '');
        $rot = dia_longo($dia) . ($n ? ': ' . plural($n, 'nota', 'notas') : ': nenhuma nota'); ?>
      <a class="<?= $cls ?>" href="<?= e($passado && $x && !(int)$x['pend'] ? 'registros.php?' . http_build_query(['de' => $dia, 'ate' => $dia]) : 'index.php?dia=' . $dia) ?>" role="gridcell" aria-label="<?= e($rot) ?>">
        <span class="cal-num"><?= (int)date('j', strtotime($dia)) ?></span>
        <?php if ($n): ?>
          <b class="cal-n"><?= n($n) ?></b>
          <small class="cal-v"><?= $n === 1 ? 'nota' : 'notas' ?><?= (int)$x['vol'] ? ' · ' . n($x['vol']) . ' vol' : '' ?></small>
          <span class="cal-marcas">
            <?php if ((int)$x['feitas']): ?><i class="ok" title="Recebidas">✓ <?= n($x['feitas']) ?></i><?php endif; ?>
            <?php if ($passado && (int)$x['pend']): ?><i class="atr" title="Ficaram para trás">! <?= n($x['pend']) ?></i><?php endif; ?>
            <?php if ((int)$x['diverg']): ?><i class="div" title="Com divergência">⚠ <?= n($x['diverg']) ?></i><?php endif; ?>
          </span>
        <?php endif; ?>
      </a>
    <?php endfor; ?>
  </div>
  <p class="cal-legenda muted small"><span class="nivel-1"></span><span class="nivel-2"></span><span class="nivel-3"></span><span class="nivel-4"></span> menos → mais notas no dia · clique num dia para abrir a agenda</p>

<?php else: ?>
  <div class="cal-semana<?= $podeMover ? ' com-bandeja' : '' ?>">
    <?php if ($podeMover): ?>
    <aside class="cal-bandeja" aria-label="Notas para agendar">
      <p class="muted small">Arraste uma nota para um dia (ou use "Mudar dia").</p>
      <?php foreach ($bandeja as $k => [$rot, $lista]): if (!$lista) continue; ?>
        <details class="cal-grupo" <?= $k !== 'atrasados' ? 'open' : '' ?>>
          <summary><?= e($rot) ?> <span class="muted">(<?= count($lista) ?><?= count($lista) >= 100 ? '+' : '' ?>)</span></summary>
          <?php foreach ($lista as $r) echo $cartao($r); ?>
        </details>
      <?php endforeach; ?>
      <?php if (!array_filter(array_column($bandeja, 1))): ?><p class="muted small">Nenhuma nota sem data ou atrasada.</p><?php endif; ?>
    </aside>
    <?php endif; ?>
    <div class="cal-dias">
      <?php for ($i = 0; $i < 7; $i++):
          $dia = soma_dias($ini, $i);
          $lista = $porDia[$dia] ?? [];
          $pend = array_filter($lista, fn($r) => $r['entregue'] === 'N');
          $vol = array_sum(array_map(fn($r) => (int)$r['volumes_num'], $pend)); ?>
        <div class="cal-col<?= $dia === $h ? ' hoje' : '' ?><?= $dia < $h ? ' passado' : '' ?>" data-dia="<?= $dia ?>"<?= $podeMover && $dia >= $h ? ' data-alvo="1"' : '' ?>>
          <a class="cal-col-topo" href="index.php?dia=<?= $dia ?>">
            <span><?= $sem[$i] ?> <b><?= (int)date('j', strtotime($dia)) ?></b></span>
            <small><?= $pend ? plural(count($pend), 'nota', 'notas') . ($vol ? ' · ' . n($vol) . ' vol' : '') : ($lista ? 'tudo recebido' : '—') ?></small>
          </a>
          <div class="cal-lista">
            <?php foreach ($lista as $r) echo $cartao($r); ?>
          </div>
        </div>
      <?php endfor; ?>
    </div>
  </div>
<?php endif; ?>
</section>
<?php rodape();
