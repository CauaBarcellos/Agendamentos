<?php
require __DIR__ . '/inc/bootstrap.php';
require __DIR__ . '/inc/layout.php';
exigir_login();
site_fp(); // antes das consultas: a página aberta se atualiza sozinha quando isso muda

$busca = trim((string)($_GET['q'] ?? ''));
$p = [];
$w = $w2 = '1=1';
if ($busca !== '') {
    $w = '(fornecedor LIKE :q OR transportadora LIKE :q OR nota_fiscal LIKE :q OR material LIKE :q OR observacao LIKE :q)';
    $w2 = '(fornecedor LIKE :q OR transportadora LIKE :q OR nota_fiscal LIKE :q OR produto LIKE :q OR observacao LIKE :q)';
    $p[':q'] = "%$busca%";
}
// Planilha antiga (recebidas_es) + notas avisadas pela filial pelo portal e já recebidas no Rio.
$linhas = q("SELECT * FROM (
    SELECT NULL AS id, data_emissao, transportadora, fornecedor, material, nota_fiscal, volumes, data_recebido_rj, observacao FROM recebidas_es WHERE $w
    UNION ALL
    SELECT id, chegou_es_em, transportadora, fornecedor, produto, nota_fiscal, volumes, DATE(entregue_em), observacao FROM agendamentos
      WHERE uf = 'ES' AND chegou_es_em IS NOT NULL AND entregue = 'S' AND $w2
  ) t ORDER BY data_recebido_rj DESC, data_emissao DESC LIMIT 2000", $p)->fetchAll();

topo('Recebidas ES', 'recebidas');
?>
<div class="pagehead"><h1>Recebidas do ES</h1><p class="muted">Notas transferidas do Espírito Santo e já recebidas no RJ. Na primeira coluna: data de emissão (planilha antiga) ou dia em que chegou no ES (avisadas pelo portal).</p></div>
<form class="toolbar" method="get">
  <div class="search"><?= icone('busca') ?><input name="q" type="search" value="<?= e($busca) ?>" placeholder="Buscar nas notas recebidas do ES" autocomplete="off"></div>
  <button class="btn" type="submit">Buscar</button>
</form>
<div class="tablebox" id="rcb-tabela" data-vivo><table class="cards rec" style="min-width:760px">
  <thead><tr><th>Emissão / chegada ES</th><th>Fornecedor</th><th>Nota fiscal</th><th class="r">Volumes</th><th>Material</th><th>Recebido no RJ</th><th>Obs.</th></tr></thead>
  <tbody>
  <?php foreach ($linhas as $r): ?>
    <tr<?= $r['id'] ? ' class="click" data-href="agendamento.php?id=' . (int)$r['id'] . '"' : '' ?>>
      <td class="num"><?= br($r['data_emissao']) ?></td>
      <td><div class="two"><b><?= e(titulo($r['fornecedor'])) ?></b><small><?= e(titulo($r['transportadora'])) ?></small></div></td>
      <td class="mono"><?= e($r['nota_fiscal']) ?></td>
      <td class="num r"><?= e($r['volumes']) ?></td>
      <td><?= e(frase($r['material'])) ?></td>
      <td class="num"><span class="st s-entregue"><?= br($r['data_recebido_rj']) ?></span></td>
      <td class="obs"><?= e($r['observacao']) ?></td>
    </tr>
  <?php endforeach; ?>
  <?php if (!$linhas): ?><tr><td colspan="7"><div class="empty"><b>Nada encontrado</b></div></td></tr><?php endif; ?>
  </tbody>
</table></div>
<div class="foot" id="rcb-pe" data-vivo><span class="num"><?= plural(count($linhas), 'nota', 'notas') ?></span></div>
<?php rodape();
