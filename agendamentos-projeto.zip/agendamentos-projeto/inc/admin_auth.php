<?php
/**
 * Área administrativa (pasta /admin): login próprio, separado do portal.
 * Estar logado no portal, mesmo como administrador, NÃO dá acesso aqui.
 */
const ADM_OCIOSO = 1800; // 30 min sem atividade → pede senha de novo

function adm_usuario(): ?array { return $_SESSION['adm'] ?? null; }

function adm_exigir(): void
{
    $a = adm_usuario();
    if ($a && (time() - ($a['ts'] ?? 0)) < ADM_OCIOSO) {
        // Confere a cada página se continua ativo e administrador.
        $row = q('SELECT id, nome, login FROM usuarios WHERE id = ? AND ativo = 1 AND perfil = ?', [$a['id'], 'admin'])->fetch();
        // A atualização automática da página (X-Vivo) não conta como atividade: o bloqueio por inatividade continua valendo.
        if ($row) { $_SESSION['adm'] = ['id' => (int)$row['id'], 'nome' => $row['nome'], 'login' => $row['login'], 'ts' => empty($_SERVER['HTTP_X_VIVO']) ? time() : $a['ts']]; return; }
    }
    unset($_SESSION['adm']);
    redirecionar('login.php');
}

function adm_topo(string $titulo, string $ativo): void
{
    $a = adm_usuario();
    ?><!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title><?= e($titulo) ?> · Administração</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Geist:wght@400;500;600;700&family=Geist+Mono:wght@400;500&display=swap">
<link rel="icon" type="image/svg+xml" href="../favicon.svg?v=3">
<link rel="icon" href="../favicon.ico?v=3" sizes="any">
<link rel="icon" type="image/png" sizes="32x32" href="../assets/favicon-32.png?v=3">
<link rel="apple-touch-icon" href="../assets/apple-touch-icon.png?v=3">
<link rel="stylesheet" href="../assets/style.css?v=<?= v('assets/style.css') ?>">
</head>
<body data-versao="<?= site_versao() ?>" data-fp-site="<?= site_fp() ?>" data-estado="../estado.php">
<header class="top">
  <div class="wrap topin">
    <span class="brand"><span class="mark"><?= icone('caminhao', 17) ?></span><b>Administração</b></span>
    <nav class="tabs" aria-label="Seções">
      <a class="tab" href="index.php" <?= $ativo === 'usuarios' ? 'aria-current="page"' : '' ?>><span class="ti"><?= icone('pessoas', 23) ?></span>Usuários</a>
      <a class="tab" href="painel.php" <?= $ativo === 'painel' ? 'aria-current="page"' : '' ?>><span class="ti"><?= icone('grafico', 23) ?></span>Painel</a>
      <a class="tab" href="historico.php" <?= $ativo === 'historico' ? 'aria-current="page"' : '' ?>><span class="ti"><?= icone('relogio', 23) ?></span>Histórico</a>
      <a class="tab" href="planilha.php" <?= $ativo === 'planilha' ? 'aria-current="page"' : '' ?>><span class="ti"><?= icone('lista', 23) ?></span>Planilha</a>
      <a class="tab" href="backup.php" <?= $ativo === 'backup' ? 'aria-current="page"' : '' ?>><span class="ti"><?= icone('disco', 23) ?></span>Backup</a>
    </nav>
    <span class="sp"></span>
    <span class="today-lbl"><?= e($a['nome']) ?></span>
    <a class="btn" href="sair.php"><?= icone('sair', 15) ?> Sair</a>
  </div>
</header>
<main class="wrap">
<?php
    if ($f = pegar_flash()) echo '<div class="flash ' . e($f[1]) . '" role="status">' . e($f[0]) . '</div>';
}

function adm_rodape(): void
{
    ?>
</main>
<script src="../assets/app.js?v=<?= v('assets/app.js') ?>"></script>
</body>
</html>
<?php
}
