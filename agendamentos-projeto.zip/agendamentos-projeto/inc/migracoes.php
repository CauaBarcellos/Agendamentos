<?php
/**
 * Ajustes de banco aplicados sozinhos, para bancos já instalados.
 * Roda uma vez por sessão POR VERSÃO: ao criar um ajuste novo, aumente MIGRACOES_VERSAO.
 * (Antes a marca era só "já rodou", e quem estava logado durante uma atualização ficava sem os ajustes novos.)
 */
const MIGRACOES_VERSAO = 6;

function aplicar_migracoes(): void
{
    if (($_SESSION['migrado'] ?? 0) === MIGRACOES_VERSAO) return;
    try {
        if (!db()->query("SHOW TABLES LIKE 'agendamentos'")->fetch()) return; // banco ainda não instalado (install.php cuida)
        if (!db()->query("SHOW COLUMNS FROM usuarios LIKE 'trocar_senha'")->fetch()) {
            db()->exec('ALTER TABLE usuarios ADD COLUMN trocar_senha TINYINT(1) NOT NULL DEFAULT 0');
        }
        if (!db()->query("SHOW COLUMNS FROM agendamentos LIKE 'chave_nfe'")->fetch()) {
            db()->exec('ALTER TABLE agendamentos ADD COLUMN chave_nfe CHAR(44) NULL AFTER nota_fiscal, ADD KEY idx_chave (chave_nfe)');
        }
        if (!db()->query("SHOW COLUMNS FROM agendamentos LIKE 'chegou_es_em'")->fetch()) {
            db()->exec('ALTER TABLE agendamentos ADD COLUMN chegou_es_em DATE NULL AFTER entregue_em, ADD COLUMN chegou_es_por INT NULL AFTER chegou_es_em, ADD KEY idx_es (uf, chegou_es_em)');
        }
        $perfil = db()->query("SHOW COLUMNS FROM usuarios LIKE 'perfil'")->fetch();
        if ($perfil && !str_contains($perfil['Type'], 'filial_es')) {
            db()->exec("ALTER TABLE usuarios MODIFY perfil ENUM('admin','operador','leitor','filial_es') NOT NULL DEFAULT 'operador'");
        }
        if (!db()->query("SHOW COLUMNS FROM agendamentos LIKE 'vol_recebidos'")->fetch()) {
            db()->exec('ALTER TABLE agendamentos ADD COLUMN vol_recebidos INT NULL AFTER entregue_em, ADD COLUMN divergencia VARCHAR(60) NULL AFTER vol_recebidos, ADD COLUMN divergencia_obs TEXT NULL AFTER divergencia');
        }
        db()->exec("CREATE TABLE IF NOT EXISTS fotos (
            id INT AUTO_INCREMENT PRIMARY KEY,
            agendamento_id INT NOT NULL,
            arquivo VARCHAR(80) NOT NULL,
            tipo VARCHAR(20) NOT NULL DEFAULT 'image/jpeg',
            tamanho INT NOT NULL DEFAULT 0,
            criado_por INT NULL,
            criado_em DATETIME NOT NULL,
            KEY idx_ag (agendamento_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        db()->exec("CREATE TABLE IF NOT EXISTS ajustes (chave VARCHAR(50) PRIMARY KEY, valor TEXT NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        db()->exec("CREATE TABLE IF NOT EXISTS push_inscricoes (
            id INT AUTO_INCREMENT PRIMARY KEY,
            usuario_id INT NOT NULL,
            endpoint VARCHAR(700) NOT NULL,
            p256dh VARCHAR(120) NOT NULL,
            auth VARCHAR(60) NOT NULL,
            aparelho VARCHAR(120) NULL,
            criado_em DATETIME NOT NULL,
            ultimo_envio DATETIME NULL,
            falhas INT NOT NULL DEFAULT 0,
            UNIQUE KEY uq_endpoint (endpoint(255)),
            KEY idx_usuario (usuario_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $_SESSION['migrado'] = MIGRACOES_VERSAO;
    } catch (Throwable $e) {
        error_log('migracoes: ' . $e->getMessage());
        // Sem permissão para alterar o banco: explica o que fazer em vez de quebrar mais adiante com "coluna não encontrada".
        if (stripos($e->getMessage(), 'denied') !== false && PHP_SAPI !== 'cli') {
            http_response_code(500);
            header('Content-Type: text/html; charset=utf-8');
            exit('<p style="font-family:system-ui;padding:24px;max-width:680px">O portal foi atualizado e precisa ajustar o banco de dados, mas o usuário do banco não tem permissão para isso.<br><br>No cPanel, abra <b>Bancos de dados MySQL</b> → <b>Usuários atuais</b> / <b>Adicionar usuário ao banco</b>, e dê ao usuário do portal as permissões <b>ALTER</b>, <b>CREATE</b> e <b>INDEX</b> no banco. Depois recarregue esta página.</p>');
        }
    }
}
