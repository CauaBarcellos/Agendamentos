<?php
/** Gera um dump SQL completo do banco (estrutura + dados) escrevendo em $saida (recurso de arquivo/stream). */
function backup_sql($saida): int
{
    $pdo = db();
    $bytes = 0;
    $w = function (string $s) use ($saida, &$bytes) { fwrite($saida, $s); $bytes += strlen($s); };
    $w("-- Backup Agendamentos · " . date('Y-m-d H:i:s') . "\nSET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS=0;\n\n");
    $tabelas = $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
    foreach ($tabelas as $t) {
        $w("DROP TABLE IF EXISTS `$t`;\n");
        $w($pdo->query("SHOW CREATE TABLE `$t`")->fetch(PDO::FETCH_NUM)[1] . ";\n\n");
        $st = $pdo->query("SELECT * FROM `$t`", PDO::FETCH_NUM);
        $lote = [];
        while ($row = $st->fetch()) {
            $vals = array_map(fn($v) => $v === null ? 'NULL' : $pdo->quote((string)$v), $row);
            $lote[] = '(' . implode(',', $vals) . ')';
            if (count($lote) >= 200) { $w("INSERT INTO `$t` VALUES " . implode(",\n", $lote) . ";\n"); $lote = []; }
        }
        if ($lote) $w("INSERT INTO `$t` VALUES " . implode(",\n", $lote) . ";\n");
        $w("\n");
    }
    $w("SET FOREIGN_KEY_CHECKS=1;\n");
    return $bytes;
}
