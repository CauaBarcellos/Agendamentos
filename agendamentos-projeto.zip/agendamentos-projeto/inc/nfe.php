<?php
/**
 * Importação de notas: leitura de XML de NF-e, planilhas (CSV/colado do Excel) e ZIP de XMLs.
 * Tudo aqui só LÊ e normaliza; quem grava é importar.php, depois que a pessoa confere a prévia.
 */

const IMP_MAX_XML = 3 * 1024 * 1024;        // por arquivo XML
const IMP_MAX_ZIP_ENTRADAS = 300;           // arquivos dentro de um ZIP
const IMP_MAX_ZIP_TOTAL = 40 * 1024 * 1024; // soma descompactada (barreira contra zip-bomb)
const IMP_MAX_LINHAS = 500;                 // notas por importação

/** Limites das colunas do banco (evita erro de "dado grande demais" na gravação). */
function imp_cortar(?string $s, int $max): string { $s = trim((string)$s); return mb_strlen($s) > $max ? rtrim(mb_substr($s, 0, $max)) : $s; }

/** Sem acentos, maiúsculas, espaços únicos: para comparar nomes. */
function imp_norm(?string $s): string
{
    $s = trim((string)$s);
    if ($s === '') return '';
    $t = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $s);
    $s = $t !== false && $t !== '' ? $t : $s;
    return preg_replace('/\s+/', ' ', strtoupper(preg_replace('/[^A-Za-z0-9\s\.\-\/&]/', '', $s)));
}

/** Valor de um caminho "ide/nNF" dentro do nó, ignorando namespace. */
function nfe_val(SimpleXMLElement $n, string $caminho): ?string
{
    $xp = './*[local-name()="' . implode('"]/*[local-name()="', explode('/', $caminho)) . '"]';
    $r = $n->xpath($xp);
    if (!$r) return null;
    $v = trim((string)$r[0]);
    return $v === '' ? null : $v;
}

/** Soma de todos os valores de um caminho (ex.: vários <vol><qVol>). */
function nfe_soma(SimpleXMLElement $n, string $caminho): ?float
{
    $xp = './*[local-name()="' . implode('"]/*[local-name()="', explode('/', $caminho)) . '"]';
    $r = $n->xpath($xp);
    if (!$r) return null;
    $t = 0.0;
    foreach ($r as $x) $t += (float)str_replace(',', '.', (string)$x);
    return $t;
}

/**
 * Lê um XML e devolve uma lista de resultados, um por NF-e encontrada:
 *   ['ok' => true, 'dados' => [...]]  ou  ['ok' => false, 'erro' => '...']
 */
function nfe_ler_xml(string $xml, string $nome = ''): array
{
    $rot = $nome !== '' ? "$nome: " : '';
    if (strlen($xml) > IMP_MAX_XML) return [['ok' => false, 'erro' => $rot . 'arquivo grande demais (máx. 3 MB).']];
    $xml = preg_replace('/^\xEF\xBB\xBF/', '', $xml);
    if (!preg_match('/^\s*</', $xml)) return [['ok' => false, 'erro' => $rot . 'não parece um XML.']];
    // Barreira contra XXE / "billion laughs": NF-e legítima nunca tem DOCTYPE ou ENTITY.
    if (preg_match('/<!(DOCTYPE|ENTITY)/i', $xml)) return [['ok' => false, 'erro' => $rot . 'XML recusado (contém declarações DOCTYPE/ENTITY).']];

    $prev = libxml_use_internal_errors(true);
    $doc = simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NONET | LIBXML_NOCDATA);
    libxml_clear_errors();
    libxml_use_internal_errors($prev);
    if (!$doc) return [['ok' => false, 'erro' => $rot . 'XML inválido ou corrompido.']];

    $infs = $doc->xpath('//*[local-name()="infNFe"]');
    if (!$infs) {
        $raiz = $doc->getName();
        $msg = stripos($raiz, 'evento') !== false || stripos($raiz, 'cancel') !== false
            ? 'é um evento (cancelamento/carta de correção), não uma NF-e.'
            : 'não encontrei uma NF-e neste XML.';
        return [['ok' => false, 'erro' => $rot . $msg]];
    }

    $out = [];
    foreach ($infs as $inf) {
        $chave = preg_replace('/\D/', '', (string)($inf['Id'] ?? ''));
        $chave = strlen($chave) === 44 ? $chave : '';
        $nf = nfe_val($inf, 'ide/nNF');
        if ($nf === null) { $out[] = ['ok' => false, 'erro' => $rot . 'NF-e sem número.']; continue; }
        $emit = nfe_val($inf, 'emit/xNome');
        if ($emit === null) { $out[] = ['ok' => false, 'erro' => $rot . "NF $nf sem emitente."]; continue; }

        $vol = nfe_soma($inf, 'transp/vol/qVol');
        $emissao = nfe_val($inf, 'ide/dhEmi') ?? nfe_val($inf, 'ide/dEmi');
        $prods = [];
        foreach ($inf->xpath('./*[local-name()="det"]/*[local-name()="prod"]/*[local-name()="xProd"]') ?: [] as $p) $prods[] = trim((string)$p);

        $out[] = ['ok' => true, 'dados' => [
            'chave_nfe' => $chave,
            'nota_fiscal' => ltrim($nf, '0') !== '' ? ltrim($nf, '0') : $nf,
            'emitente' => $emit,
            'emitente_fantasia' => nfe_val($inf, 'emit/xFant'),
            'emitente_cnpj' => preg_replace('/\D/', '', (string)nfe_val($inf, 'emit/CNPJ')),
            'destinatario' => nfe_val($inf, 'dest/xNome'),
            'destinatario_cnpj' => preg_replace('/\D/', '', (string)nfe_val($inf, 'dest/CNPJ')),
            'uf_destino' => nfe_val($inf, 'dest/enderDest/UF'),
            'transportadora' => nfe_val($inf, 'transp/transporta/xNome'),
            'volumes' => $vol !== null && $vol > 0 ? (string)(int)round($vol) : null,
            'produtos' => $prods,
            'emissao' => $emissao ? substr($emissao, 0, 10) : null,
            'valor' => nfe_val($inf, 'total/ICMSTot/vNF'),
        ]];
    }
    return $out;
}

/** Empresa do grupo a partir do destinatário (CNPJ configurado ou nome). */
function imp_empresa(?string $destNome, ?string $destCnpj): string
{
    global $CONFIG;
    $mapa = $CONFIG['cnpj_empresas'] ?? [];
    $c = preg_replace('/\D/', '', (string)$destCnpj);
    if ($c !== '' && isset($mapa[$c]) && in_array($mapa[$c], EMPRESAS, true)) return $mapa[$c];
    $n = imp_norm($destNome);
    foreach (['GREEN MED' => 'GREEN MED', 'GREENMED' => 'GREEN MED', 'ESTEVIA' => 'ESTEVIA', 'ESSENCIAL' => 'ESSENCIAL'] as $achar => $emp) {
        if ($n !== '' && str_contains($n, $achar)) return $emp;
    }
    return '';
}

/** Categoria de produto (texto das notas) a partir das descrições dos itens. */
function imp_produto(array $prods): string
{
    $mapa = ['Medicamento' => 'MEDICAMENTO', 'Material' => 'MATERIAL', 'Fralda' => 'FRALDA', 'Soro' => 'SORO', 'Luva' => 'LUVA', 'Saneante' => 'SANEANTES'];
    $cont = [];
    foreach ($prods as $p) {
        $c = categoria_de($p);
        if (isset($mapa[$c])) $cont[$c] = ($cont[$c] ?? 0) + 1;
    }
    if (!$cont) return 'DIVERSOS';
    arsort($cont);
    return $mapa[array_key_first($cont)];
}

/** Reaproveita o nome já cadastrado quando o emitente começa com ele ("TEUTO BRASILEIRO S/A" → "TEUTO"). */
function imp_nome_conhecido(?string $nome, ?string $fantasia, array $conhecidos): string
{
    $nome = maiusc($nome);
    $fant = maiusc($fantasia);
    if ($nome === '') return $fant;
    $idx = [];
    foreach ($conhecidos as $c) { $n = imp_norm($c); if ($n !== '') $idx[$n] = $c; }
    foreach ([$nome, $fant] as $cand) {
        if ($cand !== '' && isset($idx[imp_norm($cand)])) return $idx[imp_norm($cand)];
    }
    $nn = imp_norm($nome);
    $melhor = '';
    foreach ($idx as $n => $orig) {
        if (strlen($n) >= 4 && (str_starts_with($nn, $n . ' ') || str_starts_with($nn, $n . '-')) && strlen($n) > strlen($melhor)) $melhor = $n;
    }
    return $melhor !== '' ? $idx[$melhor] : $nome;
}

/** Linha padronizada da prévia a partir de uma NF-e lida. */
function imp_linha_de_nfe(array $d, array $padrao, array $forn, array $transp): array
{
    $emp = imp_empresa($d['destinatario'], $d['destinatario_cnpj']);
    $aviso = [];
    if ($emp === '') { $emp = $padrao['empresa']; $aviso[] = 'Não identifiquei a empresa destinatária' . ($d['destinatario'] ? ' (' . $d['destinatario'] . ')' : '') . '; confira.'; }
    if (!$d['transportadora']) $aviso[] = 'NF sem transportadora informada.';
    $tr = imp_nome_conhecido($d['transportadora'], null, $transp);
    return [
        'fornecedor' => imp_cortar(imp_nome_conhecido($d['emitente'], $d['emitente_fantasia'], $forn), 150),
        'transportadora' => imp_cortar($tr, 120),
        'nota_fiscal' => imp_cortar($d['nota_fiscal'], 60),
        'volumes' => substr(preg_replace('/\D/', '', (string)($d['volumes'] ?? '')), 0, 8),
        'produto' => imp_produto($d['produtos']),
        'empresa' => $emp,
        'uf' => strtoupper((string)$d['uf_destino']) === 'ES' ? 'ES' : $padrao['uf'],
        'data_receber' => $padrao['data_receber'],
        'chave_nfe' => $d['chave_nfe'],
        'origem' => 'xml',
        'info' => trim(($d['emissao'] ? 'Emitida em ' . br($d['emissao']) : '') . ($d['valor'] ? ' · R$ ' . number_format((float)$d['valor'], 2, ',', '.') : '')),
        'aviso' => $aviso,
    ];
}

/** Aliases de cabeçalho de planilha → campo interno. */
const IMP_COLUNAS = [
    'fornecedor' => ['fornecedor', 'emitente', 'fabricante', 'remetente'],
    'transportadora' => ['transportadora', 'transp', 'transportador'],
    'nota_fiscal' => ['nf', 'nota', 'nota fiscal', 'notafiscal', 'n.f.', 'numero nf', 'nº nf', 'no nf', 'numero da nota'],
    'volumes' => ['volumes', 'volume', 'vol', 'qtd volumes', 'qtde volumes'],
    'produto' => ['produto', 'material', 'categoria', 'tipo'],
    'empresa' => ['empresa', 'destino', 'destinatario', 'filial'],
    'uf' => ['uf', 'estado'],
    'data_receber' => ['data', 'data receber', 'data p/ receber', 'data para receber', 'receber', 'receber em', 'previsao', 'previsão', 'data receber'],
    'recebido' => ['recebido', 'recebida', 'recebido em', 'recebida em', 'entregue', 'entregue em', 'status', 'situacao', 'situação', 'chegou', 'data recebimento', 'data de recebimento', 'recebimento', 'baixa'],
];

/**
 * Coluna "Recebido" da planilha → ['data' => Y-m-d ou null] quando diz que já chegou; null quando não chegou ou está vazia.
 * Aceita uma data (dia em que chegou) ou palavras como "sim", "x", "ok", "recebido", "entregue".
 * $aviso recebe o motivo quando o valor não é entendido.
 */
function imp_recebido(?string $v, ?string &$aviso = null): ?array
{
    $aviso = null;
    $t = trim((string)$v);
    if ($t === '') return null;
    $n = strtolower(imp_norm($t));
    if (in_array($n, ['sim', 's', 'x', 'ok', 'recebido', 'recebida', 'entregue', 'entregues', 'chegou', 'concluido', 'concluida', 'baixado', 'baixada', 'yes', 'y', '1', 'true', '✓', '✔'], true)) return ['data' => null];
    if (in_array($n, ['nao', 'n', 'nao recebido', 'nao recebida', 'pendente', 'aguardando', 'a caminho', 'em transito', 'atrasado', 'atrasada', 'agendado', 'agendada', 'no', '0', 'false', '-'], true)) return null;
    $d = imp_data($t);
    if ($d !== null) {
        if ($d > hoje()) { $aviso = "Recebido em \"$t\" está no futuro; ignorei."; return null; }
        return ['data' => $d];
    }
    $aviso = "Valor \"$t\" na coluna Recebido não foi entendido; ignorei.";
    return null;
}

/** Converte "22/10/2026", "22/10/26", "2026-10-22" ou "22-10" em Y-m-d (ou null). */
function imp_data(?string $s): ?string
{
    $s = trim((string)$s);
    if ($s === '') return null;
    if (preg_match('/^(\d{4})-(\d{2})-(\d{2})/', $s, $m) && checkdate((int)$m[2], (int)$m[3], (int)$m[1])) return "$m[1]-$m[2]-$m[3]";
    if (preg_match('/^(\d{1,2})[\/\.\-](\d{1,2})(?:[\/\.\-](\d{2,4}))?$/', $s, $m)) {
        $a = $m[3] ?? date('Y');
        $a = strlen($a) === 2 ? '20' . $a : $a;
        if (checkdate((int)$m[2], (int)$m[1], (int)$a)) return sprintf('%04d-%02d-%02d', $a, $m[2], $m[1]);
    }
    return null;
}

/** Número de série de data do Excel (ex.: 46318) → Y-m-d. */
function imp_data_excel(float $serial): ?string
{
    if ($serial < 20000 || $serial > 80000) return null;
    return date('Y-m-d', (int)(($serial - 25569) * 86400));
}

/** Lê a primeira planilha de um .xlsx e devolve o conteúdo como texto separado por tabulação (reaproveita a leitura de tabelas). */
function imp_xlsx_para_texto(string $caminho): array
{
    $z = new ZipArchive();
    if ($z->open($caminho) !== true) return [null, 'arquivo .xlsx inválido.'];
    $ler = function (string $nome, int $max) use ($z) {
        $fp = $z->getStream($nome);
        if (!$fp) return null;
        $d = stream_get_contents($fp, $max + 1); // limite real, não confia no tamanho declarado
        fclose($fp);
        return strlen($d) > $max ? false : $d;
    };
    $planilhas = [];
    for ($i = 0; $i < min($z->numFiles, 400); $i++) {
        $n = (string)$z->getNameIndex($i);
        if (preg_match('#^xl/worksheets/sheet\d+\.xml$#', $n)) $planilhas[] = $n;
    }
    if (!$planilhas) { $z->close(); return [null, 'não encontrei nenhuma planilha dentro do .xlsx.']; }
    sort($planilhas, SORT_NATURAL);

    $carregar = function (?string $xml) {
        if (!$xml || preg_match('/<!(DOCTYPE|ENTITY)/i', $xml)) return null;
        $prev = libxml_use_internal_errors(true);
        $d = simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NONET);
        libxml_clear_errors(); libxml_use_internal_errors($prev);
        return $d ?: null;
    };
    $textos = [];
    $ss = $ler('xl/sharedStrings.xml', 10 * 1024 * 1024);
    if ($ss === false) { $z->close(); return [null, 'planilha grande demais.']; }
    if ($ss && ($sx = $carregar($ss))) {
        foreach ($sx->xpath('//*[local-name()="si"]') ?: [] as $si) {
            $t = '';
            foreach ($si->xpath('.//*[local-name()="t"]') ?: [] as $x) $t .= (string)$x;
            $textos[] = $t;
        }
    }
    $xml = $ler($planilhas[0], 20 * 1024 * 1024);
    $z->close();
    if ($xml === false) return [null, 'planilha grande demais.'];
    $sx = $carregar($xml);
    if (!$sx) return [null, 'não consegui ler a planilha (XML inválido).'];

    $linhas = [];
    foreach ($sx->xpath('//*[local-name()="sheetData"]/*[local-name()="row"]') ?: [] as $row) {
        $cel = [];
        foreach ($row->xpath('./*[local-name()="c"]') ?: [] as $c) {
            $ref = (string)$c['r'];
            if (!preg_match('/^([A-Z]+)/', $ref, $m)) continue;
            $col = 0;
            foreach (str_split($m[1]) as $ch) $col = $col * 26 + (ord($ch) - 64);
            $tipo = (string)$c['t'];
            $v = $c->xpath('./*[local-name()="v"]');
            $v = $v ? (string)$v[0] : '';
            if ($tipo === 's') $v = $textos[(int)$v] ?? '';
            elseif ($tipo === 'inlineStr') { $is = $c->xpath('.//*[local-name()="t"]'); $v = $is ? (string)$is[0] : ''; }
            elseif ($tipo === '' || $tipo === 'n') {
                // número: datas do Excel viram data; inteiros grandes não ganham ".0"
                if (is_numeric($v) && ($d = imp_data_excel((float)$v)) !== null && (float)$v == floor((float)$v)) $v = date('d/m/Y', strtotime($d));
                elseif (is_numeric($v) && (float)$v == floor((float)$v) && abs((float)$v) < 1e15) $v = (string)(int)$v;
            }
            $cel[$col] = str_replace(["\t", "\r", "\n"], ' ', $v);
        }
        if (!$cel) continue;
        $max = max(array_keys($cel));
        $l = [];
        for ($k = 1; $k <= $max; $k++) $l[] = $cel[$k] ?? '';
        $linhas[] = implode("\t", $l);
        if (count($linhas) > IMP_MAX_LINHAS + 5) break;
    }
    return [implode("\n", $linhas), null];
}

/** Texto colado do Excel/CSV → linhas brutas (primeira linha com os nomes das colunas). */
function imp_ler_tabela(string $texto): array
{
    $texto = preg_replace('/^\xEF\xBB\xBF/', '', $texto);
    if (!mb_check_encoding($texto, 'UTF-8')) $texto = mb_convert_encoding($texto, 'UTF-8', 'Windows-1252');
    $linhas = preg_split('/\r\n|\r|\n/', trim($texto));
    $linhas = array_values(array_filter($linhas, fn($l) => trim($l) !== ''));
    if (count($linhas) < 2) return [];
    // Delimitador: o que mais aparece no cabeçalho.
    $melhor = ';'; $mx = -1;
    foreach (["\t", ';', ','] as $d) { $n = substr_count($linhas[0], $d); if ($n > $mx) { $mx = $n; $melhor = $d; } }
    $cab = array_map(fn($c) => imp_norm_cab($c), str_getcsv($linhas[0], $melhor, '"', ''));
    $campos = [];
    foreach ($cab as $i => $c) {
        foreach (IMP_COLUNAS as $campo => $aliases) {
            if (in_array($c, array_map('imp_norm_cab', $aliases), true) && !in_array($campo, $campos, true)) { $campos[$i] = $campo; break; }
        }
    }
    if (!in_array('fornecedor', $campos, true)) return [];
    $out = [];
    foreach (array_slice($linhas, 1) as $l) {
        $cel = str_getcsv($l, $melhor, '"', '');
        $r = [];
        foreach ($campos as $i => $campo) $r[$campo] = trim((string)($cel[$i] ?? ''));
        if (implode('', $r) !== '') $out[] = $r;
        if (count($out) >= IMP_MAX_LINHAS + 1) break;
    }
    return $out;
}

function imp_norm_cab(string $s): string { return strtolower(preg_replace('/\s+/', ' ', trim(str_replace(['_', '.'], [' ', ''], imp_norm($s))))); }

/** Linha bruta de planilha → linha padronizada da prévia. */
function imp_linha_de_tabela(array $r, array $padrao): array
{
    $aviso = [];
    $emp = '';
    $e = imp_norm($r['empresa'] ?? '');
    foreach (EMPRESAS as $x) if ($e !== '' && (str_contains($e, imp_norm($x)) || str_contains(str_replace(' ', '', $e), str_replace(' ', '', imp_norm($x))))) $emp = $x;
    if ($emp === '') { $emp = $padrao['empresa']; if (($r['empresa'] ?? '') !== '') $aviso[] = 'Empresa "' . $r['empresa'] . '" não reconhecida; usei a padrão.'; }
    $data = imp_data($r['data_receber'] ?? '');
    if (($r['data_receber'] ?? '') !== '' && $data === null) $aviso[] = 'Data "' . $r['data_receber'] . '" inválida; usei a padrão.';
    $vol = substr(preg_replace('/[^\d]/', '', (string)($r['volumes'] ?? '')), 0, 8);
    $uf = strtoupper(trim((string)($r['uf'] ?? '')));
    $rec = imp_recebido($r['recebido'] ?? '', $avisoRec);
    if ($avisoRec) $aviso[] = $avisoRec;
    return [
        'fornecedor' => imp_cortar(maiusc($r['fornecedor'] ?? ''), 150),
        'transportadora' => imp_cortar(maiusc($r['transportadora'] ?? ''), 120),
        'nota_fiscal' => imp_cortar($r['nota_fiscal'] ?? '', 60),
        'volumes' => $vol,
        'produto' => imp_cortar(maiusc($r['produto'] ?? ''), 120) ?: 'DIVERSOS',
        'empresa' => $emp,
        'uf' => in_array($uf, ['RJ', 'ES'], true) ? $uf : $padrao['uf'],
        'data_receber' => $data ?? $padrao['data_receber'],
        'chave_nfe' => '',
        'origem' => 'csv',
        'info' => '',
        'aviso' => $aviso,
        'recebido' => $rec, // null = não chegou; ['data' => ...] = a planilha diz que já chegou
    ];
}

/** Nota já existente (por chave da NF-e ou por fornecedor + número). Devolve [id, data_receber] ou null. */
function imp_duplicada(string $chave, string $fornecedor, string $nf): ?array
{
    if ($chave !== '') {
        $r = q('SELECT id, data_receber, entregue, entregue_em, uf, divergencia FROM agendamentos WHERE chave_nfe = ? LIMIT 1', [$chave])->fetch();
        if ($r) return $r;
    }
    if ($fornecedor !== '' && $nf !== '') {
        $r = q('SELECT id, data_receber, entregue, entregue_em, uf, divergencia FROM agendamentos WHERE fornecedor = ? AND nota_fiscal = ? LIMIT 1', [$fornecedor, $nf])->fetch();
        if ($r) return $r;
    }
    return null;
}

/**
 * Lê tudo que a pessoa enviou (XMLs, ZIPs, CSV, texto colado) e devolve [linhas, problemas].
 * $arquivos é o formato de $_FILES['arquivos'] já normalizado para lista de [name, tmp_name, error, size].
 */
function imp_coletar(array $arquivos, string $texto, array $padrao): array
{
    $forn = q("SELECT DISTINCT fornecedor FROM agendamentos WHERE fornecedor <> ''")->fetchAll(PDO::FETCH_COLUMN);
    $transp = q("SELECT DISTINCT transportadora FROM agendamentos WHERE transportadora <> ''")->fetchAll(PDO::FETCH_COLUMN);
    $linhas = []; $probs = [];

    $doXml = function (string $xml, string $nome) use (&$linhas, &$probs, $padrao, $forn, $transp) {
        foreach (nfe_ler_xml($xml, $nome) as $r) {
            if ($r['ok']) $linhas[] = imp_linha_de_nfe($r['dados'], $padrao, $forn, $transp);
            else $probs[] = $r['erro'];
        }
    };
    $doTabela = function (string $txt, string $nome) use (&$linhas, &$probs, $padrao) {
        $t = imp_ler_tabela($txt);
        if (!$t) { $probs[] = "$nome: não achei uma tabela com a coluna \"Fornecedor\" (use a primeira linha como cabeçalho)."; return; }
        foreach ($t as $r) $linhas[] = imp_linha_de_tabela($r, $padrao);
    };

    foreach ($arquivos as $f) {
        $nome = (string)$f['name'];
        if ($f['error'] === UPLOAD_ERR_NO_FILE) continue;
        if ($f['error'] !== UPLOAD_ERR_OK) { $probs[] = "$nome: falha no envio (código {$f['error']})."; continue; }
        $ext = strtolower(pathinfo($nome, PATHINFO_EXTENSION));
        if ($ext === 'zip') {
            $z = new ZipArchive();
            if ($z->open($f['tmp_name']) !== true) { $probs[] = "$nome: ZIP inválido."; continue; }
            if ($z->numFiles > IMP_MAX_ZIP_ENTRADAS) { $probs[] = "$nome: ZIP com arquivos demais (máx. " . IMP_MAX_ZIP_ENTRADAS . ')'; $z->close(); continue; }
            $total = 0; $tem = false;
            for ($i = 0; $i < $z->numFiles; $i++) {
                $st = $z->statIndex($i);
                $en = (string)$st['name'];
                if (str_ends_with($en, '/') || str_contains($en, '__MACOSX') || !preg_match('/\.xml$/i', $en)) continue;
                $total += (int)$st['size'];
                if ($total > IMP_MAX_ZIP_TOTAL || (int)$st['size'] > IMP_MAX_XML) { $probs[] = "$nome: conteúdo grande demais; envie em partes."; break; }
                $fp = $z->getStream($en);
                if (!$fp) continue;
                $xml = stream_get_contents($fp, IMP_MAX_XML + 1); // limite real, mesmo que o ZIP minta sobre o tamanho
                fclose($fp);
                if ($xml === false) continue;
                if (strlen($xml) > IMP_MAX_XML) { $probs[] = basename($en) . ': arquivo grande demais (máx. 3 MB).'; continue; }
                $tem = true; $doXml($xml, basename($en));
            }
            if (!$tem && !$probs) $probs[] = "$nome: nenhum XML dentro do ZIP.";
            $z->close();
        } elseif ($ext === 'xml') {
            $doXml((string)file_get_contents($f['tmp_name']), $nome);
        } elseif ($ext === 'xlsx') {
            if ($f['size'] > 8 * 1024 * 1024) { $probs[] = "$nome: arquivo grande demais (máx. 8 MB)."; continue; }
            [$txt, $err] = imp_xlsx_para_texto($f['tmp_name']);
            if ($err) { $probs[] = "$nome: $err"; continue; }
            $doTabela($txt, $nome);
        } elseif (in_array($ext, ['csv', 'txt', 'tsv'], true)) {
            if ($f['size'] > 5 * 1024 * 1024) { $probs[] = "$nome: arquivo grande demais."; continue; }
            $doTabela((string)file_get_contents($f['tmp_name']), $nome);
        } else {
            $probs[] = "$nome: tipo não aceito (use .xml, .zip, .xlsx ou .csv).";
        }
    }
    if (trim($texto) !== '') $doTabela($texto, 'Texto colado');

    // Remove repetições dentro do próprio envio (mesma chave ou mesmo fornecedor+NF).
    $vistos = []; $unicas = [];
    foreach ($linhas as $l) {
        $k = $l['chave_nfe'] !== '' ? 'c' . $l['chave_nfe'] : 'f' . imp_norm($l['fornecedor']) . '|' . $l['nota_fiscal'];
        if ($l['nota_fiscal'] !== '' && isset($vistos[$k])) { $probs[] = 'NF ' . $l['nota_fiscal'] . ' (' . $l['fornecedor'] . ') aparece repetida no envio; mantive só uma.'; continue; }
        $vistos[$k] = true;
        $unicas[] = $l;
    }
    if (count($unicas) > IMP_MAX_LINHAS) { $probs[] = 'Mais de ' . IMP_MAX_LINHAS . ' notas: importei só as primeiras ' . IMP_MAX_LINHAS . '. Envie o restante depois.'; $unicas = array_slice($unicas, 0, IMP_MAX_LINHAS); }
    return [$unicas, $probs];
}

/** $_FILES['arquivos'] (formato embaralhado do PHP) → lista simples. */
function imp_lista_arquivos(?array $f): array
{
    if (!$f || !isset($f['name'])) return [];
    if (!is_array($f['name'])) return [$f];
    $out = [];
    foreach ($f['name'] as $i => $n) $out[] = ['name' => $n, 'tmp_name' => $f['tmp_name'][$i], 'error' => $f['error'][$i], 'size' => $f['size'][$i]];
    return $out;
}
