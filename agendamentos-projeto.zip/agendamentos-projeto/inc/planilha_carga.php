<?php
/**
 * Troca as notas que vieram da planilha pelas de uma planilha nova (dados/planilha.json, mesmo formato da instalação).
 *  - Apaga as notas com origem "planilha" (e o histórico e as fotos delas) e carrega as da planilha nova.
 *  - Mantém as notas criadas pelo site (portal, filial ES, XML, importação). Linha da planilha que repete uma
 *    dessas notas (mesmo fornecedor + NF) é pulada, para não duplicar.
 *  - Troca também a lista de "Recebidas ES".
 * planilha_analisar() só conta; planilha_substituir() faz tudo numa transação (ou tudo, ou nada).
 */

/** Chave para achar a mesma nota: fornecedor sem espaço/acento/pontuação + NF sem zeros à esquerda. */
function planilha_chave(?string $fornecedor, ?string $nf): string
{
    $n = fn($t) => preg_replace('/[^A-Z0-9]/', '', strtoupper((string)@iconv('UTF-8', 'ASCII//TRANSLIT', (string)$t)));
    $nfs = array_filter(array_map(fn($p) => ltrim($p, '0'), preg_split('/\D+/', (string)$nf)), fn($p) => $p !== '');
    return $n($fornecedor) . '|' . implode('/', $nfs);
}

/** Lê e confere o arquivo. Devolve [dados, erro]. */
function planilha_ler(string $arquivo): array
{
    if (!is_file($arquivo)) return [null, 'Arquivo da planilha não encontrado.'];
    $d = json_decode((string)file_get_contents($arquivo), true);
    if (!is_array($d) || !isset($d['agendamentos'], $d['recebidas']) || !is_array($d['agendamentos']) || !is_array($d['recebidas'])) return [null, 'O arquivo não está no formato da planilha (agendamentos e recebidas).'];
    foreach (array_slice($d['agendamentos'], 0, 50) as $a) if (!is_array($a) || count($a) !== 18) return [null, 'O arquivo não está no formato esperado (cada nota deve ter 18 campos).'];
    foreach (array_slice($d['recebidas'], 0, 50) as $r) if (!is_array($r) || count($r) !== 10) return [null, 'O arquivo não está no formato esperado (cada recebida deve ter 10 campos).'];
    if (count($d['agendamentos']) < 100) return [null, 'A planilha tem só ' . count($d['agendamentos']) . ' notas: parece incompleta. Confira o arquivo.'];
    return [$d, null];
}

/** Notas do site (não vieram da planilha), por chave. */
function planilha_do_site(): array
{
    $m = [];
    foreach (q("SELECT id, fornecedor, nota_fiscal FROM agendamentos WHERE origem <> 'planilha'")->fetchAll() as $r) {
        if (trim((string)$r['nota_fiscal']) !== '') $m[planilha_chave($r['fornecedor'], $r['nota_fiscal'])] = (int)$r['id'];
    }
    return $m;
}

/** O que vai acontecer, sem mudar nada. */
function planilha_analisar(array $dados): array
{
    $site = planilha_do_site();
    $pular = 0; $exemplosPulo = [];
    $novas = ['N' => 0, 'S' => 0, 'D' => 0];
    foreach ($dados['agendamentos'] as $a) {
        if (trim((string)$a[9]) !== '' && isset($site[planilha_chave($a[5], $a[9])])) { $pular++; if (count($exemplosPulo) < 5) $exemplosPulo[] = $a[5] . ' · NF ' . $a[9]; continue; }
        $novas[$a[14] ?: 'N'] = ($novas[$a[14] ?: 'N'] ?? 0) + 1;
    }
    $antigas = (int)q("SELECT COUNT(*) FROM agendamentos WHERE origem = 'planilha'")->fetchColumn();
    return [
        'apagar' => $antigas,
        'apagar_mexidas' => (int)q("SELECT COUNT(*) FROM agendamentos WHERE origem = 'planilha' AND atualizado_por IS NOT NULL")->fetchColumn(),
        'apagar_fotos' => (int)q("SELECT COUNT(*) FROM fotos f JOIN agendamentos a ON a.id = f.agendamento_id WHERE a.origem = 'planilha'")->fetchColumn(),
        'manter_site' => (int)q("SELECT COUNT(*) FROM agendamentos WHERE origem <> 'planilha'")->fetchColumn(),
        'carregar' => array_sum($novas),
        'carregar_aguardando' => $novas['N'],
        'carregar_recebidas' => $novas['S'],
        'carregar_devolvidas' => $novas['D'],
        'pular' => $pular,
        'pular_exemplos' => $exemplosPulo,
        'recebidas_antes' => (int)q('SELECT COUNT(*) FROM recebidas_es')->fetchColumn(),
        'recebidas_depois' => count($dados['recebidas']),
    ];
}

/** Faz a troca. Devolve os números do que foi feito. */
function planilha_substituir(array $dados): array
{
    $pdo = db();
    $site = planilha_do_site();
    $nul = fn($v) => ($v === '' || $v === null) ? null : $v;
    $pdo->beginTransaction();
    try {
        $ids = q("SELECT id FROM agendamentos WHERE origem = 'planilha'")->fetchAll(PDO::FETCH_COLUMN);
        $fotos = q("SELECT f.arquivo FROM fotos f JOIN agendamentos a ON a.id = f.agendamento_id WHERE a.origem = 'planilha'")->fetchAll(PDO::FETCH_COLUMN);
        q("DELETE f FROM fotos f JOIN agendamentos a ON a.id = f.agendamento_id WHERE a.origem = 'planilha'");
        q("DELETE h FROM historico h JOIN agendamentos a ON a.id = h.agendamento_id WHERE a.origem = 'planilha'");
        $apagadas = q("DELETE FROM agendamentos WHERE origem = 'planilha'")->rowCount();

        $agora = agora();
        $st = $pdo->prepare('INSERT INTO agendamentos (linha_planilha, data_agendamento, empresa, uf, transportadora, fornecedor, filial, produto, categoria, nota_fiscal, volumes, volumes_num, data_receber,
            ref_interna, entregue, entregue_em, observacao, email_enviado, obs_vianna, origem, criado_em) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,\'planilha\',?)');
        $carregadas = 0; $puladas = 0;
        foreach ($dados['agendamentos'] as $a) {
            [$linha, $dt, $emp, $uf, $tr, $fo, $fil, $prod, $cat, $nf, $vol, $volN, $rc, $ref, $ent, $obs, $email, $obs2] = $a;
            if (trim((string)$nf) !== '' && isset($site[planilha_chave($fo, $nf)])) { $puladas++; continue; }
            $ent = in_array($ent, ['S', 'N', 'D'], true) ? $ent : 'N';
            $st->execute([(int)$linha, $nul($dt), (string)$emp, $uf === 'ES' ? 'ES' : 'RJ', $nul(imp_cortar((string)$tr, 120)), $nul(imp_cortar((string)$fo, 150)), $nul(imp_cortar((string)$fil, 5)),
                $nul(imp_cortar((string)$prod, 120)), (string)$cat, $nul(imp_cortar((string)$nf, 255)), $nul(imp_cortar((string)$vol, 40)), $volN === null ? null : (int)$volN, $nul($rc),
                $nul(imp_cortar((string)$ref, 20)), $ent, $ent === 'S' && $rc ? $rc . ' 12:00:00' : null, $nul($obs), $nul(imp_cortar((string)$email, 3)), $nul($obs2), $agora]);
            $carregadas++;
        }

        q('DELETE FROM recebidas_es');
        $st = $pdo->prepare('INSERT INTO recebidas_es (linha_planilha, data_emissao, transportadora, fornecedor, material, nota_fiscal, volumes, status, data_recebido_rj, observacao) VALUES (?,?,?,?,?,?,?,?,?,?)');
        foreach ($dados['recebidas'] as $r) {
            $st->execute([(int)$r[0], $nul($r[1]), $nul(imp_cortar((string)$r[2], 120)), $nul(imp_cortar((string)$r[3], 150)), $nul(imp_cortar((string)$r[4], 120)), $nul(imp_cortar((string)$r[5], 150)),
                $nul(imp_cortar((string)$r[6], 40)), $nul(imp_cortar((string)$r[7], 20)), $nul($r[8]), $nul(imp_cortar((string)$r[9], 255))]);
        }
        registrar_historico(null, 'editou', ['planilha' => ["$apagadas notas", "$carregadas notas"]]);
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }
    // fotos: só apaga os arquivos depois que o banco confirmou
    foreach ($fotos as $arq) @unlink(uploads_dir() . '/' . $arq);
    return ['apagadas' => $apagadas, 'carregadas' => $carregadas, 'puladas' => $puladas, 'recebidas' => count($dados['recebidas']), 'fotos' => count($fotos), 'ids' => count($ids)];
}
