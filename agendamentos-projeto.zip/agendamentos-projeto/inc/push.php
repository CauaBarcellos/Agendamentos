<?php
/**
 * Notificações no celular (Web Push), sem serviço pago: o padrão dos navegadores.
 *  - Chaves VAPID (RFC 8292) geradas uma vez e guardadas na tabela "ajustes".
 *  - Mensagem criptografada como manda a RFC 8291 (aes128gcm) — só o aparelho consegue ler.
 *  - Enviada depois que a página já respondeu, para ninguém esperar.
 */

/** Só envia para os serviços de push conhecidos (impede usar o portal para acessar outros endereços). */
const PUSH_SERVICOS = ['fcm.googleapis.com', 'android.googleapis.com', 'updates.push.services.mozilla.com', 'push.services.mozilla.com', 'web.push.apple.com', 'notify.windows.com'];

function b64u(string $s): string { return rtrim(strtr(base64_encode($s), '+/', '-_'), '='); }
function b64u_dec(string $s): string { return (string)base64_decode(strtr($s, '-_', '+/') . str_repeat('=', (4 - strlen($s) % 4) % 4)); }

function ajuste(string $chave): ?string
{
    $v = q('SELECT valor FROM ajustes WHERE chave = ?', [$chave])->fetchColumn();
    return $v === false ? null : (string)$v;
}
function ajuste_gravar(string $chave, string $valor): void
{
    q('INSERT INTO ajustes (chave, valor) VALUES (?, ?) ON DUPLICATE KEY UPDATE valor = VALUES(valor)', [$chave, $valor]);
}

/** Chave pública P-256 "crua" (65 bytes: 04 || x || y) → PEM, que o openssl entende. */
function ec_pem_publica(string $crua): string
{
    $der = hex2bin('3059301306072a8648ce3d020106082a8648ce3d030107034200') . $crua;
    return "-----BEGIN PUBLIC KEY-----\n" . chunk_split(base64_encode($der), 64, "\n") . "-----END PUBLIC KEY-----\n";
}
/** Detalhes de uma chave EC → chave pública crua de 65 bytes. */
function ec_crua(array $det): string
{
    return "\x04" . str_pad($det['ec']['x'], 32, "\0", STR_PAD_LEFT) . str_pad($det['ec']['y'], 32, "\0", STR_PAD_LEFT);
}
/**
 * Opções extras do openssl. No Linux da hospedagem não precisa de nada; no Windows (XAMPP) o openssl
 * às vezes não acha o openssl.cnf, então aponta para ele.
 */
function openssl_opcoes(): array
{
    static $op = null;
    if ($op !== null) return $op;
    $op = [];
    if (@openssl_pkey_new(['curve_name' => 'prime256v1', 'private_key_type' => OPENSSL_KEYTYPE_EC])) return $op;
    foreach ([getenv('OPENSSL_CONF') ?: '', dirname(PHP_BINARY) . '/extras/ssl/openssl.cnf', dirname(PHP_BINARY, 2) . '/apache/conf/openssl.cnf', 'C:/xampp2/php/extras/ssl/openssl.cnf'] as $cnf) {
        if ($cnf !== '' && is_file($cnf)) { $op = ['config' => $cnf]; break; }
    }
    while (openssl_error_string()) {} // limpa a fila de erros do openssl
    return $op;
}

function ec_nova(): OpenSSLAsymmetricKey
{
    $k = openssl_pkey_new(['curve_name' => 'prime256v1', 'private_key_type' => OPENSSL_KEYTYPE_EC] + openssl_opcoes());
    if (!$k) throw new RuntimeException('não consegui gerar a chave (openssl)');
    return $k;
}

/** Chaves VAPID do portal (cria na primeira vez). Devolve [chave privada, pública em base64url]. */
function vapid_chaves(): array
{
    $pem = ajuste('vapid_privada');
    if (!$pem) {
        $k = ec_nova();
        if (!openssl_pkey_export($k, $pem, null, openssl_opcoes())) throw new RuntimeException('não consegui salvar a chave (openssl)');
        ajuste_gravar('vapid_privada', $pem);
        ajuste_gravar('vapid_publica', b64u(ec_crua(openssl_pkey_get_details($k))));
    }
    $priv = openssl_pkey_get_private($pem);
    return [$priv, b64u(ec_crua(openssl_pkey_get_details($priv)))];
}

/** Assinatura ES256 no formato do JWT (R || S, 64 bytes), a partir da assinatura DER do openssl. */
function es256_jwt(string $der): string
{
    $pos = 3;                                   // 30 len 02
    $lr = ord($der[$pos]); $r = substr($der, $pos + 1, $lr);
    $pos += 1 + $lr + 1;                        // pula R e o 02 do S
    $ls = ord($der[$pos]); $s = substr($der, $pos + 1, $ls);
    $fix = fn($v) => str_pad(ltrim($v, "\0"), 32, "\0", STR_PAD_LEFT);
    return $fix($r) . $fix($s);
}

/** Cabeçalho Authorization (VAPID) para o serviço de push do endpoint. */
function vapid_cabecalho(string $endpoint, $priv, string $pub, int $agora): string
{
    $p = parse_url($endpoint);
    $contato = $GLOBALS['CONFIG']['contato_push'] ?? ('mailto:suporte@' . preg_replace('/^www\./', '', $_SERVER['HTTP_HOST'] ?? 'localhost'));
    $dados = b64u(json_encode(['typ' => 'JWT', 'alg' => 'ES256'])) . '.' . b64u(json_encode(['aud' => $p['scheme'] . '://' . $p['host'], 'exp' => $agora + 12 * 3600, 'sub' => $contato]));
    openssl_sign($dados, $der, $priv, OPENSSL_ALGO_SHA256);
    return 'vapid t=' . $dados . '.' . b64u(es256_jwt($der)) . ', k=' . $pub;
}

/**
 * Criptografa a mensagem para um aparelho (RFC 8291, aes128gcm).
 * $chaveP256 e $auth vêm da inscrição do aparelho (base64url). $sal e $efemera só para teste.
 */
function push_cifrar(string $texto, string $chaveP256, string $auth, ?string $sal = null, $efemera = null): string
{
    $uaPub = b64u_dec($chaveP256);
    $authSecret = b64u_dec($auth);
    if (strlen($uaPub) !== 65 || strlen($authSecret) < 16) throw new RuntimeException('inscrição inválida');
    $as = $efemera ?: ec_nova();
    $asPub = ec_crua(openssl_pkey_get_details($as));
    $ecdh = openssl_pkey_derive(ec_pem_publica($uaPub), $as, 32);
    if ($ecdh === false) throw new RuntimeException('falha no ECDH');
    $ikm = hash_hkdf('sha256', $ecdh, 32, "WebPush: info\0" . $uaPub . $asPub, $authSecret);
    $sal = $sal ?? random_bytes(16);
    $cek = hash_hkdf('sha256', $ikm, 16, "Content-Encoding: aes128gcm\0", $sal);
    $nonce = hash_hkdf('sha256', $ikm, 12, "Content-Encoding: nonce\0", $sal);
    $cifrado = openssl_encrypt($texto . "\x02", 'aes-128-gcm', $cek, OPENSSL_RAW_DATA, $nonce, $tag);
    return $sal . pack('N', 4096) . chr(65) . $asPub . $cifrado . $tag;
}

/** O endpoint é de um serviço de push conhecido e https? */
function push_endpoint_ok(string $url): bool
{
    $p = parse_url($url);
    if (($p['scheme'] ?? '') !== 'https' || empty($p['host'])) return false;
    foreach (PUSH_SERVICOS as $h) if ($p['host'] === $h || str_ends_with($p['host'], '.' . $h)) return true;
    return false;
}

/** Envia para uma inscrição. Devolve o código HTTP (201 = entregue ao serviço; 404/410 = aparelho saiu). */
function push_enviar_um(array $insc, array $msg): int
{
    if (!push_endpoint_ok($insc['endpoint'])) return 0;
    [$priv, $pub] = vapid_chaves();
    $corpo = push_cifrar(json_encode($msg, JSON_UNESCAPED_UNICODE), $insc['p256dh'], $insc['auth']);
    $cab = ['Authorization: ' . vapid_cabecalho($insc['endpoint'], $priv, $pub, time()), 'Content-Encoding: aes128gcm',
        'Content-Type: application/octet-stream', 'TTL: 86400', 'Urgency: ' . (($msg['urgente'] ?? false) ? 'high' : 'normal')];
    [$cod, $resp, $erro] = http_post($insc['endpoint'], $cab, $corpo);
    // falha que não é "aparelho saiu": registra o motivo (ajuda a descobrir problema de configuração)
    if ($cod < 200 || $cod >= 300) error_log('push: ' . parse_url($insc['endpoint'], PHP_URL_HOST) . ' respondeu ' . $cod . ' ' . ($cod ? mb_substr(trim((string)$resp), 0, 300) : $erro));
    return $cod;
}

/** POST https com curl; se a hospedagem não tiver curl, usa as funções de rede do próprio PHP. Devolve [código, resposta, erro]. */
function http_post(string $url, array $cabecalhos, string $corpo, bool $semCurl = false): array
{
    if (!$semCurl && function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true, CURLOPT_POSTFIELDS => $corpo, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 8, CURLOPT_CONNECTTIMEOUT => 4,
            CURLOPT_FOLLOWLOCATION => false, CURLOPT_PROTOCOLS => CURLPROTO_HTTPS, CURLOPT_HTTPHEADER => $cabecalhos,
        ]);
        $resp = curl_exec($ch);
        return [(int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE), (string)$resp, curl_error($ch)];
    }
    $ctx = stream_context_create([
        'http' => ['method' => 'POST', 'header' => implode("\r\n", $cabecalhos), 'content' => $corpo, 'timeout' => 8, 'ignore_errors' => true, 'follow_location' => 0],
        'ssl' => ['verify_peer' => true, 'verify_peer_name' => true],
    ]);
    $resp = @file_get_contents($url, false, $ctx);
    $linha = $http_response_header[0] ?? '';
    $cod = preg_match('#^HTTP/\S+\s+(\d{3})#', $linha, $m) ? (int)$m[1] : 0;
    return [$cod, (string)$resp, $cod ? '' : (error_get_last()['message'] ?? 'sem resposta')];
}

/** Fila de avisos da página atual; enviados depois que a resposta já saiu (register_shutdown_function). */
function avisar(array $uids, string $titulo, string $corpo, string $url, string $tag = ''): void
{
    $uids = array_values(array_unique(array_filter(array_map('intval', $uids))));
    if (!$uids) return;
    static $registrado = false;
    $GLOBALS['__push_fila'][] = [$uids, ['titulo' => $titulo, 'corpo' => $corpo, 'url' => $url, 'tag' => $tag ?: 'agend-' . substr(md5($url), 0, 8)]];
    if (!$registrado) {
        $registrado = true;
        register_shutdown_function('push_despachar');
    }
}

function push_despachar(): void
{
    $fila = $GLOBALS['__push_fila'] ?? [];
    $GLOBALS['__push_fila'] = [];
    if (!$fila) return;
    if (function_exists('fastcgi_finish_request')) fastcgi_finish_request(); // a pessoa já recebeu a página
    @set_time_limit(60);
    foreach ($fila as [$uids, $msg]) {
        try {
            $marcas = implode(',', array_fill(0, count($uids), '?'));
            foreach (q("SELECT * FROM push_inscricoes WHERE usuario_id IN ($marcas)", $uids)->fetchAll() as $insc) {
                $cod = push_enviar_um($insc, $msg);
                if ($cod >= 200 && $cod < 300) q('UPDATE push_inscricoes SET ultimo_envio = ?, falhas = 0 WHERE id = ?', [agora(), $insc['id']]);
                elseif (in_array($cod, [404, 410], true)) q('DELETE FROM push_inscricoes WHERE id = ?', [$insc['id']]); // aparelho desinscrito
                else q('UPDATE push_inscricoes SET falhas = falhas + 1 WHERE id = ?', [$insc['id']]);
            }
        } catch (Throwable $e) {
            error_log('push: ' . $e->getMessage());
        }
    }
}

/** Ids dos usuários ativos com estes perfis (menos quem fez a ação). */
function usuarios_com_perfil(array $perfis, ?int $exceto = null): array
{
    $marcas = implode(',', array_fill(0, count($perfis), '?'));
    $ids = q("SELECT id FROM usuarios WHERE ativo = 1 AND perfil IN ($marcas)", $perfis)->fetchAll(PDO::FETCH_COLUMN);
    return array_values(array_filter(array_map('intval', $ids), fn($i) => $i !== $exceto));
}
