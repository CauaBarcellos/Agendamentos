<?php
// Carregado no topo de todas as páginas.
declare(strict_types=1);

// O portal precisa de PHP 8.0 ou mais novo. Em versão antiga, explica em vez de dar "erro 500" sem mensagem.
if (PHP_VERSION_ID < 80000) {
    http_response_code(500);
    header('Content-Type: text/html; charset=utf-8');
    exit('<p style="font-family:system-ui;padding:24px;max-width:640px">Este portal precisa de <b>PHP 8.0 ou mais novo</b>, e o servidor está usando o PHP ' . htmlspecialchars(PHP_VERSION) . '.<br><br>No cPanel, abra <b>MultiPHP Manager</b> (ou "Selecionar versão do PHP"), escolha <b>PHP 8.2</b> para este domínio e recarregue a página.</p>');
}
$faltam = array_values(array_filter(['mbstring', 'pdo_mysql'], fn($x) => !extension_loaded($x)));
if ($faltam) {
    http_response_code(500);
    header('Content-Type: text/html; charset=utf-8');
    exit('<p style="font-family:system-ui;padding:24px;max-width:640px">Falta ligar no servidor a extensão do PHP: <b>' . implode(', ', $faltam) . '</b>.<br><br>No cPanel, abra <b>Selecionar versão do PHP</b> → aba <b>Extensões</b>, marque ' . (count($faltam) > 1 ? 'essas extensões' : 'essa extensão') . ' e recarregue a página.</p>');
}
// array_is_list só existe a partir do PHP 8.1
if (!function_exists('array_is_list')) {
    function array_is_list(array $a): bool { $i = 0; foreach ($a as $k => $_) { if ($k !== $i++) return false; } return true; }
}

define('APP_DIR', dirname(__DIR__));
$CONFIG = require APP_DIR . '/config.php';
date_default_timezone_set($CONFIG['timezone'] ?? 'America/Sao_Paulo');
mb_internal_encoding('UTF-8');

// ---------- segurança ----------
$LOCAL = in_array(strtolower(preg_replace('/:\d+$/', '', $_SERVER['HTTP_HOST'] ?? '')), ['localhost', '127.0.0.1', '[::1]'], true) || PHP_SAPI === 'cli';
$HTTPS = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
    || strtolower($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https'; // atrás de proxy/CDN (Cloudflare etc.)

// Força HTTPS fora do computador local.
if (!$LOCAL && !$HTTPS && ($CONFIG['forcar_https'] ?? true)) {
    $host = preg_replace('/[^A-Za-z0-9.\-:\[\]]/', '', $_SERVER['HTTP_HOST'] ?? '');
    header('Location: https://' . $host . ($_SERVER['REQUEST_URI'] ?? '/'), true, 301);
    exit;
}

// Em produção nunca mostra erros na tela (só no log do servidor).
ini_set('display_errors', $LOCAL ? '1' : '0');
ini_set('log_errors', '1');
header_remove('X-Powered-By');

if (!headers_sent()) {
    if ($HTTPS) header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: DENY');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: camera=(self), microphone=(), geolocation=(), payment=()');
    header("Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src 'self' data: blob:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'; object-src 'none'");
    header('Cross-Origin-Opener-Policy: same-origin');
    if (PHP_SAPI !== 'cli' && !str_ends_with($_SERVER['SCRIPT_NAME'] ?? '', 'exportar.php')) header('Cache-Control: no-store'); // páginas com dados internos não ficam em cache
}

if (session_status() !== PHP_SESSION_ACTIVE) {
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.gc_maxlifetime', '28800');
    session_name($HTTPS ? '__Host-agend' : 'agend_sess');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'httponly' => true,
        'samesite' => 'Lax',
        'secure' => $HTTPS,
    ]);
    session_start();
    // Sessão do portal expira após 8 h sem uso.
    if (isset($_SESSION['u']) && time() - ($_SESSION['atividade'] ?? time()) > 28800) { $_SESSION = []; }
    $_SESSION['atividade'] = time();
}

require __DIR__ . '/db.php';
require __DIR__ . '/helpers.php';
require __DIR__ . '/auth.php';
require __DIR__ . '/migracoes.php';
require __DIR__ . '/nfe.php';
require __DIR__ . '/recebimento.php';
require __DIR__ . '/push.php';
if (basename($_SERVER['SCRIPT_NAME'] ?? '') !== 'install.php') aplicar_migracoes();

// Filtro de empresa vale para o portal inteiro e fica guardado na sessão.
if (isset($_GET['emp'])) {
    $e = (string)$_GET['emp'];
    $_SESSION['emp'] = in_array($e, EMPRESAS, true) ? $e : '';
}
$EMP = $_SESSION['emp'] ?? '';
