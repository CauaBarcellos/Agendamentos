<?php
function db(): PDO
{
    static $pdo = null;
    if ($pdo) return $pdo;
    global $CONFIG;
    $c = $CONFIG['db'];
    $dsn = "mysql:host={$c['host']};port={$c['port']};dbname={$c['nome']};charset=utf8mb4";
    try {
        $pdo = new PDO($dsn, $c['usuario'], $c['senha'], [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
    } catch (PDOException $e) {
        http_response_code(500);
        echo '<p style="font-family:system-ui;padding:24px">Não foi possível conectar ao banco de dados. Confira os dados em <b>config.php</b> e se o MySQL está ligado. Se é a primeira vez, abra <a href="install.php">install.php</a>.</p>';
        exit;
    }
    return $pdo;
}

/**
 * Roda uma consulta preparada (os valores nunca são colados no texto SQL).
 * As consultas preparadas são "de verdade" (feitas pelo MySQL, sem emulação), e o MySQL não aceita o mesmo
 * :nome duas vezes na mesma consulta. Aqui cada repetição ganha um nome próprio automaticamente.
 */
function q(string $sql, array $params = []): PDOStatement
{
    if ($params && !array_is_list($params)) [$sql, $params] = nomes_unicos($sql, $params);
    $st = db()->prepare($sql);
    $st->execute($params);
    return $st;
}

/** Troca :nome repetido por :nome, :nome__2, :nome__3... (ignora o que estiver entre aspas). */
function nomes_unicos(string $sql, array $params): array
{
    $vistos = [];
    $novos = [];
    $partes = preg_split('/(\'(?:[^\'\\\\]|\\\\.|\'\')*\'|"(?:[^"\\\\]|\\\\.|"")*")/s', $sql, -1, PREG_SPLIT_DELIM_CAPTURE);
    foreach ($partes as $i => $trecho) {
        if ($i % 2 === 1) continue; // texto entre aspas: não mexe
        $partes[$i] = preg_replace_callback('/(?<![:\w]):([A-Za-z_]\w*)/', function ($m) use (&$vistos, &$novos, $params) {
            $nome = $m[1];
            $vistos[$nome] = ($vistos[$nome] ?? 0) + 1;
            $uso = $vistos[$nome] === 1 ? $nome : $nome . '__' . $vistos[$nome];
            foreach ([$nome, ':' . $nome] as $k) if (array_key_exists($k, $params)) { $novos[$uso] = $params[$k]; break; }
            return ':' . $uso;
        }, $trecho);
    }
    return [implode('', $partes), $novos];
}

function agora(): string
{
    return date('Y-m-d H:i:s');
}
