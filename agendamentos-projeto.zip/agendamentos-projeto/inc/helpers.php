<?php
const EMPRESAS = ['GREEN MED', 'ESTEVIA', 'ESSENCIAL'];
const EMP_NOME = ['GREEN MED' => 'Green Med', 'ESTEVIA' => 'Estevia', 'ESSENCIAL' => 'Essencial', 'RAL' => 'RAL', '' => '—'];
const FILIAL_EMP = ['GREEN MED' => '19', 'ESTEVIA' => '16', 'ESSENCIAL' => '15'];
const PERFIL_NOME = ['admin' => 'Administrador', 'operador' => 'Operador', 'leitor' => 'Leitor', 'filial_es' => 'Filial ES'];
const DIVERG = ['falta' => 'Falta de volume', 'avaria' => 'Avaria', 'sobra' => 'Sobra', 'errado' => 'Produto errado', 'outro' => 'Outro problema'];
const ST_LABEL = ['divergencia' => 'Recebida c/ divergência', 'atrasado' => 'Atrasado', 'hoje' => 'Chega hoje', 'agendado' => 'Agendado', 'entregue' => 'Entregue', 'devolvida' => 'Devolvida', 'semdata' => 'Sem data'];
const ENT_LABEL = ['N' => 'Aguardando', 'S' => 'Entregue', 'D' => 'Devolvida'];
const DIAS = ['domingo', 'segunda', 'terça', 'quarta', 'quinta', 'sexta', 'sábado'];
const MESES = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];
const CATEGORIAS = ['Material', 'Medicamento', 'Fralda', 'Soro', 'Luva', 'Saneante', 'Outros'];

function e($s): string { return htmlspecialchars((string)($s ?? ''), ENT_QUOTES, 'UTF-8'); }
function hoje(): string { return date('Y-m-d'); }
function soma_dias(string $d, int $n): string { return date('Y-m-d', strtotime("$d $n day")); }
function br(?string $d): string { return $d ? date('d/m/Y', strtotime($d)) : '—'; }
function dm(?string $d): string { return $d ? date('d/m', strtotime($d)) : '—'; }
function br_hora(?string $d): string { return $d ? date('d/m/Y H:i', strtotime($d)) : '—'; }
function dia_longo(string $d): string { $t = strtotime($d); return DIAS[(int)date('w', $t)] . ', ' . (int)date('j', $t) . ' de ' . MESES[(int)date('n', $t) - 1]; }
function dia_curto(string $d): string { $t = strtotime($d); return mb_substr(DIAS[(int)date('w', $t)], 0, 3) . ', ' . (int)date('j', $t) . ' ' . mb_substr(MESES[(int)date('n', $t) - 1], 0, 3); }
function n($v): string { return number_format((float)$v, 0, ',', '.'); }
function plural(int $q, string $um, string $varios): string { return n($q) . ' ' . ($q === 1 ? $um : $varios); }
function ucfirst_mb(string $s): string { return mb_strtoupper(mb_substr($s, 0, 1)) . mb_substr($s, 1); }
function emp_nome(?string $e): string { return EMP_NOME[$e ?? ''] ?? (string)$e; }

/** Status calculado a partir da situação e da data para receber. */
function status_de(array $r): string
{
    if ($r['entregue'] === 'S') return !empty($r['divergencia']) ? 'divergencia' : 'entregue';
    if ($r['entregue'] === 'D') return 'devolvida';
    if (!$r['data_receber']) return 'semdata';
    $h = hoje();
    if ($r['data_receber'] < $h) return 'atrasado';
    if ($r['data_receber'] === $h) return 'hoje';
    return 'agendado';
}

/** "TELECARGA REGINA" → "Telecarga Regina". Mantém siglas curtas em caixa alta. */
function titulo(?string $s): string
{
    if (!$s) return '';
    static $manter = ['DHL','VTC','ABL','TKL','SR','FL','EJ','E.J.','RJ','ES','NF','SA','S.A.','LTDA','EPP','ME','CRAL','B.BRAUN','ABT','MG','SP','JR','BD','3M','HB'];
    static $minus = ['de','da','do','das','dos','e','em','na','no'];
    $partes = preg_split('/(\s+|-|\/)/u', mb_strtolower($s), -1, PREG_SPLIT_DELIM_CAPTURE);
    foreach ($partes as $i => $w) {
        if ($w === '' || preg_match('/^(\s+|-|\/)$/u', $w)) continue;
        $U = mb_strtoupper($w);
        if (in_array($U, $manter, true) || preg_match('/^\d/u', $w)) { $partes[$i] = $U; continue; }
        if ($i > 0 && in_array($w, $minus, true)) continue;
        $partes[$i] = ucfirst_mb($w);
    }
    return implode('', $partes);
}

/** "EMPENHO PENDENTE" → "Empenho pendente" */
function frase(?string $s): string { return $s ? ucfirst_mb(mb_strtolower($s)) : ''; }

function categoria_de(string $prod): string
{
    $k = preg_replace('/[^A-Z]/', '', strtoupper(iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $prod) ?: $prod));
    if (preg_match('/^ME[I]?DIC/', $k)) return 'Medicamento';
    foreach (['MATER' => 'Material', 'FRALD' => 'Fralda', 'SORO' => 'Soro', 'LUVA' => 'Luva', 'SANEA' => 'Saneante'] as $p => $c) {
        if (strpos($k, $p) === 0) return $c;
    }
    return 'Outros';
}

function maiusc(?string $s): string { return mb_strtoupper(trim((string)$s)); }

/** URL da página atual trocando alguns parâmetros (null remove). */
function url_com(array $troca, ?string $pagina = null): string
{
    $p = array_merge($_GET, $troca);
    foreach ($p as $k => $v) if ($v === null || $v === '') unset($p[$k]);
    $base = $pagina ?? basename($_SERVER['SCRIPT_NAME']);
    return $base . ($p ? '?' . http_build_query($p) : '');
}

function flash(string $msg, string $tipo = 'ok'): void { $_SESSION['flash'] = [$msg, $tipo]; }
function pegar_flash(): ?array { $f = $_SESSION['flash'] ?? null; unset($_SESSION['flash']); return $f; }

function redirecionar(string $url): void { header('Location: ' . $url); exit; }

/** Só aceita retorno para páginas do próprio portal. */
function volta_segura(?string $u, string $padrao = 'index.php'): string
{
    $u = (string)$u;
    if ($u === '' || strpos($u, '//') !== false || strpos($u, '\\') !== false || preg_match('/^[a-z]+:/i', $u)) return $padrao;
    return $u;
}

/** Totais do resumo (respeita o filtro de empresa). */
function resumo(string $emp): array
{
    $h = hoje();
    $sql = "SELECT
        COALESCE(SUM(entregue='N' AND data_receber < :h),0) AS atrasados,
        COALESCE(SUM(entregue='N' AND data_receber = :h),0) AS hoje,
        COALESCE(SUM(entregue='N' AND data_receber > :h AND data_receber <= :h7),0) AS proximos,
        COALESCE(SUM(entregue='N'),0) AS aguardando,
        COALESCE(SUM(entregue='S' AND data_receber BETWEEN :m1 AND :h),0) AS mes
        FROM agendamentos" . ($emp !== '' ? ' WHERE empresa = :emp' : '');
    $p = [':h' => $h, ':h7' => soma_dias($h, 7), ':m1' => date('Y-m-01')];
    if ($emp !== '') $p[':emp'] = $emp;
    return array_map('intval', q($sql, $p)->fetch());
}

function registrar_historico(?int $agId, string $acao, ?array $detalhes = null): void
{
    q('INSERT INTO historico (agendamento_id, usuario_id, acao, detalhes, criado_em) VALUES (?,?,?,?,?)',
        [$agId, usuario()['id'] ?? null, $acao, $detalhes ? json_encode($detalhes, JSON_UNESCAPED_UNICODE) : null, agora()]);
}

const CAMPOS_LABEL = [
    'fornecedor' => 'Fornecedor', 'transportadora' => 'Transportadora', 'empresa' => 'Empresa', 'uf' => 'UF', 'filial' => 'Filial',
    'data_receber' => 'Data p/ receber', 'data_agendamento' => 'Agendado em', 'nota_fiscal' => 'Nota fiscal', 'volumes' => 'Volumes',
    'produto' => 'Produto', 'email_enviado' => 'E-mail enviado', 'entregue' => 'Situação', 'observacao' => 'Observação', 'obs_vianna' => 'Obs. Vianna', 'chegou_es_em' => 'Chegou no ES em', 'vol_recebidos' => 'Volumes recebidos', 'divergencia' => 'Divergência', 'divergencia_obs' => 'Obs. da divergência', 'fotos' => 'Fotos', 'origem' => 'Origem',
];

function valor_legivel(string $campo, $v): string
{
    if ($v === null || $v === '') return 'vazio';
    if ($campo === 'entregue') return ENT_LABEL[$v] ?? $v;
    if (in_array($campo, ['data_receber', 'data_agendamento', 'chegou_es_em'], true)) return br($v);
    if ($campo === 'empresa') return emp_nome($v);
    if ($campo === 'divergencia') return divergencia_txt((string)$v);
    return (string)$v;
}

function icone(string $nome, int $tam = 16): string
{
    $p = [
        'check' => '<path d="m5 12 5 5 9-10"/>',
        'mais' => '<path d="M12 5v14M5 12h14"/>',
        'busca' => '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
        'filtro' => '<path d="M4 6h16M7 12h10M10 18h4"/>',
        'baixar' => '<path d="M12 4v11m0 0-4-4m4 4 4-4M5 20h14"/>',
        'voltar' => '<path d="M15 6l-6 6 6 6"/>',
        'caminhao' => '<path d="M3 7h11v9H3z"/><path d="M14 10h4l3 3v3h-7"/><circle cx="7" cy="18" r="1.6"/><circle cx="17" cy="18" r="1.6"/>',
        'editar' => '<path d="M4 20h4L19 9l-4-4L4 16v4z"/>',
        'agenda' => '<rect x="4" y="5" width="16" height="15" rx="3"/><path d="M8 3v4M16 3v4M4 10h16"/>',
        'lista' => '<path d="M9 6h11M9 12h11M9 18h11"/><circle cx="4.8" cy="6" r=".9"/><circle cx="4.8" cy="12" r=".9"/><circle cx="4.8" cy="18" r=".9"/>',
        'caixa' => '<path d="M4 13l2.5-7h11L20 13v6H4z"/><path d="M4 13h4.5l1 2h5l1-2H20"/>',
        'pessoas' => '<circle cx="9" cy="8" r="3.2"/><path d="M3.5 19c.6-3.3 2.8-5 5.5-5s4.9 1.7 5.5 5"/><path d="M16 5.2a3 3 0 0 1 0 5.6M18 14.3c1.5.6 2.4 2 2.7 4.2"/>',
        'grafico' => '<path d="M5 20V11M12 20V4M19 20v-6"/>',
        'relogio' => '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
        'disco' => '<ellipse cx="12" cy="6" rx="7.5" ry="3"/><path d="M4.5 6v12c0 1.7 3.4 3 7.5 3s7.5-1.3 7.5-3V6M4.5 12c0 1.7 3.4 3 7.5 3s7.5-1.3 7.5-3"/>',
        'camera' => '<path d="M4 8h3l1.5-2h7L17 8h3v11H4z"/><circle cx="12" cy="13.5" r="3.5"/>',
        'codigo' => '<path d="M4 6v12M7 6v12M10 6v12M14 6v12M16 6v12M20 6v12"/>',
        'sair' => '<path d="M15 4h4v16h-4M10 8l-4 4 4 4M6 12h10"/>',
    ][$nome] ?? '';
    return '<svg width="' . $tam . '" height="' . $tam . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $p . '</svg>';
}

/**
 * "Impressão digital" dos dados da agenda: muda sempre que uma nota é criada, editada, recebida,
 * reaberta ou excluída. A agenda aberta compara isso a cada poucos segundos para saber se precisa se atualizar.
 */
function agenda_fp(string $emp): string
{
    $w = $emp !== '' ? ' WHERE empresa = ?' : '';
    $r = q("SELECT COUNT(*) n, COALESCE(SUM(id),0) s, COALESCE(SUM(UNIX_TIMESTAMP(COALESCE(atualizado_em, criado_em))),0) t,
            COALESCE(SUM(entregue='N'),0) a, COALESCE(SUM(entregue='S'),0) e, COALESCE(SUM(data_receber IS NULL),0) sd FROM agendamentos$w", $emp !== '' ? [$emp] : [])->fetch();
    return substr(md5(implode('|', $r) . '|' . date('Y-m-d')), 0, 16); // a data entra para virar o "atrasado" à meia-noite
}

/** Nome de quem fez a última alteração (e o id), para avisar "Fulano atualizou a agenda". */
function agenda_ultimo_autor(string $emp): array
{
    $w = $emp !== '' ? ' WHERE a.empresa = ?' : '';
    $r = q("SELECT u.id, u.nome FROM agendamentos a JOIN usuarios u ON u.id = a.atualizado_por$w ORDER BY a.atualizado_em DESC, a.id DESC LIMIT 1", $emp !== '' ? [$emp] : [])->fetch();
    return $r ?: ['id' => 0, 'nome' => ''];
}

/**
 * Impressão digital de tudo que as outras páginas mostram (notas de todas as empresas, Recebidas ES e histórico).
 * Registros, Filial ES, Recebidas ES e o admin comparam isso para se atualizar sozinhos. Guardada na primeira chamada:
 * a página chama antes das consultas (se algo mudar durante a montagem, a próxima consulta corrige).
 */
function site_fp(): string
{
    static $fp = null;
    if ($fp === null) {
        $r = q('SELECT (SELECT COUNT(*) FROM recebidas_es), (SELECT COALESCE(SUM(id),0) FROM recebidas_es), (SELECT COALESCE(MAX(id),0) FROM historico)')->fetch(PDO::FETCH_NUM);
        $fp = substr(md5(agenda_fp('') . '|' . implode('|', $r)), 0, 16);
    }
    return $fp;
}

/** Versão dos arquivos do site: muda quando sobem um app.js, style.css ou topo novos, e a página aberta se recarrega sozinha. */
function site_versao(): string
{
    $t = '';
    foreach (['assets/app.js', 'assets/style.css', 'inc/layout.php', 'inc/admin_auth.php'] as $a) $t .= v($a) . '|';
    return substr(md5($t), 0, 10);
}

/** Número para o "?v=" de um arquivo (quando ele mudou): o navegador baixa o novo sem precisar de Ctrl+F5. */
function v(string $arquivo): int
{
    return (int)@filemtime(dirname(__DIR__) . '/' . $arquivo);
}

/** "falta,avaria" → "Falta de volume, Avaria" */
function divergencia_txt(?string $v): string
{
    if (!$v) return '';
    return implode(', ', array_map(fn($k) => DIVERG[$k] ?? $k, explode(',', $v)));
}
