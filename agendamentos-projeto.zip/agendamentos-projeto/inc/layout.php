<?php
/**
 * Cabeçalho comum. $ativo: agenda | registros | recebidas | usuarios | historico | outro
 * $mostrarResumo: exibe a faixa de números + seletor de empresa.
 */
function topo(string $titulo, string $ativo = 'outro', bool $mostrarResumo = false): void
{
    global $EMP;
    $u = usuario();
    $hoje = hoje();
    ?><!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#FFFFFF">
<title><?= e($titulo) ?> · Agendamentos</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Geist:wght@400;500;600;700&family=Geist+Mono:wght@400;500&display=swap">
<link rel="icon" type="image/svg+xml" href="favicon.svg?v=3">
<link rel="icon" href="favicon.ico?v=3" sizes="any">
<link rel="icon" type="image/png" sizes="32x32" href="assets/favicon-32.png?v=3">
<link rel="apple-touch-icon" href="assets/apple-touch-icon.png?v=3">
<link rel="manifest" href="manifest.webmanifest">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="Agendamentos">
<meta name="apple-mobile-web-app-status-bar-style" content="default">
<link rel="stylesheet" href="assets/style.css?v=<?= v('assets/style.css') ?>">
</head>
<body class="pg-<?= e($ativo) ?>" data-versao="<?= site_versao() ?>" data-fp-site="<?= site_fp() ?>" data-intervalo="<?= (int)($GLOBALS['CONFIG']['agenda_intervalo'] ?? 8) ?>">
<header class="top">
  <div class="wrap topin">
    <a class="brand" href="<?= e_filial_es() ? 'es.php' : 'index.php' ?>"><span class="mark"><?= icone('caminhao', 17) ?></span><b>Agendamentos</b></a>
    <?php if (!e_filial_es()): ?>
    <nav class="tabs" aria-label="Seções">
      <a class="tab" href="index.php" <?= $ativo === 'agenda' ? 'aria-current="page"' : '' ?>><span class="ti"><?= icone('agenda', 23) ?></span>Agenda</a>
      <a class="tab" href="registros.php" <?= $ativo === 'registros' ? 'aria-current="page"' : '' ?>><span class="ti"><?= icone('lista', 23) ?></span>Registros</a>
      <a class="tab" href="recebidas.php" <?= $ativo === 'recebidas' ? 'aria-current="page"' : '' ?>><span class="ti"><?= icone('caixa', 23) ?></span><span>Recebidas<span class="lbl-long"> ES</span></span></a>
      <a class="tab so-desk" href="calendario.php" <?= $ativo === 'calendario' ? 'aria-current="page"' : '' ?>>Calendário</a>
      <?php if (pode_editar()): ?><a class="tab so-cel" href="entrada.php" <?= $ativo === 'receber' ? 'aria-current="page"' : '' ?>><span class="ti"><?= icone('codigo', 23) ?></span>Entrada</a><?php endif; ?>
      <?php if (pode_editar()): ?><a class="tab so-cel" href="importar.php" <?= $ativo === 'importar' ? 'aria-current="page"' : '' ?>><span class="ti"><?= icone('baixar', 23) ?></span>Importar</a><?php endif; ?>
      <?php if (e_admin()): ?><a class="tab" href="es.php" <?= $ativo === 'es' ? 'aria-current="page"' : '' ?>><span class="ti"><?= icone('caminhao', 23) ?></span>Filial ES</a><?php endif; ?>
    </nav>
    <?php endif; ?>
    <span class="sp"></span>
    <?php if (pode_editar()): ?>
      <a class="btn ghost" href="entrada.php" title="Ler o código de barras da nota e conferir o recebimento"><?= icone('codigo', 15) ?><span>Dar entrada</span></a>
      <a class="btn ghost" href="importar.php" title="Importar XML de NF-e ou planilha"><?= icone('baixar', 15) ?><span>Importar</span></a>
      <a class="btn primary" href="agendamento.php"><?= icone('mais', 15) ?><span>Novo<span class="lbl-long"> agendamento</span></span></a>
    <?php endif; ?>
    <details class="user">
      <summary aria-label="Menu do usuário"><span class="avatar"><?= e(mb_strtoupper(mb_substr($u['nome'], 0, 1))) ?></span></summary>
      <div class="menu">
        <div class="who"><b><?= e($u['nome']) ?></b><small><?= e(PERFIL_NOME[$u['perfil']] ?? ucfirst($u['perfil'])) ?> · <?= e($u['login']) ?></small></div>
        <div class="app-itens" id="app-itens" data-csrf="<?= e(csrf_token()) ?>">
          <button type="button" id="app-instalar" hidden>Instalar o app no celular</button>
          <p class="app-dica" id="app-ios" hidden>No iPhone: toque em <b>Compartilhar</b> (quadrado com seta) e depois em <b>Adicionar à Tela de Início</b>.</p>
          <button type="button" id="avisos-bt" hidden>Ativar avisos neste aparelho</button>
          <button type="button" id="avisos-teste" hidden>Enviar aviso de teste</button>
          <p class="app-dica" id="avisos-dica" hidden></p>
        </div>
        <a href="senha.php">Alterar minha senha</a>
        <a href="logout.php"><?= icone('sair', 15) ?> Sair</a>
      </div>
    </details>
    <img class="logo-emp" src="assets/logo-greenmed.png" alt="Green Med">
  </div>
</header>
<main class="wrap">
<?php
    if ($f = pegar_flash()) {
        echo '<div class="flash ' . e($f[1]) . '" role="status">' . e($f[0]) . '</div>';
    }
    if ($mostrarResumo) {
        $r = resumo($EMP);
        $mes = MESES[(int)date('n') - 1];
        $itens = [
            ['Atrasados', $r['atrasados'], '--late', 'index.php?dia=atrasados'],
            ['Chegam hoje', $r['hoje'], '--today', 'index.php?dia=' . $hoje],
            ['Próximos 7 dias', $r['proximos'], '--sched', 'registros.php?st=agendado&de=' . soma_dias($hoje, 1) . '&ate=' . soma_dias($hoje, 7) . '&ord=rc&dir=asc'],
            ['Aguardando entrega', $r['aguardando'], '--muted', 'registros.php?st=pend&ord=rc&dir=asc'],
            ['Entregues no mês', $r['mes'], '--done', 'registros.php?st=entregue&de=' . date('Y-m-01') . '&ate=' . $hoje],
        ];
        echo '<section class="summary" id="resumo" data-vivo><div class="stats">';
        foreach ($itens as [$l, $v, $c, $href]) {
            echo '<a class="stat" href="' . e($href) . '" style="--c:var(' . $c . ')"><span class="v"><i></i>' . n($v) . '</span><span class="l">' . e($l) . '</span></a>';
        }
        echo '</div><div class="seg" role="group" aria-label="Empresa">';
        foreach (array_merge([''], EMPRESAS) as $emp) {
            echo '<a href="' . e(url_com(['emp' => $emp === '' ? 'todas' : $emp, 'p' => null])) . '" aria-pressed="' . ($EMP === $emp ? 'true' : 'false') . '">' . e($emp === '' ? 'Todas' : emp_nome($emp)) . '</a>';
        }
        echo '</div></section>';
    }
}

function rodape(): void
{
    ?>
</main>
<script src="assets/app.js?v=<?= v('assets/app.js') ?>"></script>
</body>
</html>
<?php
}
