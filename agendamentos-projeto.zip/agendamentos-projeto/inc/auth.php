<?php
function usuario(): ?array { return $_SESSION['u'] ?? null; }

function exigir_login(): void
{
    $u = usuario();
    if ($u) {
        // Confere a cada página se o usuário continua ativo e com o mesmo perfil.
        $row = q('SELECT id, nome, login, perfil, ativo, trocar_senha FROM usuarios WHERE id = ?', [$u['id']])->fetch();
        if ($row && (int)$row['ativo'] === 1) {
            $_SESSION['u'] = $row;
            // Senha provisória ou fraca: só deixa usar a página de troca de senha.
            if ((int)$row['trocar_senha'] === 1 && !in_array(basename($_SERVER['SCRIPT_NAME'] ?? ''), ['senha.php', 'logout.php'], true)) {
                flash('Por segurança, defina uma nova senha para continuar.', 'erro');
                redirecionar('senha.php');
            }
            // Filial do ES: só a tela da filial (e trocar senha / sair).
            if ($row['perfil'] === 'filial_es' && !in_array(basename($_SERVER['SCRIPT_NAME'] ?? ''), ['es.php', 'foto.php', 'push.php', 'senha.php', 'logout.php'], true)) {
                redirecionar('es.php');
            }
            return;
        }
        $_SESSION = [];
    }
    redirecionar('login.php?volta=' . urlencode($_SERVER['REQUEST_URI'] ?? 'index.php'));
}

function pode_editar(): bool { return in_array(usuario()['perfil'] ?? '', ['admin', 'operador'], true); }
function e_admin(): bool { return (usuario()['perfil'] ?? '') === 'admin'; }
function e_filial_es(): bool { return (usuario()['perfil'] ?? '') === 'filial_es'; }
/** Quem pode usar a tela da filial do ES: a própria filial e os administradores. */
function pode_filial_es(): bool { return e_filial_es() || e_admin(); }

function exigir_edicao(): void
{
    if (!pode_editar()) { flash('Seu perfil é só de consulta. Peça a um administrador para liberar edição.', 'erro'); redirecionar('index.php'); }
}
function exigir_admin(): void
{
    if (!e_admin()) { flash('Área restrita a administradores.', 'erro'); redirecionar('index.php'); }
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));
    return $_SESSION['csrf'];
}
function csrf_campo(): string { return '<input type="hidden" name="csrf" value="' . csrf_token() . '">'; }
function csrf_validar(): void
{
    if (!hash_equals($_SESSION['csrf'] ?? '', (string)($_POST['csrf'] ?? ''))) {
        http_response_code(400);
        flash('A página expirou. Tente de novo.', 'erro');
        redirecionar('index.php');
    }
}

// ---------- proteção contra tentativas de senha (por IP, no banco) ----------
const LOGIN_MAX_FALHAS = 8;      // tentativas erradas...
const LOGIN_JANELA = 900;        // ...em 15 min bloqueiam o IP

function ip_cliente(): string { return substr((string)($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0'), 0, 45); }

function login_tabela(): void
{
    static $ok = false;
    if ($ok) return;
    db()->exec('CREATE TABLE IF NOT EXISTS login_falhas (id INT AUTO_INCREMENT PRIMARY KEY, ip VARCHAR(45) NOT NULL, criado_em DATETIME NOT NULL, KEY ix_ip (ip, criado_em)) ENGINE=InnoDB');
    $ok = true;
}
function login_bloqueado(): bool
{
    login_tabela();
    $desde = date('Y-m-d H:i:s', time() - LOGIN_JANELA);
    return (int)q('SELECT COUNT(*) FROM login_falhas WHERE ip = ? AND criado_em >= ?', [ip_cliente(), $desde])->fetchColumn() >= LOGIN_MAX_FALHAS;
}
function login_falhou(): void
{
    login_tabela();
    q('INSERT INTO login_falhas (ip, criado_em) VALUES (?, ?)', [ip_cliente(), date('Y-m-d H:i:s')]);
    q('DELETE FROM login_falhas WHERE criado_em < ?', [date('Y-m-d H:i:s', time() - 86400)]);
}
function login_ok(): void { login_tabela(); q('DELETE FROM login_falhas WHERE ip = ?', [ip_cliente()]); }

// ---------- política de senha ----------
/** Regra da senha: pelo menos 6 caracteres, com pelo menos 1 letra e 1 número. Devolve o motivo, ou null se estiver boa. */
function senha_invalida(string $senha, string $login = ''): ?string
{
    if (mb_strlen($senha) < 6) return 'A senha precisa ter pelo menos 6 caracteres.';
    if (!preg_match('/\pL/u', $senha) || !preg_match('/\d/', $senha)) return 'A senha precisa ter pelo menos 1 letra e 1 número.';
    return null;
}