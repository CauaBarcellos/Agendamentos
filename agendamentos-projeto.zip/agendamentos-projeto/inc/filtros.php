<?php
/** Monta o WHERE da aba Registros (também usado no exportar). */
function filtros_registros(array $g, string $emp): array
{
    $w = ['1=1'];
    $p = [];
    $h = hoje();
    if ($emp !== '') { $w[] = 'empresa = :emp'; $p[':emp'] = $emp; }

    $q = trim((string)($g['q'] ?? ''));
    if ($q !== '') {
        foreach (array_slice(preg_split('/\s+/u', $q), 0, 6) as $i => $pal) {
            $k = ":q$i";
            $w[] = "(fornecedor LIKE $k OR transportadora LIKE $k OR nota_fiscal LIKE $k OR produto LIKE $k OR observacao LIKE $k OR obs_vianna LIKE $k)";
            $p[$k] = '%' . $pal . '%';
        }
    }
    $st = (string)($g['st'] ?? '');
    $mapa = [
        'pend' => "entregue='N'",
        'atrasado' => "entregue='N' AND data_receber < :hs",
        'hoje' => "entregue='N' AND data_receber = :hs",
        'agendado' => "entregue='N' AND data_receber > :hs",
        'semdata' => "entregue='N' AND data_receber IS NULL",
        'entregue' => "entregue='S'",
        'divergencia' => "entregue='S' AND divergencia IS NOT NULL",
        'devolvida' => "entregue='D'",
    ];
    if (isset($mapa[$st])) {
        $w[] = $mapa[$st];
        if (strpos($mapa[$st], ':hs') !== false) $p[':hs'] = $h;
    }
    if (!empty($g['cat']) && in_array($g['cat'], CATEGORIAS, true)) { $w[] = 'categoria = :cat'; $p[':cat'] = $g['cat']; }
    if (!empty($g['tr'])) { $w[] = 'transportadora LIKE :tr'; $p[':tr'] = '%' . $g['tr'] . '%'; }
    if (!empty($g['uf']) && in_array($g['uf'], ['RJ', 'ES'], true)) { $w[] = 'uf = :uf'; $p[':uf'] = $g['uf']; }
    if (!empty($g['de']) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $g['de'])) { $w[] = 'data_receber >= :de'; $p[':de'] = $g['de']; }
    if (!empty($g['ate']) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $g['ate'])) { $w[] = 'data_receber <= :ate'; $p[':ate'] = $g['ate']; }

    $ordens = ['rc' => 'data_receber', 'dt' => 'data_agendamento', 'forn' => 'fornecedor', 'vol' => 'volumes_num'];
    $ord = $ordens[$g['ord'] ?? 'rc'] ?? 'data_receber';
    $dir = ($g['dir'] ?? 'desc') === 'asc' ? 'ASC' : 'DESC';
    return ['where' => implode(' AND ', $w), 'params' => $p, 'order' => "$ord $dir, id $dir"];
}

const ST_FILTRO = ['' => 'Todos', 'pend' => 'Não entregues', 'atrasado' => 'Atrasado', 'hoje' => 'Chega hoje', 'agendado' => 'Agendado', 'entregue' => 'Entregue', 'divergencia' => 'Com divergência', 'devolvida' => 'Devolvida', 'semdata' => 'Sem data'];
