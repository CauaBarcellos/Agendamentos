<?php
/**
 * Entrada de notas no RJ: conferência (volumes e divergências), fotos e busca pelo código de barras da NF-e.
 */

const FOTO_MAX_BYTES = 8 * 1024 * 1024;
const FOTO_MAX_POR_VEZ = 5;
const FOTO_TIPOS = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];

function uploads_dir(): string { return APP_DIR . '/uploads'; }

/**
 * Registra a entrada. Só grava se a nota ainda estava aguardando (duas pessoas não dão entrada na mesma nota).
 * $div = tipos separados por vírgula (null = chegou tudo certo).
 */
function receber_registrar(array $r, ?int $vol, ?string $div, ?string $obs): bool
{
    $uid = usuario()['id'];
    $st = q("UPDATE agendamentos SET entregue = 'S', entregue_em = ?, vol_recebidos = ?, divergencia = ?, divergencia_obs = ?, atualizado_por = ?, atualizado_em = ?
             WHERE id = ? AND entregue = 'N'", [agora(), $vol, $div, $obs, $uid, agora(), $r['id']]);
    if ($st->rowCount() !== 1) return false;
    $det = ['entregue' => [$r['entregue'], 'S']];
    if ($vol !== null && (string)$vol !== (string)$r['volumes_num']) $det['vol_recebidos'] = [$r['volumes_num'], $vol];
    if ($div) { $det['divergencia'] = [null, $div]; $det['divergencia_obs'] = [null, $obs]; }
    registrar_historico((int)$r['id'], 'entregue', $det);
    if ($div) {
        $eu = (int)(usuario()['id'] ?? 0);
        $txt = (titulo($r['fornecedor']) ?: 'Nota') . ($r['nota_fiscal'] ? ' · NF ' . $r['nota_fiscal'] : '') . ': ' . mb_strtolower(divergencia_txt($div)) . ($obs ? ' — ' . mb_substr($obs, 0, 120) : '');
        avisar(usuarios_com_perfil(['admin'], $eu), 'Entrada com divergência', $txt, 'agendamento.php?id=' . (int)$r['id'], 'div-' . $r['id']);
        if ($r['uf'] === 'ES') avisar(usuarios_com_perfil(['filial_es']), 'Chegou no RJ com divergência', $txt, 'es.php', 'div-' . $r['id']);
    }
    return true;
}

/** Salva as fotos enviadas (já vêm reduzidas pelo navegador). Devolve [quantas salvou, problemas]. */
function fotos_salvar(int $agId, array $arquivos): array
{
    $ok = 0;
    $probs = [];
    $fi = new finfo(FILEINFO_MIME_TYPE);
    foreach (array_slice($arquivos, 0, FOTO_MAX_POR_VEZ) as $f) {
        if (($f['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) continue;
        $nome = mb_substr((string)$f['name'], 0, 60);
        if ($f['error'] !== UPLOAD_ERR_OK) { $probs[] = "$nome: não chegou inteira."; continue; }
        if ($f['size'] > FOTO_MAX_BYTES) { $probs[] = "$nome: maior que 8 MB."; continue; }
        $tipo = $fi->file($f['tmp_name']);
        $dim = @getimagesize($f['tmp_name']);
        if (!isset(FOTO_TIPOS[$tipo]) || !$dim || $dim[0] > 12000 || $dim[1] > 12000) { $probs[] = "$nome: não é uma foto (use JPG, PNG ou WEBP)."; continue; }
        $sub = date('Y/m');
        $dir = uploads_dir() . '/' . $sub;
        if (!is_dir($dir) && !mkdir($dir, 0750, true)) { $probs[] = "$nome: não consegui salvar."; continue; }
        $arq = $sub . '/' . bin2hex(random_bytes(12)) . '.' . FOTO_TIPOS[$tipo];
        if (!move_uploaded_file($f['tmp_name'], uploads_dir() . '/' . $arq)) { $probs[] = "$nome: não consegui salvar."; continue; }
        q('INSERT INTO fotos (agendamento_id, arquivo, tipo, tamanho, criado_por, criado_em) VALUES (?,?,?,?,?,?)',
            [$agId, $arq, $tipo, (int)$f['size'], usuario()['id'] ?? null, agora()]);
        $ok++;
    }
    if ($ok) registrar_historico($agId, 'editou', ['fotos' => [null, $ok === 1 ? '1 foto' : "$ok fotos"]]);
    return [$ok, $probs];
}

function fotos_de(int $agId): array
{
    return q('SELECT id, criado_em FROM fotos WHERE agendamento_id = ? ORDER BY id', [$agId])->fetchAll();
}

/** Dígito verificador da chave de acesso (módulo 11) — pega leitura errada do código de barras. */
function chave_valida(string $c): bool
{
    if (!preg_match('/^\d{44}$/', $c)) return false;
    $soma = 0;
    $peso = 2;
    for ($i = 42; $i >= 0; $i--) { $soma += (int)$c[$i] * $peso; $peso = $peso === 9 ? 2 : $peso + 1; }
    $dv = 11 - ($soma % 11);
    return ($dv >= 10 ? 0 : $dv) === (int)$c[43];
}

/**
 * Procura a nota pelo que foi lido/digitado na portaria:
 *   chave de 44 dígitos (código de barras do DANFE) → número da NF → nome do fornecedor.
 * Devolve ['id' => n] quando é exatamente uma nota pela chave, ou ['itens' => [...], 'aviso' => '...'].
 */
function entrada_buscar(string $q): array
{
    $q = trim($q);
    $dig = preg_replace('/\D/', '', $q);
    $campos = 'id, fornecedor, transportadora, nota_fiscal, volumes, empresa, uf, data_receber, entregue, entregue_em, divergencia, chegou_es_em';
    $porNF = function (string $nf, string $extra = '') use ($campos): array {
        // a coluna pode ter várias NFs ("3697 / 3698"): procura o número inteiro, sem zeros à esquerda
        $nf = ltrim($nf, '0');
        if ($nf === '') return [];
        return q("SELECT $campos FROM agendamentos WHERE nota_fiscal REGEXP ? $extra
                  ORDER BY entregue = 'S', data_receber IS NULL, data_receber LIMIT 20", ['(^|[^0-9])0*' . $nf . '([^0-9]|$)'])->fetchAll();
    };

    if (strlen($dig) === 44 && strlen($q) <= 60) {
        if (!chave_valida($dig)) return ['itens' => [], 'aviso' => 'O código lido não confere (dígito verificador errado). Leia de novo ou digite o número da NF.'];
        $r = q("SELECT $campos FROM agendamentos WHERE chave_nfe = ? ORDER BY entregue = 'S' LIMIT 1", [$dig])->fetch();
        if ($r) return ['id' => (int)$r['id'], 'itens' => [$r], 'aviso' => ''];
        $nNF = substr($dig, 25, 9);
        $itens = $porNF($nNF);
        return ['itens' => $itens, 'aviso' => $itens ? 'A chave não estava gravada; achei pelo número da NF ' . ltrim($nNF, '0') . '. Confira o fornecedor.' : 'Nenhuma nota com a NF ' . ltrim($nNF, '0') . ' no portal.'];
    }
    if ($dig !== '' && $dig === preg_replace('/\s/', '', $q) && strlen($dig) <= 12) {
        $itens = $porNF($dig);
        return ['itens' => $itens, 'aviso' => $itens ? '' : "Nenhuma nota com a NF $dig."];
    }
    if (mb_strlen($q) >= 2) {
        $itens = q("SELECT $campos FROM agendamentos WHERE (fornecedor LIKE :t OR transportadora LIKE :t) AND (entregue = 'N' OR entregue_em >= :d)
                    ORDER BY entregue = 'S', data_receber IS NULL, data_receber LIMIT 20", [':t' => '%' . $q . '%', ':d' => soma_dias(hoje(), -7)])->fetchAll();
        return ['itens' => $itens, 'aviso' => $itens ? '' : 'Nenhuma nota aguardando com esse nome.'];
    }
    return ['itens' => [], 'aviso' => ''];
}

/**
 * Confere o que foi preenchido para uma nota. $in = vol_recebidos (texto), tudo_ok ('sim'|'nao'), tipos (lista), obs.
 * Devolve [dados, erros]; dados = ['vol' => ?int, 'div' => ?string, 'obs' => ?string, 'tipos' => [...]].
 */
function conferencia_validar(array $r, array $in): array
{
    $erros = [];
    $esperado = $r['volumes_num'] !== null ? (int)$r['volumes_num'] : null;
    $vol = trim((string)($in['vol_recebidos'] ?? ''));
    $vol = $vol === '' ? null : (preg_match('/^\d{1,8}$/', $vol) ? (int)$vol : -1);
    $ok = (string)($in['tudo_ok'] ?? '');
    $tipos = array_values(array_intersect(array_keys(DIVERG), (array)($in['tipos'] ?? [])));
    $obs = imp_cortar(trim((string)($in['obs'] ?? '')), 2000);

    if ($vol === -1) $erros[] = 'Volumes recebidos: use só números.';
    if (!in_array($ok, ['sim', 'nao'], true)) $erros[] = 'Diga se chegou tudo certo.';
    $difere = $esperado !== null && $vol !== null && $vol >= 0 && $vol !== $esperado;
    if (!$erros && $ok === 'sim' && $difere) {
        $erros[] = "Os volumes não batem (esperado $esperado, recebido $vol). Marque \"teve problema\" e explique.";
    }
    if (!$erros && $ok === 'nao') {
        if ($difere && !array_intersect($tipos, ['falta', 'sobra'])) $tipos[] = $vol < $esperado ? 'falta' : 'sobra';
        if (!$tipos) $erros[] = 'Marque qual foi o problema.';
        if (mb_strlen($obs) < 3) $erros[] = 'Descreva o problema em poucas palavras.';
    }
    $div = $ok === 'nao' && $tipos ? implode(',', $tipos) : null;
    return [['vol' => $vol !== null && $vol >= 0 ? $vol : null, 'div' => $div, 'obs' => $div ? $obs : null, 'tipos' => $tipos, 'tudo_ok' => $ok, 'obs_digitada' => $obs], $erros];
}

/** A nota pode receber entrada agora? (aguardando; nota do ES só depois de o RJ escolher o dia) */
function pode_receber(array $r): bool
{
    return $r['entregue'] === 'N' && !($r['uf'] === 'ES' && !$r['data_receber']);
}
