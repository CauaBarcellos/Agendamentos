<?php
// Ações rápidas vindas da agenda: marcar entregue (uma ou várias) e desfazer.
// Responde JSON quando chamado pelo JavaScript da agenda (cabeçalho X-Requested-With), senão redireciona.
require __DIR__ . '/inc/bootstrap.php';

$ajax = ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'fetch';
function responder(bool $ajax, bool $ok, string $msg, string $volta, array $extra = []): void
{
    if ($ajax) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['ok' => $ok, 'msg' => $msg] + $extra, JSON_UNESCAPED_UNICODE);
        exit;
    }
    flash($msg, $ok ? 'ok' : 'erro');
    redirecionar($volta);
}

if ($ajax && !usuario()) { http_response_code(401); responder(true, false, 'Sessão expirada. Entre de novo.', 'login.php'); }
exigir_login();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirecionar('index.php');
if ($ajax && !hash_equals($_SESSION['csrf'] ?? '', (string)($_POST['csrf'] ?? ''))) { http_response_code(400); responder(true, false, 'A página expirou. Atualize e tente de novo.', 'index.php'); }
if (!$ajax) csrf_validar();
if (!pode_editar()) {
    if ($ajax) { http_response_code(403); responder(true, false, 'Seu perfil é só de consulta.', 'index.php'); }
    exigir_edicao();
}

$volta = volta_segura($_POST['volta'] ?? '');
$acao = (string)($_POST['acao'] ?? '');

function avisar_es_dia(array $r, string $dia, bool $mudou): void
{
    avisar(usuarios_com_perfil(['filial_es']), $mudou ? 'O RJ mudou o dia' : 'O RJ pediu uma nota', (titulo($r['fornecedor']) ?: 'Nota') . ': enviar para chegar no RJ ' . dia_curto($dia) . '.', 'es.php', 'es-dia-' . $r['id']);
}
// Nota que chegou na filial do ES: o Rio escolhe o dia de receber, e ela entra na agenda desse dia.
if ($acao === 'receber_es') {
    $id = (int)($_POST['id'] ?? 0);
    $dia = (string)($_POST['data_receber'] ?? '');
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $dia) || !strtotime($dia) || $dia < hoje()) responder($ajax, false, 'Escolha hoje ou um dia futuro para receber.', $volta);
    $r = q('SELECT id, fornecedor, uf, entregue, chegou_es_em, data_receber FROM agendamentos WHERE id = ?', [$id])->fetch();
    // "de" = dia que a pessoa estava vendo; se outra pessoa mudou nesse meio-tempo, não sobrescreve.
    if (!$r || $r['uf'] !== 'ES' || !$r['chegou_es_em'] || $r['entregue'] !== 'N' || (string)$r['data_receber'] !== (string)($_POST['de'] ?? '')) {
        responder($ajax, false, 'Essa nota mudou enquanto você olhava (outra pessoa pode ter agendado). Confira e tente de novo.', $volta);
    }
    q('UPDATE agendamentos SET data_receber = ?, atualizado_por = ?, atualizado_em = ? WHERE id = ?', [$dia, usuario()['id'], agora(), $id]);
    registrar_historico($id, 'editou', ['data_receber' => [$r['data_receber'], $dia]]);
    avisar_es_dia($r, $dia, (bool)$r['data_receber']);
    responder($ajax, true, (titulo($r['fornecedor']) ?: 'A nota') . ' vai ser recebida no Rio em ' . br($dia) . '.', $volta, ['ids' => [$id], 'n' => 1]);
}

// Reagendar pelo calendário (arrastar a nota para outro dia, ou "Mudar dia").
// Notas do ES: só depois de chegarem no ES (o dia de receber é a única coisa que o RJ decide nelas).
if ($acao === 'reagendar') {
    $id = (int)($_POST['id'] ?? 0);
    $dia = (string)($_POST['data_receber'] ?? '');
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $dia) || !checkdate((int)substr($dia, 5, 2), (int)substr($dia, 8, 2), (int)substr($dia, 0, 4)) || $dia < hoje()) {
        responder($ajax, false, 'Escolha hoje ou um dia futuro.', $volta);
    }
    $r = q('SELECT id, fornecedor, uf, entregue, chegou_es_em, data_receber FROM agendamentos WHERE id = ?', [$id])->fetch();
    if (!$r || $r['entregue'] !== 'N') responder($ajax, false, 'Essa nota já foi recebida ou não existe mais.', $volta);
    if ($r['uf'] === 'ES' && !$r['chegou_es_em']) responder($ajax, false, 'Nota do ES: o dia só pode ser escolhido depois que ela chegar no ES.', $volta);
    if ((string)$r['data_receber'] !== (string)($_POST['de'] ?? '')) {
        responder($ajax, false, 'Essa nota mudou enquanto você olhava (outra pessoa pode ter mudado o dia). Confira e tente de novo.', $volta);
    }
    $nome = titulo($r['fornecedor']) ?: 'A nota';
    if ($r['data_receber'] === $dia) responder($ajax, true, "$nome já estava em " . br($dia) . '.', $volta, ['ids' => [], 'n' => 0, 'dia' => $dia]);
    q('UPDATE agendamentos SET data_receber = ?, atualizado_por = ?, atualizado_em = ? WHERE id = ?', [$dia, usuario()['id'], agora(), $id]);
    registrar_historico($id, 'editou', ['data_receber' => [$r['data_receber'], $dia]]);
    if ($r['uf'] === 'ES') avisar_es_dia($r, $dia, (bool)$r['data_receber']);
    responder($ajax, true, "$nome passou para " . dia_curto($dia) . '.', $volta, ['ids' => [$id], 'n' => 1, 'dia' => $dia, 'antes' => $r['data_receber']]);
}

// Um id (campo "id") ou vários ("ids[]"); no máximo 500 por vez.
$ids = array_values(array_unique(array_merge(array_map('intval', (array)($_POST['ids'] ?? [])), [(int)($_POST['id'] ?? 0)])));
$ids = array_slice(array_filter($ids), 0, 500);
if (!$ids) responder($ajax, false, 'Nenhuma nota selecionada.', $volta);

$marcadas = [];
foreach ($ids as $id) {
    $r = q('SELECT id, fornecedor, entregue, uf, data_receber FROM agendamentos WHERE id = ?', [$id])->fetch();
    if (!$r) continue;
    if ($r['uf'] === 'ES' && !$r['data_receber'] && $acao !== 'desfazer') continue; // nota do ES: só dá entrada depois de escolher o dia
    if (in_array($acao, ['entregue', 'entregue_grupo'], true) && $r['entregue'] !== 'S') {
        q("UPDATE agendamentos SET entregue='S', entregue_em=?, vol_recebidos=volumes_num, atualizado_por=?, atualizado_em=? WHERE id=?", [agora(), usuario()['id'], agora(), $id]);
        registrar_historico($id, 'entregue', ['entregue' => [$r['entregue'], 'S']]);
        $marcadas[] = $id;
    } elseif ($acao === 'desfazer' && $r['entregue'] === 'S') {
        q("UPDATE agendamentos SET entregue='N', entregue_em=NULL, vol_recebidos=NULL, divergencia=NULL, divergencia_obs=NULL, atualizado_por=?, atualizado_em=? WHERE id=?", [usuario()['id'], agora(), $id]);
        registrar_historico($id, 'reabriu', ['entregue' => ['S', 'N']]);
        $marcadas[] = $id;
    }
}

$n = count($marcadas);
if ($acao === 'desfazer') $msg = $n === 1 ? 'Nota reaberta.' : "$n notas reabertas.";
elseif ($n === 1) { $r = q('SELECT fornecedor FROM agendamentos WHERE id = ?', [$marcadas[0]])->fetch(); $msg = (titulo($r['fornecedor'] ?? '') ?: 'Nota') . ' marcado como entregue.'; }
else $msg = $n ? "$n notas marcadas como entregues." : 'Nada para alterar.';
responder($ajax, true, $msg, $volta, ['ids' => $marcadas, 'n' => $n]);
