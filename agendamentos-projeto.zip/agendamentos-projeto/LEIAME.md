# Portal de Agendamentos de Fornecedor

Sistema PHP + MySQL para o recebimento de fornecedores da Green Med, Estevia e Essencial.
Substitui a planilha AGENDAMENTOS FORNECEDOR. Várias pessoas usam ao mesmo tempo, cada uma com o seu login.

## Requisitos
- PHP 8.0 ou superior (recomendado 8.2), com as extensões `pdo_mysql`, `mbstring` e `openssl` (avisos no celular)
- MySQL 5.7+ ou MariaDB 10.3+
- Servidor web: Apache (XAMPP, HostGator) ou IIS (Windows Server)

## Instalação (Windows Server com XAMPP)
1. Instale o XAMPP e ligue **Apache** e **MySQL** no painel.
2. Copie a pasta `agendamentos` para `C:\xampp\htdocs\`.
3. Abra `config.php` e confira os dados do MySQL. No XAMPP padrão: usuário `root`, senha vazia.
4. No navegador do servidor, abra `http://localhost/agendamentos/install.php`.
5. Crie o seu usuário administrador. Deixe marcado "Importar as notas da planilha".
6. **Apague** o arquivo `install.php` e a pasta `dados/`.
7. Nos outros computadores da rede, acesse `http://NOME-OU-IP-DO-SERVIDOR/agendamentos`.
   - Se não abrir, libere a porta 80 no Firewall do Windows do servidor.

## Instalação no IIS (sem XAMPP)
- Instale o PHP pelo Web Platform Installer ou manualmente (FastCGI) e o MySQL/MariaDB.
- Crie um site ou aplicativo apontando para a pasta `agendamentos`.
- O arquivo `web.config` já bloqueia o acesso direto às pastas `inc`, `dados` e `sql`.
- Depois siga do passo 3 em diante.

## Instalação na HostGator (ou outra hospedagem cPanel)
1. No cPanel, crie um banco MySQL e um usuário, e dê todas as permissões do usuário no banco.
2. Envie a pasta pelo Gerenciador de Arquivos (ex.: `public_html/agendamentos`).
3. Coloque em `config.php` o nome do banco, o usuário e a senha criados. Na HostGator o nome costuma ter prefixo, ex.: `conta_agendamentos`.
4. Abra `https://seudominio.com.br/agendamentos/install.php` e siga os passos 5 e 6 acima.

## Perfis de acesso
| Perfil | O que pode fazer |
|---|---|
| Administrador | Tudo, inclusive cadastrar usuários, ver o histórico geral e excluir agendamentos |
| Operador | Criar, editar e dar baixa em agendamentos |
| Leitor | Só consultar |
| Filial ES | Só a tela da filial (`es.php`): registra as notas que chegaram no ES, vê o dia em que o RJ pediu cada uma e vê quando chegaram no RJ. Não vê a agenda do RJ. |

## Como usar
- **Agenda:** escolha o dia à esquerda. As notas aparecem agrupadas por transportadora. O ✓ dá baixa na hora (com botão **Desfazer**), "Receber todas" dá baixa em toda a transportadora, e o campo de busca filtra o dia (Enter procura em todos os dias). O botão **Imprimir** gera a folha do dia com caixinhas para conferir.
- **Novo agendamento:** botão verde no topo.
- **App no celular:** no menu do usuário (a letra no canto), **"Instalar o app no celular"** (Android/Chrome). No iPhone: Safari → **Compartilhar** → **Adicionar à Tela de Início**. Abre em tela cheia com o ícone "Agendamentos"; sem internet mostra uma página "Sem conexão".
- **Avisos no celular:** no mesmo menu, **"Ativar avisos neste aparelho"** e depois **"Enviar aviso de teste"**. Cada pessoa ativa no próprio celular. Avisos: o RJ é avisado quando o ES registra uma chegada; o ES quando o RJ escolhe (ou muda) o dia; administradores (e o ES, se a nota for dele) quando uma entrada tem divergência; e o RJ recebe de manhã o resumo das atrasadas. Quem fez a ação não recebe o próprio aviso. No iPhone precisa do iOS 16.4+ e de abrir pelo app instalado. Só funciona com o site em **https**. Não usa serviço pago (padrão Web Push dos navegadores).
- **Calendário (aba no topo; no celular, atalho na lista de dias da agenda):** visão do **mês** (quantas notas e volumes por dia, cor mais forte nos dias mais cheios, ✓ recebidas, ! que ficaram para trás, ⚠ com divergência; clique no dia abre a agenda) e da **semana** (as notas de cada dia). Na semana dá para **arrastar** uma nota para outro dia, inclusive da bandeja "Sem data", "Atrasadas" e "Chegaram no ES"; ou usar **"Mudar dia"** em cada nota (celular e teclado). Só dias de hoje em diante; nota do ES só depois de chegar lá; se outra pessoa mudou antes, aparece um aviso e nada é sobrescrito. O perfil Leitor só vê. O calendário se atualiza sozinho (como a agenda) quando outra pessoa muda algo, mas espera você terminar se estiver arrastando ou com "Mudar dia" aberto.
- **Dar entrada (portaria):** botão "Dar entrada" no topo (no celular, aba "Entrada"). Leia o código de barras do DANFE com a câmera do celular ou com um leitor USB, ou digite o número da NF / o fornecedor. Com a chave da NF-e cadastrada, a nota abre direto; senão o portal acha pelo número da NF. Na conferência: volumes recebidos, "Chegou tudo certo?" e, se não, o que houve (falta, avaria, sobra, produto errado, outro) com explicação e fotos (avaria, canhoto). A nota fica como "Recebida c/ divergência" (filtro em Registros, coluna no CSV) e a filial ES vê a divergência das notas dela. O ✓ da agenda continua sendo a baixa rápida "chegou tudo certo".
  - A câmera só funciona com o site em **https**. No Android usa o leitor do próprio Chrome; no iPhone e nos outros, a biblioteca ZXing (`assets/vendor/`, licença Apache 2.0).
- **Registros:** todas as notas, com busca, filtros, ordenação e exportação para CSV (abre no Excel).
- **Detalhe da nota:** clique em qualquer linha para ver, editar, dar baixa e ver o histórico de alterações.
- **Reabrir nota:** no detalhe de uma nota recebida, "Reabrir (desfazer baixa)".
- **Importar notas (botão "Importar"):** arraste XMLs de NF-e, um ZIP com vários XMLs, uma planilha `.xlsx`/`.csv` (há um modelo para baixar na tela) ou cole linhas do Excel. Aparece uma **prévia** onde dá para corrigir empresa, data, volumes etc., desmarcar notas e aplicar data/empresa em todas de uma vez; só grava ao confirmar. Notas já cadastradas (mesma chave da NF-e ou mesmo fornecedor + número) vêm marcadas como "Já cadastrada" e desmarcadas. Limite de 500 notas por importação. Se a planilha tiver uma coluna **Recebido** (data em que chegou, ou "sim"), as notas que já existem no portal e ainda estão aguardando aparecem com "Dar entrada: Atrasado → Recebida em …" para você confirmar: o portal dá entrada nelas (não cria outra) e registra no histórico que veio da planilha. Notas novas com Recebido já entram como recebidas. Para o sistema reconhecer a empresa pelo CNPJ do destinatário, preencha `cnpj_empresas` no config.php.
- **Agenda ao vivo:** a agenda se atualiza sozinha quando outra pessoa dá baixa ou cadastra (consulta leve a cada 8 s, só com a aba visível). O filtro digitado e os grupos recolhidos são mantidos. Se a conexão cair aparece um aviso. Para mudar o intervalo, descomente `'agenda_intervalo'` no config.php (3 a 300 segundos).
- **Sem F5:** Registros, Filial ES, Recebidas ES e o Painel/Histórico do admin também se atualizam sozinhos (só as listas; o que a pessoa está digitando não é mexido). Quando sobem arquivos novos do site, as páginas abertas se recarregam sozinhas na versão nova, menos se houver formulário com algo digitado (aí esperam a pessoa salvar ou sair).
- **Notas do ES (regra):** só a filial do ES cadastra notas do ES, registrando quando chegam lá. O RJ não cadastra nem edita nota do ES (no Novo agendamento não há UF; na importação, notas com destino ES ficam travadas). O RJ só vê, escolhe o dia de receber e dá entrada quando chega. O administrador pode tudo.
- **Fluxo:** ES registra "chegou" → no RJ aparece em Pendências "Chegaram no ES" → o RJ escolhe o dia (e pode mudar no detalhe da nota) → o ES vê em "O RJ pediu para enviar" → o RJ dá entrada na agenda → o ES vê em "Chegaram no RJ" e a nota vai para Recebidas ES.
- **Admin (`/admin/`):** área separada, sem link no portal, com login próprio só para administradores. Tem Usuários (criar, editar, redefinir senha), Painel (números e gráficos), Histórico (filtros e CSV), Planilha e Backup.
- **Planilha nova (Admin > Planilha):** troca as notas que vieram da planilha do Excel pelas de uma planilha nova, mantendo as criadas pelo site. Gere o arquivo no computador com `php ferramentas/converter_planilha.php "AGENDAMENTOS FORNECEDOR.xlsx" planilha.json`, envie, confira a prévia e digite SUBSTITUIR. Um backup do banco é feito antes.

## Arquivos
```
agendamentos/
├── index.php          Agenda
├── registros.php      Todas as notas (busca e filtros)
├── recebidas.php      Recebidas do ES
├── agendamento.php    Detalhe, novo, editar, excluir
├── acao.php           Baixa rápida pela agenda
├── exportar.php       CSV
├── admin/             Área restrita: usuários e histórico (login próprio)
├── login.php, logout.php, senha.php
├── install.php        Instalador (apagar depois)
├── config.php         Dados do banco (não vai para o Git; veja config.exemplo.php)
├── backup_cron.php    Backup diário automático (cron do cPanel)
├── es.php             Tela da filial do ES (avisar chegada)
├── push.php           Avisos no celular: ativar, desativar, aviso de teste
├── avisos_cron.php    Resumo das atrasadas (cron de manhã)
├── sw.js, manifest.webmanifest, offline.html   App instalável
├── calendario.php     Calendário do mês e da semana (arrastar para reagendar)
├── entrada.php        Portaria: código de barras / NF → conferência
├── receber.php        Conferência do recebimento (volumes, divergência, fotos)
├── foto.php           Mostra as fotos (só para quem está logado)
├── uploads/           Fotos do recebimento (bloqueada para o navegador)
├── importar.php       Importação de NF-e (XML/ZIP), planilha e texto colado
├── estado.php         Consulta leve usada pelas páginas ao vivo
├── ferramentas/       converter_planilha.php: Excel → planilha.json (só pelo terminal; bloqueada para o navegador)
├── tests/             smoke.php (testes), browser/ (Chrome automatizado); tudo: sh tests/rodar_tudo.sh
├── inc/               Funções internas (protegido)
├── sql/schema.sql     Estrutura do banco
├── dados/             Dados da planilha para importar (apagar depois)
└── assets/            CSS e JS
```

## Backup
- **Automático:** no cPanel → Tarefas Cron → uma vez por dia:
  `/usr/local/bin/php /home/SUACONTA/public_html/agendamentos/backup_cron.php` (guarda os 14 mais recentes em `backups/`).
- **Manual:** `/admin/` → Backup → Baixar backup, ou phpMyAdmin → Exportar.
- Para restaurar, importe o arquivo `.sql` no phpMyAdmin.
- **Resumo das atrasadas no celular:** outra tarefa cron, todo dia às 7h (minuto 0, hora 7): `/usr/local/bin/php /home2/SUACONTA/public_html/agendamentos/avisos_cron.php`.
- **Fotos do recebimento** ficam na pasta `uploads/` e não vão no backup do banco: entram no backup completo do cPanel (Backup → Baixar backup da pasta pessoal). A pasta precisa permitir escrita pelo PHP (o padrão do cPanel já permite).

## Segurança
- HTTPS obrigatório fora do localhost; cabeçalhos de segurança; bloqueio de IP após 8 senhas erradas em 15 min.
- Senhas: mínimo 6 caracteres, com pelo menos 1 letra e 1 número. Senha provisória obriga a trocar no primeiro acesso.
- Antes de publicar: apague `install.php` e `dados/`, use usuário de banco exclusivo e rode `php tests/smoke.php`.
- **SQL injection:** todas as consultas usam parâmetros (`?`/`:nome`) e o MySQL faz a preparação de verdade (`ATTR_EMULATE_PREPARES` desligado em `inc/db.php`). Colunas de ordenação vêm de listas fixas. O teste `tests/browser/sqli.mjs` dispara dezenas de ataques típicos em todas as buscas, filtros, formulários, importação e telas do admin, e confere que nada quebra, nada vaza e nenhum dado muda.
- **No cPanel:** crie o usuário do banco só com SELECT, INSERT, UPDATE e DELETE. O portal cria colunas novas sozinho na primeira execução (ALTER), então deixe também ALTER/CREATE/INDEX até abrir o site uma vez depois de cada atualização, e depois pode retirá-los.
- **Escrevendo consultas novas:** nunca cole variável dentro do SQL. Use `q('... WHERE x = ?', [$valor])`. O mesmo `:nome` pode se repetir na consulta; o `q()` cuida disso.
