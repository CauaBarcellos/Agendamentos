<?php
// Instalador: cria o banco, as tabelas, importa as notas da planilha e cria o primeiro administrador.
// APAGUE este arquivo (e a pasta dados/) depois de instalar.
declare(strict_types=1);
define('APP_DIR', __DIR__);
$CONFIG = require __DIR__ . '/config.php';
date_default_timezone_set($CONFIG['timezone'] ?? 'America/Sao_Paulo');
require __DIR__ . '/inc/helpers.php';
require __DIR__ . '/inc/auth.php'; // regra da senha (senha_invalida)

$c = $CONFIG['db'];
$msg = [];
$erro = '';
$feito = false;

function conectar(array $c, bool $comBanco): PDO
{
    $dsn = "mysql:host={$c['host']};port={$c['port']};charset=utf8mb4" . ($comBanco ? ";dbname={$c['nome']}" : '');
    return new PDO($dsn, $c['usuario'], $c['senha'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
}

try {
    try {
        $pdo = conectar($c, true);
    } catch (PDOException $e) {
        if ((int)($e->errorInfo[1] ?? 0) !== 1049) throw $e; // 1049 = banco não existe
        $tmp = conectar($c, false);
        $tmp->exec('CREATE DATABASE `' . str_replace('`', '', $c['nome']) . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
        $pdo = conectar($c, true);
        $msg[] = "Banco “{$c['nome']}” criado.";
    }
    foreach (array_filter(array_map('trim', preg_split('/;\s*$/m', preg_replace('/^--.*$/m', '', file_get_contents(__DIR__ . '/sql/schema.sql'))))) as $sql) {
        $pdo->exec($sql);
    }
    $jaInstalado = (int)$pdo->query('SELECT COUNT(*) FROM usuarios')->fetchColumn() > 0;
} catch (PDOException $e) {
    $erro = isset($pdo)
        ? 'Erro ao criar as tabelas: ' . $e->getMessage()
        : 'Não consegui conectar ao MySQL: ' . $e->getMessage() . '. Confira host, usuário e senha em config.php.';
    $jaInstalado = false;
}

if ($jaInstalado) {
    http_response_code(403);
    exit('<p style="font-family:system-ui;padding:24px">Já instalado. Por segurança, apague o arquivo <b>install.php</b> e a pasta <b>dados/</b> do servidor.</p>');
}

if (!$erro && !$jaInstalado && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim((string)($_POST['nome'] ?? ''));
    $login = mb_strtolower(trim((string)($_POST['login'] ?? '')));
    $senha = (string)($_POST['senha'] ?? '');
    if ($nome === '' || !preg_match('/^[a-z0-9._-]{3,50}$/', $login) || senha_invalida($senha) !== null) {
        $erro = 'Preencha nome, um usuário válido (letras minúsculas, números, ponto) e uma senha com pelo menos 6 caracteres, com 1 letra e 1 número.';
    } else {
        @set_time_limit(300);
        $pdo->beginTransaction();
        try {
            $agora = date('Y-m-d H:i:s');
            $importar = isset($_POST['importar']) && is_file(__DIR__ . '/dados/planilha.json');
            if ($importar && (int)$pdo->query('SELECT COUNT(*) FROM agendamentos')->fetchColumn() === 0) {
                $dados = json_decode(file_get_contents(__DIR__ . '/dados/planilha.json'), true);
                $st = $pdo->prepare('INSERT INTO agendamentos (linha_planilha,data_agendamento,empresa,uf,transportadora,fornecedor,filial,produto,categoria,nota_fiscal,volumes,volumes_num,data_receber,ref_interna,entregue,observacao,email_enviado,obs_vianna,origem,criado_em)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,\'planilha\',?)');
                $nul = fn($v) => ($v === '' || $v === null) ? null : $v;
                foreach ($dados['agendamentos'] as $a) {
                    [$linha, $dt, $emp, $uf, $tr, $fo, $fil, $prod, $cat, $nf, $vol, $volN, $rc, $ref, $ent, $obs, $email, $obs2] = $a;
                    $st->execute([$linha, $nul($dt), (string)$emp, $uf ?: 'RJ', $nul($tr), $nul($fo), $nul($fil), $nul($prod), $cat, $nul($nf), $nul($vol), $volN, $nul($rc), $nul($ref), $ent ?: 'N', $nul($obs), $nul($email), $nul($obs2), $agora]);
                }
                $st = $pdo->prepare('INSERT INTO recebidas_es (linha_planilha,data_emissao,transportadora,fornecedor,material,nota_fiscal,volumes,status,data_recebido_rj,observacao) VALUES (?,?,?,?,?,?,?,?,?,?)');
                foreach ($dados['recebidas'] as $r) {
                    $st->execute(array_map($nul, $r));
                }
                $msg[] = n(count($dados['agendamentos'])) . ' agendamentos e ' . n(count($dados['recebidas'])) . ' notas recebidas do ES importados da planilha.';
            }
            $pdo->prepare('INSERT INTO usuarios (nome, login, senha_hash, perfil, ativo, criado_em) VALUES (?,?,?,?,1,?)')
                ->execute([$nome, $login, password_hash($senha, PASSWORD_DEFAULT), 'admin', $agora]);
            $pdo->commit();
            $msg[] = "Administrador “{$login}” criado.";
            $feito = true;
        } catch (Throwable $e) {
            $pdo->rollBack();
            $erro = 'Erro na instalação: ' . $e->getMessage();
        }
    }
}
?><!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Instalação · Agendamentos</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Figtree:wght@400;500;600;700&display=swap">
<link rel="stylesheet" href="assets/style.css?v=1">
</head>
<body class="loginpage">
<main class="logincard wide">
  <div class="brand"><span class="mark"><?= icone('caminhao', 18) ?></span><b>Agendamentos</b></div>
  <h1>Instalação</h1>
  <?php foreach ($msg as $m): ?><div class="flash ok"><?= e($m) ?></div><?php endforeach; ?>
  <?php if ($erro): ?><div class="flash erro"><?= e($erro) ?></div><?php endif; ?>

  <?php if ($feito): ?>
    <p>Pronto. Agora:</p>
    <ol class="steps">
      <li><b>Apague</b> o arquivo <code>install.php</code> e a pasta <code>dados/</code> do servidor.</li>
      <li><a href="login.php">Entre no portal</a> com o usuário que você acabou de criar.</li>
      <li>Cadastre a equipe em <b>Usuários</b>.</li>
    </ol>
  <?php elseif ($jaInstalado): ?>
    <p>O portal já está instalado. Por segurança, <b>apague o arquivo install.php</b> e a pasta <code>dados/</code> do servidor.</p>
    <p><a class="btn primary" href="login.php">Ir para o login</a></p>
  <?php elseif (isset($pdo)): ?>
    <p class="muted">Conectado ao banco <b><?= e($c['nome']) ?></b> em <?= e($c['host']) ?>. Crie o primeiro administrador.</p>
    <form method="post" class="form1">
      <div class="field"><label for="nome">Seu nome</label><input id="nome" name="nome" required value="<?= e($_POST['nome'] ?? '') ?>"></div>
      <div class="field"><label for="login">Usuário</label><input id="login" name="login" required placeholder="ex.: caua" value="<?= e($_POST['login'] ?? '') ?>"></div>
      <div class="field"><label for="senha">Senha</label><input id="senha" name="senha" type="password" required minlength="6"></div>
      <?php if (is_file(__DIR__ . '/dados/planilha.json')): ?>
      <label class="checkline"><input type="checkbox" name="importar" value="1" checked> Importar as notas da planilha AGENDAMENTOS FORNECEDOR (arquivo dados/planilha.json)</label>
      <?php endif; ?>
      <button class="btn primary full" type="submit">Instalar</button>
    </form>
  <?php endif; ?>
</main>
</body>
</html>
