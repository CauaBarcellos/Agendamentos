﻿PORTAL DE AGENDAMENTOS DE FORNECEDOR
====================================

  Português (Brasil) ........ parte 1
  English ................... part 2

Esta cópia NÃO tem dados sensíveis: não tem config.php (senhas do banco),
nem a planilha da empresa (dados/), nem backups, nem fotos de recebimento.
This copy has NO sensitive data: no config.php (database passwords), no
company spreadsheet (dados/), no backups and no delivery photos.


######################################################################
PARTE 1 - PORTUGUÊS (BRASIL)
######################################################################

O QUE É
-------
Site (PHP + MySQL) para controlar o recebimento de mercadorias de
fornecedores das empresas Alfa Med, Beta Saúde e Gama Farma, no RJ e na
filial do ES. Substitui a planilha "AGENDAMENTOS FORNECEDOR". Várias
pessoas usam ao mesmo tempo, cada uma com o seu login, no computador ou
no celular.


1. O QUE PRECISA
----------------
- PHP 8.0 ou mais novo (recomendado 8.2), com as extensões pdo_mysql,
  mbstring e openssl.
- MySQL 5.7+ ou MariaDB 10.3+.
- Servidor web Apache (XAMPP, HostGator/cPanel) ou IIS.
- HTTPS (cadeado) no site publicado. Sem HTTPS não funcionam a câmera
  (código de barras) nem os avisos no celular.


2. RODAR NO COMPUTADOR (XAMPP, para testar)
-------------------------------------------
1. Instale o XAMPP e ligue "Apache" e "MySQL" no painel do XAMPP.
2. Copie a pasta do projeto para C:\xampp\htdocs\agendamentos
3. Copie o arquivo config.exemplo.php com o nome config.php.
   No XAMPP padrão os dados do banco já servem (usuário root, senha vazia).
4. Abra no navegador: http://localhost/agendamentos/install.php
   O instalador cria o banco e as tabelas.
5. Crie o primeiro usuário administrador (nome, usuário e senha).
6. Entre em http://localhost/agendamentos/
7. Outros computadores da mesma rede: http://IP-DO-COMPUTADOR/agendamentos
   (se não abrir, libere a porta 80 no Firewall do Windows).


3. PUBLICAR NA INTERNET (HostGator ou outra hospedagem com cPanel)
-----------------------------------------------------------------
1. No cPanel > "Bancos de dados MySQL": crie um banco e um usuário e
   dê TODAS as permissões desse usuário no banco.
   (Na HostGator o nome ganha um prefixo, ex.: conta_agendamentos.)
2. No cPanel > "MultiPHP Manager": deixe o domínio em PHP 8.2.
3. No cPanel > "Gerenciador de Arquivos": envie a pasta do projeto para
   public_html/agendamentos (dá para enviar um .zip e usar "Extrair").
4. Copie config.exemplo.php para config.php e coloque nele o nome do
   banco, o usuário e a senha criados no passo 1.
5. Abra https://SEUDOMINIO/agendamentos/install.php e crie o
   administrador.
6. IMPORTANTE: apague o arquivo install.php depois de instalar.
7. Tarefas agendadas (cPanel > "Tarefas Cron"), troque SUACONTA:
   - Backup diário do banco (ex.: todo dia às 3h):
       /usr/local/bin/php /home/SUACONTA/public_html/agendamentos/backup_cron.php
     Guarda os 14 backups mais recentes na pasta backups/.
   - Resumo das notas atrasadas no celular (todo dia às 7h):
       /usr/local/bin/php /home/SUACONTA/public_html/agendamentos/avisos_cron.php
   (Em algumas contas o caminho é /home2/SUACONTA/...; o cPanel mostra o
   caminho certo no topo do Gerenciador de Arquivos.)

Opcional - carregar as notas da planilha do Excel na instalação:
  No computador, com PHP instalado, rode:
    php ferramentas/converter_planilha.php "AGENDAMENTOS FORNECEDOR.xlsx" planilha.json
  Coloque o planilha.json na pasta dados/ antes do install.php e deixe
  marcada a opção "Importar as notas da planilha". Depois apague dados/.
  Com o site já funcionando, use Admin > Planilha (veja abaixo).

Atualizar o site depois:
  Envie os arquivos novos por cima, SEM substituir o config.php.
  O banco é atualizado sozinho (colunas novas) na primeira visita, e as
  páginas abertas se recarregam sozinhas na versão nova.


4. CONFIGURAÇÕES (config.php)
-----------------------------
- db: servidor, porta, nome do banco, usuário e senha do MySQL.
- cnpj_empresas: CNPJ do destinatário -> empresa (para a importação de
  NF-e reconhecer a empresa). Opcional.
- forcar_https: manda http para https (ignorado em localhost).
- timezone: fuso horário (padrão America/Sao_Paulo).
- por_pagina: linhas por página na tela Registros.
- agenda_intervalo: de quantos em quantos segundos as páginas conferem
  se alguém mudou algo (padrão 8; de 3 a 300).


5. PERFIS DE USUÁRIO
--------------------
- Administrador: tudo, inclusive usuários, histórico geral e excluir notas.
- Operador: cria, edita e dá entrada nas notas do RJ.
- Leitor: só consulta.
- Filial ES: só a tela da filial do ES (registra o que chegou lá).
Usuários são criados em /agendamentos/admin/ (área com login próprio, só
para administradores). Quem recebe senha provisória troca no 1º acesso.
Regra da senha: pelo menos 6 caracteres, com 1 letra e 1 número.


6. FUNCIONALIDADES
------------------
Agenda do dia
- Lista de dias à esquerda (atrasados, hoje, próximos, sem data) e as
  notas do dia agrupadas por transportadora.
- Números no topo: atrasados, chegam hoje, próximos 7 dias, aguardando
  e entregues no mês. Filtro por empresa (Todas, Alfa Med, Beta Saúde,
  Gama Farma).
- Busca por fornecedor ou NF. Botão Imprimir (folha do dia para conferir).
- O botão de check abre a conferência; "Receber todas" confere a
  transportadora inteira de uma vez. Toda baixa tem "Desfazer".

Dar entrada (portaria) e conferência
- Ler o código de barras da DANFE com a câmera do celular ou leitor USB,
  ou digitar a NF / fornecedor.
- Conferência: volumes recebidos, "chegou tudo certo?" e, se não, o que
  houve (falta, avaria, sobra, produto errado, outro), com explicação e
  fotos. A nota fica "Recebida com divergência".

Calendário
- Mês (quantidade de notas e volumes por dia) e semana (as notas de cada
  dia). Arrastar uma nota para outro dia reagenda (ou "Mudar dia").

Registros
- Todas as notas, com busca, filtros (status, produto, transportadora,
  UF, datas), ordenação e exportação para CSV (Excel).

Detalhe da nota
- Ver, editar, dar entrada, reabrir e ver o histórico de alterações
  (quem mudou o quê e quando).

Novo agendamento e Importar
- Cadastro manual pelo botão "Novo agendamento".
- Importar: XML de NF-e, ZIP com vários XMLs, planilha .xlsx/.csv ou
  linhas coladas do Excel. Mostra uma prévia para corrigir antes de
  gravar e avisa as notas que já existem. Com a coluna "Recebido", dá
  entrada nas notas que já estavam no site.

Filial ES (fluxo entre ES e RJ)
- O ES registra a nota que chegou lá -> o RJ vê em "Chegaram no ES" e
  escolhe o dia em que quer receber -> o ES vê "O RJ pediu para enviar"
  -> o RJ dá entrada quando chega -> o ES vê "Chegaram no RJ".
- Só o ES cadastra notas do ES; o RJ só vê, escolhe o dia e dá entrada.
- Recebidas ES: histórico das notas que vieram do ES.

Sempre atualizado (sem F5)
- Agenda, calendário, Registros, Filial ES, Recebidas ES e o painel do
  admin se atualizam sozinhos quando outra pessoa muda algo, sem
  apagar o que você está digitando.

App no celular e avisos
- Instalar como app (Android: menu do usuário > "Instalar o app";
  iPhone: Safari > Compartilhar > Adicionar à Tela de Início).
- Avisos no celular (cada pessoa ativa no próprio aparelho): o ES
  registrou uma chegada, o RJ escolheu o dia, entrada com divergência e
  o resumo das atrasadas de manhã. Não usa serviço pago.

Área do administrador (/agendamentos/admin/)
- Usuários (criar, editar, ativar/desativar, redefinir senha).
- Painel: números e gráficos das entregas.
- Histórico: tudo que foi feito, com filtros e CSV.
- Planilha: troca as notas que vieram do Excel pelas de uma planilha
  nova (gere o planilha.json com ferramentas/converter_planilha.php),
  com prévia, confirmação e backup antes. Notas criadas pelo site ficam.
- Backup: baixar o banco na hora e ver os backups automáticos.
  Para restaurar: phpMyAdmin > Importar o arquivo .sql/.sql.gz.

Segurança
- Senhas guardadas com hash; bloqueio após 8 senhas erradas em 15 min.
- Proteção contra SQL injection (consultas preparadas) e CSRF.
- HTTPS obrigatório e cabeçalhos de segurança.
- Pastas internas (inc, dados, sql, ferramentas, backups, uploads)
  bloqueadas para o navegador.
- As fotos ficam em uploads/ e NÃO vão no backup do banco: entram no
  backup completo do cPanel.


7. PASTAS
---------
  admin/        área do administrador
  assets/       CSS, JavaScript e ícones
  ferramentas/  conversor da planilha do Excel (só pelo terminal)
  inc/          funções internas
  sql/          estrutura do banco (schema.sql)
  tests/        testes automáticos (php tests/smoke.php; os testes no
                navegador usam Node + Chrome e caminhos do XAMPP local)
  backups/      backups automáticos (criada vazia)
  uploads/      fotos do recebimento (criada vazia)
  LEIAME.md     documentação técnica mais detalhada


######################################################################
PART 2 - ENGLISH
######################################################################

WHAT IT IS
----------
A website (PHP + MySQL) that tracks supplier deliveries for the companies
Alfa Med, Beta Saúde and Gama Farma, at the Rio de Janeiro (RJ) warehouse
and the Espírito Santo (ES) branch. It replaces the "AGENDAMENTOS
FORNECEDOR" spreadsheet. Many people use it at the same time, each with
their own login, on a computer or a phone.
Note: the user interface is in Portuguese.


1. REQUIREMENTS
---------------
- PHP 8.0 or newer (8.2 recommended) with the pdo_mysql, mbstring and
  openssl extensions.
- MySQL 5.7+ or MariaDB 10.3+.
- Apache web server (XAMPP, HostGator/cPanel) or IIS.
- HTTPS on the published site. Without HTTPS the camera (barcode) and
  phone notifications do not work.


2. RUN IT ON A COMPUTER (XAMPP, for testing)
--------------------------------------------
1. Install XAMPP and start "Apache" and "MySQL" in the XAMPP panel.
2. Copy the project folder to C:\xampp\htdocs\agendamentos
3. Copy config.exemplo.php to a new file named config.php.
   With a default XAMPP the database settings already work
   (user root, empty password).
4. Open http://localhost/agendamentos/install.php in the browser.
   The installer creates the database and the tables.
5. Create the first administrator (name, username and password).
6. Log in at http://localhost/agendamentos/
7. Other computers on the same network: http://COMPUTER-IP/agendamentos
   (if it does not open, allow port 80 in Windows Firewall).


3. PUBLISH IT ON THE INTERNET (HostGator or any cPanel hosting)
---------------------------------------------------------------
1. cPanel > "MySQL Databases": create a database and a user, and give
   that user ALL privileges on the database.
   (HostGator adds a prefix, e.g. account_agendamentos.)
2. cPanel > "MultiPHP Manager": set the domain to PHP 8.2.
3. cPanel > "File Manager": upload the project folder to
   public_html/agendamentos (you can upload a .zip and use "Extract").
4. Copy config.exemplo.php to config.php and fill in the database name,
   user and password from step 1.
5. Open https://YOURDOMAIN/agendamentos/install.php and create the
   administrator.
6. IMPORTANT: delete install.php after installing.
7. Scheduled tasks (cPanel > "Cron Jobs"), replace YOURACCOUNT:
   - Daily database backup (e.g. every day at 3 am):
       /usr/local/bin/php /home/YOURACCOUNT/public_html/agendamentos/backup_cron.php
     Keeps the 14 most recent backups in the backups/ folder.
   - Morning summary of late deliveries on the phones (every day, 7 am):
       /usr/local/bin/php /home/YOURACCOUNT/public_html/agendamentos/avisos_cron.php
   (Some accounts use /home2/YOURACCOUNT/...; cPanel shows the right path
   at the top of the File Manager.)

Optional - load the Excel spreadsheet during installation:
  On a computer with PHP, run:
    php ferramentas/converter_planilha.php "AGENDAMENTOS FORNECEDOR.xlsx" planilha.json
  Put planilha.json in the dados/ folder before running install.php and
  keep "Importar as notas da planilha" checked. Delete dados/ afterwards.
  Once the site is running, use Admin > Planilha instead (see below).

Updating the site later:
  Upload the new files over the old ones, WITHOUT replacing config.php.
  The database upgrades itself (new columns) on the first visit, and
  open pages reload themselves into the new version.


4. SETTINGS (config.php)
------------------------
- db: MySQL host, port, database name, user and password.
- cnpj_empresas: recipient company tax ID (CNPJ) -> company, so the NF-e
  (electronic invoice) import recognizes the company. Optional.
- forcar_https: redirects http to https (ignored on localhost).
- timezone: time zone (default America/Sao_Paulo).
- por_pagina: rows per page on the Registros (records) screen.
- agenda_intervalo: how often, in seconds, open pages check whether
  someone changed something (default 8; 3 to 300).


5. USER ROLES
-------------
- Administrador (admin): everything, including users, full history and
  deleting deliveries.
- Operador (operator): creates, edits and checks in RJ deliveries.
- Leitor (viewer): read only.
- Filial ES (ES branch): only the ES branch screen (registers what
  arrived there).
Users are created at /agendamentos/admin/ (a separate area with its own
login, administrators only). A temporary password must be changed on
first login. Password rule: at least 6 characters, with 1 letter and
1 number.


6. FEATURES
-----------
Daily schedule (Agenda)
- List of days on the left (late, today, upcoming, no date) and the
  day's deliveries grouped by carrier.
- Counters at the top: late, arriving today, next 7 days, pending and
  delivered this month. Company filter.
- Search by supplier or invoice number. Print button (checklist sheet).
- The check button opens the receiving check; "Receber todas" checks a
  whole carrier at once. Every check-in can be undone.

Check-in (gate) and receiving check
- Scan the invoice (DANFE) barcode with the phone camera or a USB
  scanner, or type the invoice number / supplier.
- Receiving check: boxes received, "did everything arrive OK?" and, if
  not, what happened (missing, damaged, extra, wrong product, other),
  with a note and photos. The delivery is marked "received with issues".

Calendar
- Month view (deliveries and boxes per day) and week view (each day's
  deliveries). Drag a delivery to another day to reschedule it.

Records (Registros)
- Every delivery, with search, filters (status, product, carrier,
  state, dates), sorting and CSV export (opens in Excel).

Delivery details
- View, edit, check in, reopen and see the change history (who changed
  what and when).

New delivery and Import
- Manual entry with the "Novo agendamento" button.
- Import: NF-e XML files, a ZIP with many XMLs, an .xlsx/.csv
  spreadsheet or rows pasted from Excel. Shows a preview to fix before
  saving and flags deliveries that already exist. A "Recebido"
  (received) column checks in deliveries already on the site.

ES branch (flow between ES and RJ)
- ES registers a delivery that arrived there -> RJ sees it under
  "Chegaram no ES" and picks the day it wants it -> ES sees "O RJ pediu
  para enviar" (RJ asked to send) -> RJ checks it in on arrival -> ES
  sees "Chegaram no RJ" (arrived in RJ).
- Only ES creates ES deliveries; RJ only views, picks the day and
  checks in.
- Recebidas ES: history of deliveries that came from ES.

Always up to date (no F5 needed)
- Schedule, calendar, records, ES branch, ES received and the admin
  dashboard update by themselves when someone else changes something,
  without wiping what you are typing.

Phone app and notifications
- Install it as an app (Android: user menu > "Instalar o app";
  iPhone: Safari > Share > Add to Home Screen).
- Phone notifications (each person turns them on on their own phone):
  ES registered an arrival, RJ picked the day, check-in with issues and
  the morning summary of late deliveries. No paid service is used
  (standard Web Push).

Admin area (/agendamentos/admin/)
- Users (create, edit, enable/disable, reset password).
- Dashboard (Painel): delivery numbers and charts.
- History: everything that was done, with filters and CSV.
- Planilha (spreadsheet): replaces the deliveries that came from Excel
  with a new spreadsheet (make planilha.json with
  ferramentas/converter_planilha.php), with preview, confirmation and a
  backup first. Deliveries created on the site are kept.
- Backup: download the database now and see the automatic backups.
  To restore: phpMyAdmin > Import the .sql/.sql.gz file.

Security
- Hashed passwords; lockout after 8 wrong passwords in 15 minutes.
- Protection against SQL injection (prepared statements) and CSRF.
- HTTPS enforced and security headers.
- Internal folders (inc, dados, sql, ferramentas, backups, uploads) are
  blocked from the browser.
- Photos are stored in uploads/ and are NOT in the database backup:
  they are included in the full cPanel backup.


7. FOLDERS
----------
  admin/        administrator area
  assets/       CSS, JavaScript and icons
  ferramentas/  Excel spreadsheet converter (command line only)
  inc/          internal functions
  sql/          database structure (schema.sql)
  tests/        automated tests (php tests/smoke.php; the browser tests
                use Node + Chrome and local XAMPP paths)
  backups/      automatic backups (created empty)
  uploads/      receiving photos (created empty)
  LEIAME.md     more detailed technical documentation (Portuguese)
