<?php
require __DIR__ . '/inc/bootstrap.php';
require __DIR__ . '/inc/layout.php';
exigir_login();

$fp = agenda_fp($EMP); // calculado ANTES das consultas: se algo mudar durante a montagem, o próximo aviso corrige
$h = hoje();
$amanha = soma_dias($h, 1);
$wEmp = $EMP !== '' ? ' AND empresa = :emp' : '';
$pEmp = $EMP !== '' ? [':emp' => $EMP] : [];

// Dias com notas aguardando
$atrasados = (int)q("SELECT COUNT(*) FROM agendamentos WHERE entregue='N' AND data_receber < :h$wEmp", [':h' => $h] + $pEmp)->fetchColumn();
$naoFilaES = " AND (uf <> 'ES' OR chegou_es_em IS NULL)";
$semData = (int)q("SELECT COUNT(*) FROM agendamentos WHERE entregue='N' AND data_receber IS NULL$naoFilaES$wEmp", $pEmp)->fetchColumn();
// Chegaram na filial do ES e esperam o Rio escolher o dia de receber
$filaES = (int)q("SELECT COUNT(*) FROM agendamentos WHERE entregue='N' AND uf='ES' AND chegou_es_em IS NOT NULL AND data_receber IS NULL$wEmp", $pEmp)->fetchColumn();
$dias = q("SELECT data_receber AS d, COUNT(*) AS n FROM agendamentos WHERE entregue='N' AND data_receber >= :h$wEmp GROUP BY data_receber ORDER BY data_receber", [':h' => $h] + $pEmp)->fetchAll(PDO::FETCH_KEY_PAIR);
if (!isset($dias[$h])) { $dias = [$h => 0] + $dias; ksort($dias); }

// Dia escolhido
$dia = (string)($_GET['dia'] ?? '');
$valido = $dia === 'atrasados' || $dia === 'semdata' || $dia === 'es' || (preg_match('/^\d{4}-\d{2}-\d{2}$/', $dia) && checkdate((int)substr($dia, 5, 2), (int)substr($dia, 8, 2), (int)substr($dia, 0, 4)));
// (um dia sem notas também é válido: quando tudo é recebido, a tela aberta mostra o dia vazio em vez de notas velhas)
if (!$valido) {
    if ($dias[$h] > 0) $dia = $h;
    elseif ($atrasados > 0) $dia = 'atrasados';
    else { $dia = $h; foreach ($dias as $d => $q) if ($q > 0) { $dia = $d; break; } }
}

if ($dia === 'atrasados') {
    $itens = q("SELECT * FROM agendamentos WHERE entregue='N' AND data_receber < :h$wEmp ORDER BY data_receber, fornecedor IS NULL, fornecedor", [':h' => $h] + $pEmp)->fetchAll();
    $tituloDia = 'Entregas atrasadas';
} elseif ($dia === 'semdata') {
    $itens = q("SELECT * FROM agendamentos WHERE entregue='N' AND data_receber IS NULL$naoFilaES$wEmp ORDER BY fornecedor IS NULL, fornecedor", $pEmp)->fetchAll();
    $tituloDia = 'Sem data de recebimento';
} elseif ($dia === 'es') {
    $itens = q("SELECT * FROM agendamentos WHERE entregue='N' AND uf='ES' AND chegou_es_em IS NOT NULL AND data_receber IS NULL$wEmp ORDER BY chegou_es_em, fornecedor IS NULL, fornecedor", $pEmp)->fetchAll();
    $tituloDia = 'Chegaram no ES';
} else {
    $itens = q("SELECT * FROM agendamentos WHERE entregue='N' AND data_receber = :d$wEmp ORDER BY fornecedor IS NULL, fornecedor", [':d' => $dia] + $pEmp)->fetchAll();
    $tituloDia = ($dia === $h ? 'Hoje, ' : ($dia === $amanha ? 'Amanhã, ' : '')) . dia_longo($dia);
}

// Agrupa por transportadora
$grupos = [];
foreach ($itens as $r) $grupos[titulo($r['transportadora']) ?: 'Transportadora não informada'][] = $r;
uksort($grupos, fn($a, $b) => (count($grupos[$b]) <=> count($grupos[$a])) ?: strcmp($a, $b));
$totVol = array_sum(array_map(fn($r) => (int)$r['volumes_num'], $itens));
$mostraData = $dia === 'atrasados' || $dia === 'semdata';
$volta = $_SERVER['REQUEST_URI'];

topo('Agenda', 'agenda', true);
?>
<section class="agenda">
  <aside class="rail" aria-label="Dias">
    <?php if ($atrasados || $filaES): ?><h4>Pendências</h4><?php endif; ?>
    <?php if ($filaES): ?>
      <a class="day es" href="?dia=es" aria-current="<?= $dia === 'es' ? 'true' : 'false' ?>"><span class="tile"><i>Filial</i><b>ES</b></span><span class="dn"><b>Chegaram no ES</b><small>escolher o dia</small></span><span class="ct"><?= n($filaES) ?><small>notas</small></span></a>
    <?php endif; ?>
    <?php if ($atrasados): ?>
      <a class="day late" href="?dia=atrasados" aria-current="<?= $dia === 'atrasados' ? 'true' : 'false' ?>"><span class="tile"><i>Venc</i><b>!</b></span><span class="dn"><b>Atrasados</b><small>passou da data</small></span><span class="ct"><?= n($atrasados) ?><small>notas</small></span></a>
    <?php endif; ?>
    <h4>Próximos dias</h4>
    <?php foreach ($dias as $d => $qtd):
        $lbl = $d === $h ? 'Hoje' : ($d === $amanha ? 'Amanhã' : dia_curto($d));
        $sub = ($d === $h || $d === $amanha) ? dia_curto($d) : br($d);
        $tdow = mb_substr(DIAS[(int)date('w', strtotime($d))], 0, 3); $tnum = (int)date('j', strtotime($d)); ?>
      <a class="day <?= $d === $h ? 'today' : '' ?>" href="?dia=<?= e($d) ?>" aria-current="<?= $dia === $d ? 'true' : 'false' ?>"><span class="tile"><i><?= e($tdow) ?></i><b><?= $tnum ?></b></span><span class="dn"><b><?= e($lbl) ?></b><small><?= e($sub) ?></small></span><span class="ct"><?= n($qtd) ?><small>notas</small></span></a>
    <?php endforeach; ?>
    <?php if ($semData): ?>
      <h4>Outros</h4>
      <a class="day" href="?dia=semdata" aria-current="<?= $dia === 'semdata' ? 'true' : 'false' ?>"><span class="tile"><i>—</i><b>?</b></span><span class="dn"><b>Sem data</b><small>sem previsão</small></span><span class="ct"><?= n($semData) ?><small>notas</small></span></a>
    <?php endif; ?>
    <a class="day cal-atalho" href="calendario.php"><span class="tile"><?= icone('agenda', 18) ?></span><span class="dn"><b>Calendário</b><small>ver o mês e a semana</small></span></a>
  </aside>

  <div class="panel" id="painel" data-fp="<?= e($fp) ?>" data-dia="<?= e($dia) ?>" data-intervalo="<?= (int)($CONFIG['agenda_intervalo'] ?? 8) ?>">
    <div class="ph">
      <div>
        <span class="eyebrow <?= $dia === 'atrasados' ? 'late' : '' ?>"><?= $dia === 'atrasados' ? 'Pendência' : ($dia === 'es' ? 'Transferência da filial ES' : ($dia === 'semdata' ? 'Outros' : ($dia === $h ? 'Agenda do dia' : 'Próximos dias'))) ?></span>
        <h2><?= e(ucfirst_mb($tituloDia)) ?></h2>
      </div>
      <?php if ($itens): ?>
      <div class="meta" id="meta-painel"><span><b><?= plural(count($itens), 'nota', 'notas') ?></b></span><?php if ($totVol): ?><span><b><?= n($totVol) ?></b> volumes</span><?php endif; ?><span><b><?= count($grupos) ?></b> <?= count($grupos) === 1 ? 'transportadora' : 'transportadoras' ?></span></div>
      <?php endif; ?>
    </div>
    <?php if ($itens): ?>
    <form class="tools" method="get" action="registros.php">
      <div class="search"><?= icone('busca', 15) ?><input type="search" name="q" id="filtro-agenda" placeholder="Filtrar fornecedor ou NF" autocomplete="off" aria-label="Filtrar este dia; Enter busca em todos os dias" title="Filtra o dia aberto. Enter procura em todos os dias."></div>
      <span class="sp"></span>
      <button type="button" class="btn ghost" id="imprimir-dia">Imprimir</button>
      <button type="button" class="btn ghost" id="alterna-grupos">Recolher tudo</button>
    </form>
    <div class="colhead" aria-hidden="true"><span>Fornecedor</span><span>Nota fiscal</span><span>Volumes</span><span>Empresa</span><span></span></div>
    <?php endif; ?>
    <?php if (!$itens): ?>
      <div class="empty"><b><?= $dia === 'es' ? 'Nenhuma nota esperando no ES' : 'Nenhuma nota para este dia' ?></b><?= pode_editar() ? 'Use “Novo agendamento” para registrar uma entrega.' : 'Escolha outro dia na lista.' ?></div>
    <?php endif; ?>
    <?php foreach ($grupos as $transp => $lista):
        $v = array_sum(array_map(fn($r) => (int)$r['volumes_num'], $lista)); ?>
      <div class="grp">
        <div class="gh"><button type="button" class="tog" aria-expanded="true"><span class="tname"><?= e($transp) ?></span></button><span class="tmeta"><?= plural(count($lista), 'nota', 'notas') ?><?= $v ? ' · ' . n($v) . ' vol' : '' ?></span>
          <?php if (pode_editar() && count($lista) > 1 && $dia !== 'es'): ?>
          <form method="post" action="acao.php" class="inline ajax gh-all">
            <?= csrf_campo() ?><input type="hidden" name="acao" value="entregue_grupo"><input type="hidden" name="volta" value="<?= e($volta) ?>">
            <?php foreach ($lista as $x) echo '<input type="hidden" name="ids[]" value="' . (int)$x['id'] . '">'; ?>
            <button class="btn sm" type="submit">Receber todas</button>
          </form>
          <?php endif; ?>
        </div>
        <?php foreach ($lista as $r):
            $extra = array_filter([frase($r['produto']), $mostraData && $r['data_receber'] ? 'previsto ' . dm($r['data_receber']) : '', $r['uf'] === 'ES' ? ($r['chegou_es_em'] ? 'chegou no ES ' . dm($r['chegou_es_em']) : 'ES') : '']);
            $nota = frase($r['observacao']) ?: frase($r['obs_vianna']);
            $forn = titulo($r['fornecedor']) ?: 'Fornecedor não informado';
            $volSoNum = $r['volumes'] !== null && (string)$r['volumes_num'] === (string)$r['volumes']; ?>
        <div class="row" data-id="<?= (int)$r['id'] ?>" data-vol="<?= (int)$r['volumes_num'] ?>" data-href="agendamento.php?id=<?= (int)$r['id'] ?>" data-busca="<?= e(mb_strtolower($forn . ' ' . $r['nota_fiscal'])) ?>">
          <div class="who"><a href="agendamento.php?id=<?= (int)$r['id'] ?>"><?= e($forn) ?></a><small><?= e(implode(' · ', $extra)) ?><?= $nota ? ($extra ? ' · ' : '') . '<span class="note">' . e($nota) . '</span>' : '' ?></small></div>
          <span class="nf mono"><?= $r['nota_fiscal'] ? 'NF ' . e($r['nota_fiscal']) : 'sem NF' ?></span>
          <span class="vol"><?= e($r['volumes'] ?: '—') ?><?= $volSoNum ? ' <small>vol</small>' : '' ?></span>
          <span class="tag e-<?= e(strtolower(str_replace(' ', '-', $r['empresa'] ?? ''))) ?>"><?= e(emp_nome($r['empresa'])) ?></span>
          <?php if ($dia === 'es'): ?>
          <span class="rowsp"></span>
          <?php if (pode_editar()): ?>
          <form method="post" action="acao.php" class="es-receber">
            <?= csrf_campo() ?><input type="hidden" name="acao" value="receber_es"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><input type="hidden" name="de" value=""><input type="hidden" name="volta" value="<?= e($volta) ?>">
            <label for="rec-<?= (int)$r['id'] ?>">Receber no Rio em</label>
            <input id="rec-<?= (int)$r['id'] ?>" type="date" name="data_receber" value="<?= e($amanha) ?>" min="<?= e($h) ?>" required>
            <button class="btn sm primary" type="submit">Agendar</button>
          </form>
          <?php endif; ?>
          <?php elseif (pode_editar()): ?>
          <form method="post" action="acao.php" class="inline ajax">
            <?= csrf_campo() ?><input type="hidden" name="acao" value="entregue"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><input type="hidden" name="volta" value="<?= e($volta) ?>">
            <button class="check" title="Marcar como entregue" aria-label="Marcar <?= e($forn) ?> como entregue"><?= icone('check', 15) ?></button>
          </form>
          <?php else: ?><span class="rowsp"></span><?php endif; ?>
        </div>
        <?php endforeach; ?>
      </div>
    <?php endforeach; ?>
  </div>
</section>
<?php rodape();
