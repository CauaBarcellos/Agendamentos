<?php
// Portaria: lê o código de barras do DANFE (câmera ou leitor USB) ou o número da NF, acha a nota e abre a conferência.
require __DIR__ . '/inc/bootstrap.php';
require __DIR__ . '/inc/layout.php';
exigir_login();
exigir_edicao();

$q = trim((string)($_GET['q'] ?? ''));
$res = $q !== '' ? entrada_buscar(mb_substr($q, 0, 80)) : null;
$pronta = fn(array $r) => $r['entregue'] === 'N' && !($r['uf'] === 'ES' && !$r['data_receber']);
// Achou exatamente pela chave e dá para receber: vai direto para a conferência.
if ($res && isset($res['id']) && $pronta($res['itens'][0])) {
    redirecionar('receber.php?id=' . $res['id'] . '&volta=' . urlencode('entrada.php'));
}

topo('Dar entrada', 'receber');
?>
<div class="es-col">
<div class="pagehead"><h1>Dar entrada</h1><p class="muted">Leia o código de barras da nota (DANFE) com a câmera ou com o leitor. Também dá para digitar o número da NF ou o nome do fornecedor.</p></div>

<section class="card ent">
  <form method="get" action="entrada.php" class="ent-busca" id="ent-form">
    <div class="search"><?= icone('busca', 17) ?><input type="search" name="q" id="ent-q" value="<?= e($q) ?>" placeholder="Código de barras, NF ou fornecedor" autocomplete="off" autofocus aria-label="Código de barras, número da NF ou fornecedor"></div>
    <button class="btn primary" type="submit">Procurar</button>
  </form>
  <button type="button" class="btn ent-cam-bt" id="ent-cam"><?= icone('camera', 18) ?> Ler com a câmera</button>
  <div class="ent-camera" id="ent-camera" hidden>
    <video id="ent-video" playsinline muted></video>
    <span class="ent-mira" aria-hidden="true"></span>
    <button type="button" class="btn sm ent-fechar" id="ent-fechar">Fechar câmera</button>
  </div>
  <p class="muted small" id="ent-status" role="status"></p>

  <?php if ($res): ?>
    <?php if ($res['aviso'] ?? ''): ?><div class="flash <?= $res['itens'] ? '' : 'erro' ?>" style="margin:0 0 4px"><?= e($res['aviso'] ?? '') ?></div><?php endif; ?>
    <?php foreach ($res['itens'] as $r):
        $extra = array_filter([$r['nota_fiscal'] ? 'NF ' . $r['nota_fiscal'] : 'sem NF', $r['volumes'] ? $r['volumes'] . ' vol' : '', titulo($r['transportadora']), emp_nome($r['empresa']), $r['uf'] === 'ES' ? 'vem do ES' : '']); ?>
      <div class="esitem">
        <div class="who"><b><?= e(titulo($r['fornecedor']) ?: 'Fornecedor não informado') ?></b><small><?= e(implode(' · ', $extra)) ?></small></div>
        <?php if ($pronta($r)): ?>
          <div class="es-st"><small><?= $r['data_receber'] ? 'previsto ' . br($r['data_receber']) : 'sem data prevista' ?></small></div>
          <a class="btn primary" href="receber.php?id=<?= (int)$r['id'] ?>&amp;volta=<?= urlencode('entrada.php') ?>">Dar entrada</a>
        <?php elseif ($r['entregue'] === 'N'): ?>
          <div class="es-st"><span class="st s-hoje">Falta escolher o dia (nota do ES)</span></div>
          <a class="btn" href="agendamento.php?id=<?= (int)$r['id'] ?>">Abrir</a>
        <?php else: ?>
          <div class="es-st"><span class="st s-<?= $r['divergencia'] ? 'divergencia' : 'entregue' ?>"><?= $r['divergencia'] ? 'Recebida com divergência' : 'Já recebida' ?><?= $r['entregue_em'] ? ' em ' . br($r['entregue_em']) : '' ?></span></div>
          <a class="btn ghost" href="agendamento.php?id=<?= (int)$r['id'] ?>">Ver</a>
        <?php endif; ?>
      </div>
    <?php endforeach; ?>
  <?php endif; ?>
</section>
</div>
<?php rodape();
