<?php
require __DIR__ . '/../inc/bootstrap.php';
unset($_SESSION['adm']);
redirecionar('login.php');
