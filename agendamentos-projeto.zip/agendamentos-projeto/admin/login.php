<?php
require __DIR__ . '/../inc/bootstrap.php';
require __DIR__ . '/../inc/admin_auth.php';

$erro = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (login_bloqueado()) {
        $erro = 'Muitas tentativas. Aguarde alguns minutos.';
    } else {
        $login = trim((string)($_POST['login'] ?? ''));
        $senha = (string)($_POST['senha'] ?? '');
        $u = q('SELECT * FROM usuarios WHERE login = ?', [$login])->fetch();
        if ($u && (int)$u['ativo'] === 1 && $u['perfil'] === 'admin' && password_verify($senha, $u['senha_hash'])) {
            session_regenerate_id(true);
            login_ok();
            $_SESSION['adm'] = ['id' => (int)$u['id'], 'nome' => $u['nome'], 'login' => $u['login'], 'ts' => time()];
            redirecionar('index.php');
        }
        login_falhou();
        usleep(600000);
        $erro = 'Acesso negado.';
    }
}
if (adm_usuario()) redirecionar('index.php');
?><!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>Administração</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Geist:wght@400;500;600;700&display=swap">
<link rel="icon" type="image/svg+xml" href="../favicon.svg?v=3">
<link rel="icon" href="../favicon.ico?v=3" sizes="any">
<link rel="icon" type="image/png" sizes="32x32" href="../assets/favicon-32.png?v=3">
<link rel="apple-touch-icon" href="../assets/apple-touch-icon.png?v=3">
<link rel="stylesheet" href="../assets/style.css?v=10">
</head>
<body class="loginpage">
<main class="logincard">
  <div class="brand"><span class="mark"><?= icone('caminhao', 18) ?></span><b>Administração</b></div>
  <h1>Acesso restrito</h1>
  <p class="muted">Somente administradores autorizados.</p>
  <?php if ($erro): ?><div class="flash erro"><?= e($erro) ?></div><?php endif; ?>
  <form method="post" class="form1">
    <div class="field"><label for="login">Usuário</label><input id="login" name="login" required autofocus autocomplete="username"></div>
    <div class="field"><label for="senha">Senha</label><input id="senha" name="senha" type="password" required autocomplete="current-password"></div>
    <button class="btn primary full" type="submit">Entrar</button>
  </form>
</main>
</body>
</html>
