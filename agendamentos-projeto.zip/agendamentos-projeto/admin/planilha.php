<?php
// Troca as notas da planilha antiga pelas da planilha nova (arquivo planilha.json gerado da planilha do Excel).
// Mostra a prévia, pede confirmação, faz backup do banco antes e mantém as notas criadas pelo site.
require __DIR__ . '/../inc/bootstrap.php';
require __DIR__ . '/../inc/admin_auth.php';
require __DIR__ . '/../inc/backup.php';
require __DIR__ . '/../inc/planilha_carga.php';
adm_exigir();

// nome próprio: não confunde com o dados/planilha.json da instalação, se ele ainda estiver no servidor
$arquivo = dirname(__DIR__) . '/dados/planilha_enviada.json';
$erro = '';
$feito = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validar();
    $acao = (string)($_POST['acao'] ?? '');
    if ($acao === 'enviar') {
        $f = $_FILES['arquivo'] ?? null;
        if (!$f || $f['error'] !== UPLOAD_ERR_OK) $erro = 'Escolha o arquivo planilha.json para enviar.';
        elseif ($f['size'] > 20 * 1024 * 1024) $erro = 'Arquivo grande demais.';
        else {
            [$d, $e] = planilha_ler($f['tmp_name']);
            if ($e) $erro = $e;
            else {
                if (!is_dir(dirname($arquivo))) mkdir(dirname($arquivo), 0750, true);
                if (!is_file(dirname($arquivo) . '/.htaccess')) file_put_contents(dirname($arquivo) . '/.htaccess', "Require all denied\n");
                move_uploaded_file($f['tmp_name'], $arquivo);
                flash('Arquivo recebido. Confira a prévia abaixo antes de confirmar.');
                redirecionar('planilha.php');
            }
        }
    } elseif ($acao === 'substituir') {
        [$d, $e] = planilha_ler($arquivo);
        if ($e) $erro = $e;
        elseif (($_POST['confirmo'] ?? '') !== 'sim' || mb_strtoupper(trim((string)($_POST['palavra'] ?? ''))) !== 'SUBSTITUIR') $erro = 'Marque a confirmação e digite SUBSTITUIR.';
        else {
            @set_time_limit(300);
            // backup antes de tudo, guardado na pasta de backups (aparece em Backup)
            $dir = dirname(__DIR__) . '/backups';
            if (!is_dir($dir)) mkdir($dir, 0750, true);
            $bkp = $dir . '/backup_antes_planilha_' . date('Y-m-d_His') . '.sql' . (function_exists('gzopen') ? '.gz' : '');
            $h = function_exists('gzopen') ? gzopen($bkp, 'wb9') : fopen($bkp, 'wb');
            backup_sql($h);
            function_exists('gzopen') ? gzclose($h) : fclose($h);
            try {
                $feito = planilha_substituir($d) + ['backup' => basename($bkp)];
                @unlink($arquivo); // não deixa o arquivo da planilha no servidor
            } catch (Throwable $ex) {
                error_log('planilha: ' . $ex->getMessage());
                $erro = 'Deu erro e nada foi alterado (o banco voltou ao que era). Detalhe: ' . mb_substr($ex->getMessage(), 0, 160);
            }
        }
    }
}

[$dados, $erroArq] = is_file($arquivo) ? planilha_ler($arquivo) : [null, null];
$prev = $dados && !$feito ? planilha_analisar($dados) : null;
adm_topo('Planilha', 'planilha');
?>
<div class="pagehead"><h1>Atualizar pela planilha</h1><p class="muted">Troca as notas que vieram da planilha do Excel pelas de uma planilha nova. As notas criadas pelo site (filial ES, importações, novos agendamentos) ficam como estão.</p></div>

<?php if ($erro): ?><div class="flash erro"><?= e($erro) ?></div><?php endif; ?>

<?php if ($feito): ?>
  <section class="card formcard">
    <div class="cardhead"><h2>Pronto: planilha nova carregada</h2></div>
    <dl class="kv">
      <dt>Notas apagadas (planilha antiga)</dt><dd><?= n($feito['apagadas']) ?></dd>
      <dt>Notas carregadas (planilha nova)</dt><dd><?= n($feito['carregadas']) ?></dd>
      <dt>Puladas (já existiam no site)</dt><dd><?= n($feito['puladas']) ?></dd>
      <dt>Recebidas ES</dt><dd><?= n($feito['recebidas']) ?></dd>
      <dt>Backup feito antes</dt><dd class="mono"><?= e($feito['backup']) ?></dd>
    </dl>
    <p class="muted small" style="margin:0">Se precisar voltar atrás, baixe esse backup em <a href="backup.php">Backup</a> e importe no phpMyAdmin.</p>
    <div class="cardfoot"><span class="sp"></span><a class="btn primary" href="../index.php">Abrir a agenda</a></div>
  </section>
<?php else: ?>

  <form class="card formcard" method="post" enctype="multipart/form-data">
    <?= csrf_campo() ?><input type="hidden" name="acao" value="enviar">
    <div class="cardhead"><h2>1. Enviar a planilha</h2></div>
    <p class="muted" style="margin:0">Envie o arquivo <b>planilha.json</b> gerado da planilha do Excel.</p>
    <div class="field"><input type="file" name="arquivo" accept=".json,application/json" required></div>
    <?php if ($erroArq): ?><div class="flash erro" style="margin:0"><?= e($erroArq) ?></div><?php endif; ?>
    <div class="cardfoot"><span class="sp"></span><button class="btn" type="submit">Enviar e ver a prévia</button></div>
  </form>

  <?php if ($prev): ?>
  <form class="card formcard" method="post" id="form-substituir">
    <?= csrf_campo() ?><input type="hidden" name="acao" value="substituir">
    <div class="cardhead"><h2>2. Prévia: o que vai acontecer</h2></div>
    <dl class="kv">
      <dt>Apagar (planilha antiga)</dt><dd><b><?= n($prev['apagar']) ?></b> notas<?= $prev['apagar_mexidas'] ? ' · <span class="st s-atrasado">' . n($prev['apagar_mexidas']) . ' foram alteradas pelo site</span>' : '' ?><?= $prev['apagar_fotos'] ? ' · ' . n($prev['apagar_fotos']) . ' fotos' : '' ?></dd>
      <dt>Carregar (planilha nova)</dt><dd><b><?= n($prev['carregar']) ?></b> notas · <?= n($prev['carregar_aguardando']) ?> aguardando, <?= n($prev['carregar_recebidas']) ?> recebidas<?= $prev['carregar_devolvidas'] ? ', ' . n($prev['carregar_devolvidas']) . ' devolvidas' : '' ?></dd>
      <dt>Manter (criadas pelo site)</dt><dd><b><?= n($prev['manter_site']) ?></b> notas</dd>
      <dt>Pular (já existem no site)</dt><dd><?= n($prev['pular']) ?><?= $prev['pular_exemplos'] ? ' <small class="muted">ex.: ' . e(implode('; ', $prev['pular_exemplos'])) . '</small>' : '' ?></dd>
      <dt>Recebidas ES</dt><dd><?= n($prev['recebidas_antes']) ?> → <b><?= n($prev['recebidas_depois']) ?></b></dd>
    </dl>
    <?php if ($prev['apagar_mexidas']): ?><div class="flash erro" style="margin:0">Atenção: <?= plural($prev['apagar_mexidas'], 'nota da planilha antiga foi alterada', 'notas da planilha antiga foram alteradas') ?> pelo site (entrada, data, divergência...). Essas mudanças serão perdidas: vale a informação da planilha nova.</div><?php endif; ?>
    <label class="checkline"><input type="checkbox" name="confirmo" value="sim" required> Entendi: as notas da planilha antiga serão trocadas pelas da nova. Um backup do banco é feito antes.</label>
    <div class="field"><label for="palavra">Para confirmar, digite <b>SUBSTITUIR</b></label><input id="palavra" name="palavra" autocomplete="off" required></div>
    <div class="cardfoot"><span class="sp"></span><button class="btn primary danger" type="submit">Substituir pela planilha nova</button></div>
  </form>
  <?php endif; ?>
<?php endif; ?>
<?php adm_rodape();
