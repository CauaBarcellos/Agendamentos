<?php
require __DIR__ . '/../inc/bootstrap.php';
require __DIR__ . '/../inc/admin_auth.php';
adm_exigir();

const PERFIS = PERFIL_NOME;
const PERFIS_DESC = ['admin' => 'tudo, inclusive usuários e exclusões', 'operador' => 'cria, edita e dá baixa', 'leitor' => 'só consulta', 'filial_es' => 'só avisa as notas que chegaram no ES'];
$eu = adm_usuario()['id'];
$erro = '';
$editId = (int)($_GET['id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['acao'] ?? '') === 'redefinir') {
    csrf_validar();
    $id = (int)($_POST['id'] ?? 0);
    $alvo = q('SELECT nome FROM usuarios WHERE id = ?', [$id])->fetch();
    if ($alvo) {
        // Senha provisória aleatória (sem letras/números parecidos); a pessoa é obrigada a trocar no próximo acesso.
        $alf = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789';
        $prov = '';
        for ($i = 0; $i < 10; $i++) $prov .= $alf[random_int(0, strlen($alf) - 1)];
        $prov .= random_int(2, 9);
        q('UPDATE usuarios SET senha_hash = ?, trocar_senha = 1 WHERE id = ?', [password_hash($prov, PASSWORD_DEFAULT), $id]);
        flash('Senha de ' . $alvo['nome'] . ' redefinida. Senha provisória: ' . $prov . ' — passe para a pessoa; ela vai precisar trocar ao entrar.');
    }
    redirecionar('index.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validar();
    $id = (int)($_POST['id'] ?? 0);
    $nome = trim((string)($_POST['nome'] ?? ''));
    $login = mb_strtolower(trim((string)($_POST['login'] ?? '')));
    $perfil = array_key_exists($_POST['perfil'] ?? '', PERFIS) ? $_POST['perfil'] : 'operador';
    $ativo = isset($_POST['ativo']) ? 1 : 0;
    $senha = (string)($_POST['senha'] ?? '');

    if ($nome === '') $erro = 'Informe o nome.';
    elseif (!preg_match('/^[a-z0-9._-]{3,50}$/', $login)) $erro = 'O usuário deve ter de 3 a 50 caracteres: letras minúsculas, números, ponto, hífen ou sublinhado.';
    elseif ((!$id || $senha !== '') && ($msg = senha_invalida($senha, $login))) $erro = $msg;
    elseif ((int)q('SELECT COUNT(*) FROM usuarios WHERE login = ? AND id <> ?', [$login, $id])->fetchColumn() > 0) $erro = 'Já existe um usuário com esse login.';
    elseif ($id === $eu && ($perfil !== 'admin' || !$ativo)) $erro = 'Você não pode tirar o seu próprio acesso de administrador.';

    if (!$erro) {
        if ($id) {
            q('UPDATE usuarios SET nome=?, login=?, perfil=?, ativo=? WHERE id=?', [$nome, $login, $perfil, $ativo, $id]);
            if ($senha !== '') q('UPDATE usuarios SET senha_hash=?, trocar_senha=1 WHERE id=?', [password_hash($senha, PASSWORD_DEFAULT), $id]);
            flash('Usuário atualizado.');
        } else {
            q('INSERT INTO usuarios (nome, login, senha_hash, perfil, ativo, trocar_senha, criado_em) VALUES (?,?,?,?,?,1,?)', [$nome, $login, password_hash($senha, PASSWORD_DEFAULT), $perfil, 1, agora()]);
            flash("Usuário $login criado. Passe a senha para a pessoa; ela será obrigada a trocar ao entrar.");
        }
        redirecionar('index.php');
    }
    $editId = $id;
}

$lista = q('SELECT * FROM usuarios ORDER BY ativo DESC, nome')->fetchAll();
$ed = $editId ? q('SELECT * FROM usuarios WHERE id = ?', [$editId])->fetch() : null;
$fv = fn($k, $pad = '') => e($_POST[$k] ?? ($ed[$k] ?? $pad));

adm_topo('Usuários', 'usuarios');
?>
<div class="pagehead"><h1>Usuários</h1><p class="muted">Quem pode entrar no portal e o que cada um pode fazer.</p></div>
<div class="two-col">
  <div class="tablebox"><table class="cards adm-u" style="min-width:560px">
    <thead><tr><th>Nome</th><th>Usuário</th><th>Perfil</th><th>Último acesso</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($lista as $u): ?>
      <tr class="<?= $u['ativo'] ? '' : 'off' ?>">
        <td><b><?= e($u['nome']) ?></b><?= $u['ativo'] ? '' : ' <span class="tag">desativado</span>' ?><?= !empty($u['trocar_senha']) ? ' <span class="tag">trocar senha</span>' : '' ?></td>
        <td class="mono"><?= e($u['login']) ?></td>
        <td><?= e(PERFIS[$u['perfil']]) ?></td>
        <td class="num"><?= $u['ultimo_acesso'] ? br_hora($u['ultimo_acesso']) : '<span class="muted">nunca</span>' ?></td>
        <td class="r"><a class="btn sm" href="index.php?id=<?= (int)$u['id'] ?>">Editar</a></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>

  <div style="display:flex;flex-direction:column;gap:16px">
  <form class="card formcard" style="margin:0" method="post" action="index.php<?= $ed ? '?id=' . (int)$ed['id'] : '' ?>">
    <?= csrf_campo() ?><?php if ($ed): ?><input type="hidden" name="id" value="<?= (int)$ed['id'] ?>"><?php endif; ?>
    <div class="cardhead"><h2><?= $ed ? 'Editar ' . e($ed['nome']) : 'Novo usuário' ?></h2></div>
    <?php if ($erro): ?><div class="flash erro"><?= e($erro) ?></div><?php endif; ?>
    <div class="form1">
      <div class="field"><label for="nome">Nome</label><input id="nome" name="nome" required value="<?= $fv('nome') ?>"></div>
      <div class="field"><label for="login">Usuário (para entrar)</label><input id="login" name="login" required value="<?= $fv('login') ?>" placeholder="ex.: joao.silva" autocomplete="off"></div>
      <div class="field"><label for="perfil">Perfil</label><select id="perfil" name="perfil"><?php foreach (PERFIS as $k => $l) echo '<option value="' . $k . '"' . (($_POST['perfil'] ?? $ed['perfil'] ?? 'operador') === $k ? ' selected' : '') . '>' . $l . ' — ' . PERFIS_DESC[$k] . '</option>'; ?></select></div>
      <div class="field"><label for="senha"><?= $ed ? 'Nova senha (deixe em branco para manter)' : 'Senha inicial' ?></label><input id="senha" name="senha" type="text" <?= $ed ? '' : 'required' ?> minlength="6" autocomplete="off"><small class="muted">Pelo menos 6 caracteres, com 1 letra e 1 número.</small></div>
      <?php if ($ed): ?><label class="checkline"><input type="checkbox" name="ativo" value="1" <?= ($ed['ativo'] ?? 1) ? 'checked' : '' ?>> Ativo (pode entrar no portal)</label><?php endif; ?>
    </div>
    <div class="cardfoot"><span class="sp"></span><?php if ($ed): ?><a class="btn" href="index.php">Cancelar</a><?php endif; ?><button class="btn primary" type="submit"><?= $ed ? 'Salvar' : 'Criar usuário' ?></button></div>
  </form>
  <?php if ($ed): ?>
  <form method="post" class="card formcard" style="margin:0">
    <?= csrf_campo() ?><input type="hidden" name="acao" value="redefinir"><input type="hidden" name="id" value="<?= (int)$ed['id'] ?>">
    <div class="cardhead"><h2>Esqueceu a senha?</h2><p class="muted small">Gera uma senha provisória para <?= e($ed['nome']) ?>. A pessoa será obrigada a trocar ao entrar.</p></div>
    <div class="cardfoot"><span class="sp"></span><button class="btn" type="submit">Redefinir senha</button></div>
  </form>
  <?php endif; ?>
  </div>
</div>
<?php adm_rodape();
