<?php
require __DIR__ . '/../inc/bootstrap.php';
require __DIR__ . '/../inc/admin_auth.php';
adm_exigir();
site_fp(); // antes das consultas: a página aberta se atualiza sozinha quando isso muda

$h = hoje();
$desde = date('Y-m-d', strtotime('-180 days'));
$pend = (int)q("SELECT COUNT(*) FROM agendamentos WHERE entregue='N'")->fetchColumn();
$atras = (int)q("SELECT COUNT(*) FROM agendamentos WHERE entregue='N' AND data_receber < ?", [$h])->fetchColumn();
$mes = (int)q("SELECT COUNT(*) FROM agendamentos WHERE entregue='S' AND entregue_em >= ?", [date('Y-m-01')])->fetchColumn();
$medio = q("SELECT AVG(DATEDIFF(DATE(entregue_em), data_receber)) FROM agendamentos WHERE entregue='S' AND entregue_em IS NOT NULL AND data_receber IS NOT NULL AND entregue_em >= ?", [$desde])->fetchColumn();
$noPrazo = q("SELECT COALESCE(SUM(DATEDIFF(DATE(entregue_em), data_receber) <= 0),0), COUNT(*) FROM agendamentos WHERE entregue='S' AND entregue_em IS NOT NULL AND data_receber IS NOT NULL AND entregue_em >= ?", [$desde])->fetch(PDO::FETCH_NUM);

// Últimos 6 meses (notas previstas por mês)
$meses = [];
for ($i = 5; $i >= 0; $i--) $meses[date('Y-m', strtotime("first day of -$i month"))] = ['n' => 0, 'ok' => 0];
foreach (q("SELECT DATE_FORMAT(data_receber,'%Y-%m') m, COUNT(*) n, SUM(entregue='S') ok FROM agendamentos WHERE data_receber >= ? GROUP BY m", [array_key_first($meses) . '-01'])->fetchAll() as $r) {
    if (isset($meses[$r['m']])) $meses[$r['m']] = ['n' => (int)$r['n'], 'ok' => (int)$r['ok']];
}
$maxMes = max(1, ...array_column($meses, 'n'));

$transp = q("SELECT COALESCE(NULLIF(transportadora,''),'(sem transportadora)') t, COUNT(*) n, SUM(entregue='N' AND data_receber < ?) atras,
        AVG(CASE WHEN entregue='S' AND entregue_em IS NOT NULL AND data_receber IS NOT NULL THEN DATEDIFF(DATE(entregue_em), data_receber) END) medio
    FROM agendamentos WHERE data_receber >= ? GROUP BY t ORDER BY n DESC LIMIT 10", [$h, $desde])->fetchAll();
$maxT = max(1, ...array_map(fn($r) => (int)$r['n'], $transp ?: [['n' => 1]]));
$forn = q("SELECT fornecedor, COUNT(*) n FROM agendamentos WHERE entregue='N' AND data_receber < ? AND fornecedor <> '' GROUP BY fornecedor ORDER BY n DESC LIMIT 5", [$h])->fetchAll();
$mesNome = fn($ym) => mb_substr(MESES[(int)substr($ym, 5, 2) - 1], 0, 3) . '/' . substr($ym, 2, 2);

adm_topo('Painel', 'painel');
?>
<div class="pagehead"><h1>Painel</h1><p class="muted">Visão geral das entregas (últimos 6 meses).</p></div>
<div id="adm-painel" data-vivo>
<div class="stats" style="margin-bottom:18px;flex-wrap:wrap">
  <div class="stat"><span class="v"><?= n($pend) ?></span><span class="l">Aguardando entrega</span></div>
  <div class="stat"><span class="v" style="color:<?= $atras ? 'var(--late)' : 'inherit' ?>"><?= n($atras) ?></span><span class="l">Atrasadas agora</span></div>
  <div class="stat"><span class="v"><?= n($mes) ?></span><span class="l">Recebidas no mês</span></div>
  <div class="stat"><span class="v"><?= $medio === null ? '—' : ($medio > 0 ? '+' : '') . number_format((float)$medio, 1, ',', '') . ' d' ?></span><span class="l">Atraso médio no recebimento</span></div>
  <div class="stat"><span class="v"><?= $noPrazo[1] ? round($noPrazo[0] / $noPrazo[1] * 100) . '%' : '—' ?></span><span class="l">Recebidas no prazo</span></div>
</div>
<div class="two-col" style="grid-template-columns:minmax(0,1fr) minmax(0,1fr)">
  <div class="card" style="margin:0">
    <div class="cardhead"><h2>Notas por mês</h2><p class="muted small">Previstas · parte escura = já recebidas</p></div>
    <div class="bars">
      <?php foreach ($meses as $ym => $m): ?>
        <div class="bar"><span class="bl"><?= e($mesNome($ym)) ?></span><span class="bt"><i style="width:<?= round($m['n'] / $maxMes * 100) ?>%"><i style="width:<?= $m['n'] ? round($m['ok'] / $m['n'] * 100) : 0 ?>%"></i></i></span><span class="bn"><?= n($m['n']) ?></span></div>
      <?php endforeach; ?>
    </div>
  </div>
  <div class="card" style="margin:0">
    <div class="cardhead"><h2>Transportadoras</h2><p class="muted small">Notas · atrasadas agora · atraso médio</p></div>
    <div class="bars">
      <?php foreach ($transp as $r): ?>
        <div class="bar"><span class="bl" title="<?= e(titulo($r['t'])) ?>"><?= e(titulo($r['t'])) ?></span><span class="bt"><i style="width:<?= round($r['n'] / $maxT * 100) ?>%"></i></span><span class="bn"><?= n($r['n']) ?><?= (int)$r['atras'] ? ' · <b style="color:var(--late)">' . (int)$r['atras'] . '</b>' : '' ?><?= $r['medio'] !== null ? ' · ' . number_format((float)$r['medio'], 1, ',', '') . 'd' : '' ?></span></div>
      <?php endforeach; ?>
      <?php if (!$transp) echo '<p class="muted small">Sem dados.</p>'; ?>
    </div>
  </div>
</div>
<?php if ($forn): ?>
<div class="card" style="margin:16px 0 48px;max-width:560px">
  <div class="cardhead"><h2>Fornecedores com mais notas atrasadas</h2></div>
  <?php foreach ($forn as $r): ?><div class="bar"><span class="bl" style="width:auto;flex:1"><?= e(titulo($r['fornecedor'])) ?></span><span class="bn" style="color:var(--late);font-weight:600"><?= n($r['n']) ?></span></div><?php endforeach; ?>
</div>
<?php endif; ?>
</div>
<?php adm_rodape();
