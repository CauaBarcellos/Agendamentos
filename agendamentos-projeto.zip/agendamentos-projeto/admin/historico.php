<?php
require __DIR__ . '/../inc/bootstrap.php';
require __DIR__ . '/../inc/admin_auth.php';
adm_exigir();
site_fp(); // antes das consultas: a página aberta se atualiza sozinha quando isso muda

$g = fn($k) => trim((string)($_GET[$k] ?? ''));
$txt = ['criou' => 'Criou', 'editou' => 'Editou', 'entregue' => 'Deu baixa', 'reabriu' => 'Reabriu', 'excluiu' => 'Excluiu'];

$w = ['1=1']; $p = [];
if ((int)$g('u') > 0) { $w[] = 'h.usuario_id = ?'; $p[] = (int)$g('u'); }
if (isset($txt[$g('acao')])) { $w[] = 'h.acao = ?'; $p[] = $g('acao'); }
if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $g('de'))) { $w[] = 'h.criado_em >= ?'; $p[] = $g('de') . ' 00:00:00'; }
if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $g('ate'))) { $w[] = 'h.criado_em <= ?'; $p[] = $g('ate') . ' 23:59:59'; }
if ($g('q') !== '') { $w[] = '(a.fornecedor LIKE ? OR a.nota_fiscal LIKE ? OR h.detalhes LIKE ?)'; $l = '%' . $g('q') . '%'; array_push($p, $l, $l, $l); }
$where = implode(' AND ', $w);
$sql = "SELECT h.*, u.nome, a.fornecedor, a.nota_fiscal FROM historico h
    LEFT JOIN usuarios u ON u.id = h.usuario_id
    LEFT JOIN agendamentos a ON a.id = h.agendamento_id
    WHERE $where ORDER BY h.id DESC";

$descr = function (array $h): array {
    $det = $h['detalhes'] ? json_decode($h['detalhes'], true) : [];
    $forn = $h['fornecedor'] ?? ($h['acao'] === 'excluiu' ? ($det['fornecedor'] ?? '') : '');
    $nf = $h['nota_fiscal'] ?? ($h['acao'] === 'excluiu' ? ($det['nota_fiscal'] ?? '') : '');
    $mud = '';
    if (in_array($h['acao'], ['editou', 'entregue', 'reabriu'], true) && $det) {
        $mud = implode('; ', array_map(fn($c, $v) => (CAMPOS_LABEL[$c] ?? $c) . ': ' . valor_legivel($c, $v[0]) . ' → ' . valor_legivel($c, $v[1]), array_keys($det), $det));
    }
    if ($h['acao'] === 'criou' && !empty($det['origem'])) $mud = ucfirst((string)$det['origem'][1]);
    return [$forn, $nf, $mud];
};

if ($g('csv') === '1') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="historico_' . date('Y-m-d') . '.csv"');
    $o = fopen('php://output', 'w');
    fwrite($o, "\xEF\xBB\xBF");
    fputcsv($o, ['Quando', 'Quem', 'Ação', 'Fornecedor', 'Nota fiscal', 'Detalhes'], ';');
    $st = q($sql . ' LIMIT 20000', $p);
    $cel = fn($v) => preg_match('/^[=+\-@\t\r]/', (string)$v) ? "'" . $v : $v; // evita fórmulas no Excel
    while ($h = $st->fetch()) {
        [$forn, $nf, $mud] = $descr($h);
        fputcsv($o, [br_hora($h['criado_em']), $cel($h['nome'] ?: 'Usuário removido'), $txt[$h['acao']] ?? $h['acao'], $cel(titulo($forn)), $cel($nf), $cel($mud)], ';');
    }
    fclose($o);
    exit;
}

$porPag = 100;
$total = (int)q("SELECT COUNT(*) FROM historico h LEFT JOIN agendamentos a ON a.id = h.agendamento_id WHERE $where", $p)->fetchColumn();
$paginas = max(1, (int)ceil($total / $porPag));
$pag = min($paginas, max(1, (int)($_GET['p'] ?? 1)));
$linhas = q($sql . ' LIMIT ' . $porPag . ' OFFSET ' . (($pag - 1) * $porPag), $p)->fetchAll();
$usuarios = q('SELECT id, nome FROM usuarios ORDER BY nome')->fetchAll();
$qs = fn(array $t) => 'historico.php?' . http_build_query(array_filter(array_merge($_GET, $t), fn($v) => $v !== null && $v !== ''));

adm_topo('Histórico', 'historico');
?>
<div class="pagehead"><h1>Histórico de alterações</h1><p class="muted">Tudo o que foi feito no portal, de quem e quando.</p></div>
<form class="filters" method="get" style="margin:0 0 14px">
  <div class="field"><label for="fu">Quem</label><select id="fu" name="u"><option value="">Todos</option><?php foreach ($usuarios as $u) echo '<option value="' . (int)$u['id'] . '"' . ((int)$g('u') === (int)$u['id'] ? ' selected' : '') . '>' . e($u['nome']) . '</option>'; ?></select></div>
  <div class="field"><label for="fa">Ação</label><select id="fa" name="acao"><option value="">Todas</option><?php foreach ($txt as $k => $l) echo '<option value="' . $k . '"' . ($g('acao') === $k ? ' selected' : '') . '>' . $l . '</option>'; ?></select></div>
  <div class="field"><label for="fd">De</label><input id="fd" type="date" name="de" value="<?= e($g('de')) ?>"></div>
  <div class="field"><label for="ft">Até</label><input id="ft" type="date" name="ate" value="<?= e($g('ate')) ?>"></div>
  <div class="field"><label for="fq">Fornecedor ou NF</label><input id="fq" name="q" value="<?= e($g('q')) ?>" autocomplete="off"></div>
  <div class="field acts" style="flex-direction:row;gap:8px"><button class="btn primary" type="submit">Filtrar</button><a class="btn" href="historico.php">Limpar</a><a class="btn" href="<?= e($qs(['csv' => '1', 'p' => null])) ?>"><?= icone('baixar', 15) ?>CSV</a></div>
</form>
<div class="tablebox" id="adm-h-tabela" data-vivo><table class="cards adm-h" style="min-width:760px">
  <thead><tr><th>Quando</th><th>Quem</th><th>Ação</th><th>Agendamento</th><th>Detalhes</th></tr></thead>
  <tbody>
  <?php foreach ($linhas as $h): [$forn, $nf, $mud] = $descr($h); ?>
    <tr>
      <td class="num"><?= br_hora($h['criado_em']) ?></td>
      <td><?= e($h['nome'] ?: 'Usuário removido') ?></td>
      <td><?= e($txt[$h['acao']] ?? $h['acao']) ?></td>
      <td><?= e(titulo($forn)) ?: '—' ?><?= $nf ? ' <span class="muted mono">NF ' . e($nf) . '</span>' : '' ?></td>
      <td class="small"><?= e($mud) ?></td>
    </tr>
  <?php endforeach; ?>
  <?php if (!$linhas): ?><tr><td colspan="5"><div class="empty"><b>Nada encontrado</b>Ajuste os filtros.</div></td></tr><?php endif; ?>
  </tbody>
</table></div>
<div class="foot" id="adm-h-pe" data-vivo>
  <span class="num"><?= plural($total, 'registro', 'registros') ?></span>
  <?php if ($paginas > 1): ?><nav class="pager">
    <?php if ($pag > 1): ?><a class="btn sm" href="<?= e($qs(['p' => $pag - 1])) ?>">Anterior</a><?php endif; ?>
    <span class="num">Página <?= $pag ?> de <?= $paginas ?></span>
    <?php if ($pag < $paginas): ?><a class="btn sm" href="<?= e($qs(['p' => $pag + 1])) ?>">Próxima</a><?php endif; ?>
  </nav><?php endif; ?>
</div>
<?php adm_rodape();
