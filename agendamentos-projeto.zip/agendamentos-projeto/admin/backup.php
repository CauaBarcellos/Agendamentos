<?php
require __DIR__ . '/../inc/bootstrap.php';
require __DIR__ . '/../inc/admin_auth.php';
require __DIR__ . '/../inc/backup.php';
adm_exigir();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validar();
    @set_time_limit(300);
    $gz = function_exists('gzopen');
    $tmp = tempnam(sys_get_temp_dir(), 'bkp');
    $h = $gz ? gzopen($tmp, 'wb9') : fopen($tmp, 'wb');
    backup_sql($h);
    $gz ? gzclose($h) : fclose($h);
    header('Content-Type: ' . ($gz ? 'application/gzip' : 'application/sql'));
    header('Content-Disposition: attachment; filename="backup_agendamentos_' . date('Y-m-d_His') . '.sql' . ($gz ? '.gz' : '') . '"');
    header('Content-Length: ' . filesize($tmp));
    readfile($tmp);
    unlink($tmp);
    exit;
}

$guardados = glob(dirname(__DIR__) . '/backups/backup_*.sql*') ?: [];
rsort($guardados);
adm_topo('Backup', 'backup');
?>
<div class="pagehead"><h1>Backup do banco</h1><p class="muted">Cópia completa de notas, usuários e histórico.</p></div>
<div class="two-col">
  <form class="card formcard" method="post" style="margin:0">
    <?= csrf_campo() ?>
    <div class="cardhead"><h2>Baixar agora</h2><p class="muted small">Gera um arquivo <code>.sql<?= function_exists('gzopen') ? '.gz' : '' ?></code> para guardar no seu computador. Para restaurar, importe no phpMyAdmin.</p></div>
    <div class="cardfoot"><span class="sp"></span><button class="btn primary" type="submit"><?= icone('baixar', 15) ?>Baixar backup</button></div>
  </form>
  <div class="card" style="margin:0">
    <div class="cardhead"><h2>Backup automático (diário)</h2></div>
    <p class="small">No cPanel, abra <b>Tarefas Cron</b>, escolha “Uma vez por dia” e use o comando:</p>
    <p><code style="display:block;padding:8px;overflow-x:auto">/usr/local/bin/php <?= e(dirname(__DIR__)) ?>/backup_cron.php</code></p>
    <p class="muted small">Guarda os 14 mais recentes na pasta <code>backups/</code> do servidor.</p>
    <?php if ($guardados): ?>
      <p class="small"><b>Último backup no servidor:</b> <?= e(date('d/m/Y H:i', filemtime($guardados[0]))) ?> · <?= count($guardados) ?> guardado<?= count($guardados) > 1 ? 's' : '' ?></p>
    <?php else: ?>
      <p class="small" style="color:var(--late)"><b>Nenhum backup automático encontrado ainda.</b> Configure o cron acima.</p>
    <?php endif; ?>
  </div>
</div>
<?php adm_rodape();
