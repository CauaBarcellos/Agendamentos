import { abrirNavegador } from './cdp.mjs';
const D = process.argv[2], B = 'http://localhost/agendamentos';
const nav = await abrirNavegador({ largura: 390, altura: 844, mobile: true });
try {
  await nav.tela(390, 844, true);
  await nav.ir(B + '/login.php'); await nav.foto(D + '/1-login.png');
  await nav.js(`document.querySelector('#login').value='tmp.a'; document.querySelector('#senha').value='Zq8mTe42xYw'; document.querySelector('form').submit();`);
  await nav.esperar(`typeof window.__agenda === 'object'`, 10000);
  const paginas = [['index.php','2-agenda'],['agendamento.php','3-novo'],['registros.php','4-registros'],['importar.php','5-importar'],['recebidas.php','6-recebidas']];
  for (const [p, n] of paginas) {
    await nav.ir(B + '/' + p); await nav.sleep(500);
    const w = await nav.js(`document.documentElement.scrollWidth`);
    const peq = await nav.js(`[...document.querySelectorAll('a,button,input,select')].filter(e=>{const r=e.getBoundingClientRect();return r.width>0&&(r.height<36||r.width<36)&&getComputedStyle(e).visibility!=='hidden'&&e.type!=='hidden'&&e.type!=='checkbox'}).map(e=>(e.textContent||e.name||e.className).trim().slice(0,20)+':'+Math.round(e.getBoundingClientRect().width)+'x'+Math.round(e.getBoundingClientRect().height)).slice(0,8).join(' | ')`);
    console.log(p.padEnd(18), 'largura', w, w > 391 ? 'ROLAGEM HORIZONTAL' : 'ok', '| alvos pequenos:', peq || 'nenhum');
    await nav.foto(D + '/' + n + '.png');
  }
} catch (e) { console.log('ERR', e.message); } finally { await nav.fechar(); }
process.exit(0);
