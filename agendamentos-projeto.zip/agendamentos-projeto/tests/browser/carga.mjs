// Teste de carga da agenda ao vivo: N pessoas consultando estado.php a cada 8 s (e baixando a página quando muda).
// Uso: php preparar.php && node carga.mjs [pessoas] [segundos] && php limpar.php
const B = 'http://localhost/agendamentos';
const N = +process.argv[2] || 50, SEG = +process.argv[3] || 30, INT = 8000;
const lat = { estado: [], pagina: [] }; let erros = 0, reqs = 0;
const pct = (a, p) => { const s = [...a].sort((x, y) => x - y); return s.length ? s[Math.min(s.length - 1, Math.floor(s.length * p))] : 0; };

async function entrar() {
  const g = await fetch(B + '/login.php'); const ck0 = g.headers.getSetCookie().map(c => c.split(';')[0]).join('; ');
  const html = await g.text(); const tok = /name="csrf"[^>]*value="([^"]+)"/.exec(html)?.[1] ?? /value="([^"]+)"[^>]*name="csrf"/.exec(html)?.[1];
  const r = await fetch(B + '/login.php', { method: 'POST', redirect: 'manual', headers: { cookie: ck0, 'content-type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ login: 'tmp.a', senha: 'Zq8mTe42xYw', csrf: tok ?? '' }) });
  const novos = r.headers.getSetCookie().map(c => c.split(';')[0]);
  const jar = new Map(); for (const c of [...ck0.split('; '), ...novos]) jar.set(c.split('=')[0], c); return [...jar.values()].join('; ');
}
const t0 = Date.now(); const fim = t0 + SEG * 1000;
const ck = await entrar();
const teste = await fetch(B + '/estado.php', { headers: { cookie: ck } });
if (teste.status !== 200) { console.log('Não consegui entrar (HTTP ' + teste.status + '). Cookie: ' + ck.slice(0, 60)); process.exit(1); }
let fp0 = (await teste.json()).fp;

async function cliente(i) {
  await new Promise(r => setTimeout(r, Math.random() * INT)); // chegam espalhados
  let fp = fp0;
  while (Date.now() < fim) {
    let t = performance.now();
    try {
      const r = await fetch(B + '/estado.php', { headers: { cookie: ck }, cache: 'no-store' }); reqs++;
      const j = await r.json(); lat.estado.push(performance.now() - t); if (r.status !== 200) erros++;
      if (j.fp !== fp) { fp = j.fp; t = performance.now(); const p = await fetch(B + '/index.php', { headers: { cookie: ck } }); await p.text(); reqs++; lat.pagina.push(performance.now() - t); if (p.status !== 200) erros++; }
    } catch { erros++; }
    await new Promise(r => setTimeout(r, INT + Math.random() * 1500));
  }
}
// no meio do teste alguém dá baixa/cadastra: todo mundo baixa a página junto (pior caso)
setTimeout(async () => { await fetch(B + '/estado.php', { headers: { cookie: ck } }); const { execFileSync } = await import('node:child_process');
  execFileSync('C:/xampp2/php/php.exe', ['-r', '$_SERVER["SCRIPT_NAME"]="x";$_SERVER["HTTP_HOST"]="localhost";require "C:/xampp2/htdocs/agendamentos/inc/bootstrap.php";q("UPDATE agendamentos SET atualizado_em=NOW() WHERE fornecedor LIKE \\"ZZFORN%\\" LIMIT 1");']); }, SEG * 500);
console.log(`${N} pessoas, ${SEG} s, consulta a cada ~8 s...`);
await Promise.all(Array.from({ length: N }, (_, i) => cliente(i)));
const dur = (Date.now() - t0) / 1000;
const f = (n) => n.toFixed(0) + ' ms';
console.log(`\nRequisições: ${reqs} em ${dur.toFixed(0)} s (${(reqs / dur).toFixed(1)}/s) · erros: ${erros}`);
console.log(`estado.php   n=${lat.estado.length}  mediana ${f(pct(lat.estado, .5))}  p95 ${f(pct(lat.estado, .95))}  máx ${f(Math.max(0, ...lat.estado))}`);
console.log(`página (após mudança) n=${lat.pagina.length}  mediana ${f(pct(lat.pagina, .5))}  p95 ${f(pct(lat.pagina, .95))}  máx ${f(Math.max(0, ...lat.pagina))}`);
process.exit(erros ? 1 : 0);
