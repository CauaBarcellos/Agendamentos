// Teste no navegador: atualização ao vivo da agenda, baixa sem recarregar, filtro e grupos.
// Uso (na pasta tests/browser):  php preparar.php && node live.mjs && php limpar.php
import { abrirNavegador } from './cdp.mjs';
import { execFileSync } from 'node:child_process';
import { mkdirSync } from 'node:fs';

const B = 'http://localhost/agendamentos';
const PW = 'Zq8mTe42xYw';
const FOTOS = process.env.FOTOS || '';
if (FOTOS) mkdirSync(FOTOS, { recursive: true });
let falhas = 0, total = 0;
const ok = (nome, cond, det = '') => { total++; if (!cond) falhas++; console.log((cond ? '  ok    ' : '  FALHA ') + nome + (cond || !det ? '' : '  → ' + det)); };

// "Outra pessoa" (Bruno) mexe por fora, via HTTP.
async function comoBruno() {
  const jar = [];
  const pega = (r) => { for (const c of r.headers.getSetCookie?.() ?? []) { const kv = c.split(';')[0]; const nome = kv.split('=')[0]; const i = jar.findIndex((x) => x.startsWith(nome + '=')); if (i >= 0) jar[i] = kv; else jar.push(kv); } };
  const get = async (u, o = {}) => { const r = await fetch(B + u, { redirect: 'manual', ...o, headers: { cookie: jar.join('; '), ...(o.headers || {}) } }); pega(r); return r; };
  await get('/login.php', { method: 'POST', body: new URLSearchParams({ login: 'tmp.b', senha: PW }) });
  const html = await (await get('/index.php')).text();
  const csrf = /name="csrf" value="([a-f0-9]+)"/.exec(html)?.[1];
  return {
    async baixa(...ids) {
      const fd = new URLSearchParams({ csrf, acao: 'entregue_grupo' });
      ids.forEach((i) => fd.append('ids[]', i));
      const r = await get('/acao.php', { method: 'POST', body: fd, headers: { 'X-Requested-With': 'fetch' } });
      return r.json();
    },
  };
}

const PHP_IDS = '$_SERVER["SCRIPT_NAME"]="x";$_SERVER["HTTP_HOST"]="localhost";require "C:/xampp2/htdocs/agendamentos/inc/bootstrap.php";echo json_encode(q("SELECT id FROM agendamentos WHERE fornecedor LIKE \\"ZZFORN%\\" ORDER BY id")->fetchAll(PDO::FETCH_COLUMN));';
const idsDoDia = () => JSON.parse(execFileSync('C:/xampp2/php/php.exe', ['-r', PHP_IDS]).toString());

const nav = await abrirNavegador({ largura: 1400, altura: 1000 });
try {
  console.log('Login e agenda');
  await nav.ir(B + '/login.php');
  await nav.js(`document.querySelector('#login').value='tmp.a'; document.querySelector('#senha').value='${PW}'; document.querySelector('form').submit();`);
  await nav.esperarCarga();
  await nav.esperar(`typeof window.__agenda === 'object'`, 8000, 'agenda carregada (script)');
  const ids = idsDoDia();
  const meusZZ = () => nav.js(`[...document.querySelectorAll('#painel .row')].filter(r => r.dataset.busca.includes('zzforn')).length`);
  const toast = () => nav.js(`document.getElementById('toast')?.textContent || ''`);
  ok('agenda carregada com as 7 notas de teste', (await meusZZ()) === 7, String(await meusZZ()));
  ok('painel tem impressão digital', /^[a-f0-9]{16}$/.test(await nav.js(`document.getElementById('painel').dataset.fp`)));
  if (FOTOS) await nav.foto(FOTOS + '/1-agenda.png');

  console.log('Filtro e grupos sobrevivem à atualização');
  await nav.js(`const f=document.getElementById('filtro-agenda'); f.value='zzforn a'; f.dispatchEvent(new Event('input',{bubbles:true}));`);
  ok('filtro mostra só as notas "zzforn a"', (await nav.js(`[...document.querySelectorAll('#painel .row')].filter(r => r.style.display !== 'none' && r.dataset.busca.includes('zzforn')).length`)) === 2);
  const grupoDois = `[...document.querySelectorAll('#painel .grp')].find(g => g.querySelector('.tname').textContent.toLowerCase().includes('zztransp dois'))`;
  await nav.js(`${grupoDois}.querySelector('.tog').click()`);
  ok('grupo "ZZTRANSP DOIS" recolhido', await nav.js(`${grupoDois}.classList.contains('shut')`));

  console.log('Outra pessoa dá baixa em 2 notas por fora');
  const bruno = await comoBruno();
  const fpAntes = await nav.js(`document.getElementById('painel').dataset.fp`);
  const r = await bruno.baixa(ids[0], ids[1]);
  ok('baixa feita pelo Bruno', r.ok && r.n === 2, JSON.stringify(r));
  await nav.js(`window.__agenda.checar()`);
  await nav.esperar(`document.getElementById('painel').dataset.fp !== '${fpAntes}'`, 8000, 'fp mudar');
  await nav.esperar(`[...document.querySelectorAll('#painel .row')].filter(r => r.dataset.busca.includes('zzforn')).length === 5`, 8000, '5 notas restantes');
  ok('as 2 notas saíram da tela sem recarregar', (await meusZZ()) === 5);
  ok('o filtro digitado foi mantido', (await nav.js(`document.getElementById('filtro-agenda').value`)) === 'zzforn a');
  ok('o grupo recolhido continuou recolhido', await nav.js(`${grupoDois}.classList.contains('shut')`));
  ok('aviso mostra quem atualizou', (await toast()).includes('Bruno Teste atualizou a agenda'), await toast());
  if (FOTOS) await nav.foto(FOTOS + '/2-atualizada.png');

  console.log('Baixa feita nesta tela (sem recarregar) e contadores');
  const ct = `document.querySelector('.day[aria-current="true"] .ct').firstChild.nodeValue.replace(/\\D/g,'')`;
  const ctAntes = +(await nav.js(ct));
  await nav.js(`document.getElementById('filtro-agenda').value=''; document.getElementById('filtro-agenda').dispatchEvent(new Event('input',{bubbles:true}));`);
  await nav.js(`[...document.querySelectorAll('#painel .row')].find(r => r.dataset.id === '${ids[2]}').querySelector('.check').click()`);
  await nav.esperar(`!!document.querySelector('dialog.rec-modal[open] form')`, 6000, 'janela de conferência');
  ok('o ✓ abre a janela de conferência por cima da agenda', (await nav.js(`document.querySelector('dialog.rec-modal').textContent`)).includes('Chegou tudo certo?') && (await nav.js('location.pathname')).endsWith('index.php'));
  ok('ainda não gravou nada (a linha continua)', await nav.js(`[...document.querySelectorAll('#painel .row')].some(r => r.dataset.id === '${ids[2]}')`));
  await nav.js(`document.querySelector('dialog.rec-modal [data-fechar]').click()`);
  await nav.esperar(`!document.querySelector('dialog.rec-modal')`, 4000, 'janela fechar').catch(() => {});
  ok('"Cancelar" fecha sem gravar', await nav.js(`!document.querySelector('dialog.rec-modal') && [...document.querySelectorAll('#painel .row')].some(r => r.dataset.id === '${ids[2]}')`));
  await nav.js(`[...document.querySelectorAll('#painel .row')].find(r => r.dataset.id === '${ids[2]}').querySelector('.check').click()`);
  await nav.esperar(`!!document.querySelector('dialog.rec-modal[open] form')`, 6000, 'janela de conferência');
  // volumes diferentes com "tudo certo": o servidor recusa e o erro aparece dentro da janela
  await nav.js(`var fm=document.querySelector('dialog.rec-modal form'); fm.vol_recebidos.value='999'; fm.querySelector('input[value=sim]').checked=true; fm.requestSubmit();`);
  await nav.esperar(`!document.querySelector('#rec-erros').hidden`, 6000, 'erro na janela');
  ok('erro aparece dentro da janela, que continua aberta', (await nav.js(`document.querySelector('#rec-erros').textContent`)).includes('não batem') && await nav.js(`!!document.querySelector('dialog.rec-modal[open]')`));
  await nav.js(`var fm=document.querySelector('dialog.rec-modal form'); fm.vol_recebidos.value=fm.vol_recebidos.dataset.esperado; fm.querySelector('input[value=sim]').checked=true; fm.requestSubmit();`);
  await nav.esperar(`![...document.querySelectorAll('#painel .row')].some(r => r.dataset.id === '${ids[2]}')`, 6000, 'linha sumir');
  ok('confirmando, a janela fecha', await nav.js(`!document.querySelector('dialog.rec-modal')`));
  ok('a linha saiu na hora', true);
  ok('aparece o botão Desfazer', await nav.js(`!!document.querySelector('#toast button')`));
  ok('contador do dia diminuiu em 1', +(await nav.js(ct)) === ctAntes - 1, `${ctAntes} -> ${await nav.js(ct)}`);
  await nav.js(`window.__agenda.checar()`);
  await nav.sleep(1500);
  ok('checagem seguinte mantém a tela coerente (4 notas ZZ)', (await meusZZ()) === 4, String(await meusZZ()));
  ok('contador do dia continua certo depois da checagem', +(await nav.js(ct)) === ctAntes - 1, String(await nav.js(ct)));

  console.log('Desfazer');
  await nav.js(`document.querySelector('#toast button').click()`);
  await nav.sleep(1500);
  await nav.esperar(`!!document.getElementById('painel')`, 8000);
  ok('desfazer trouxe a nota de volta (5 notas ZZ)', (await meusZZ()) === 5, String(await meusZZ()));

  console.log('Outra pessoa recebe tudo que sobrou');
  const resto = idsDoDia().filter((i) => !ids.slice(0, 2).includes(i));
  const fp2 = await nav.js(`document.getElementById('painel').dataset.fp`);
  await bruno.baixa(...resto);
  await nav.js(`window.__agenda.checar()`);
  await nav.esperar(`document.getElementById('painel').dataset.fp !== '${fp2}'`, 8000, 'fp mudar de novo');
  ok('tela continua utilizável', await nav.js(`!!document.getElementById('painel')`));
  ok('nenhuma nota ZZ sobrou na tela', (await meusZZ()) === 0, String(await meusZZ()));
  if (FOTOS) await nav.foto(FOTOS + '/3-tudo-recebido.png');

  console.log('Sem conexão: selo aparece e some sozinho');
  await nav.js(`window.__fetch0 = window.fetch; window.fetch = () => Promise.reject(new TypeError('offline'))`);
  await nav.js(`window.__agenda.checar()`); await nav.sleep(300);
  await nav.js(`window.__agenda.checar()`); await nav.sleep(300);
  ok('selo "Sem conexão" aparece após 2 falhas', await nav.js(`!!document.querySelector('.offline')`));
  await nav.js(`window.fetch = window.__fetch0`);
  await nav.js(`window.__agenda.checar()`); await nav.sleep(800);
  ok('selo some quando a conexão volta', await nav.js(`!document.querySelector('.offline')`));

  console.log('Sessão expirada interrompe a consulta');
  await nav.js(`fetch('logout.php')`);
  await nav.sleep(600);
  await nav.js(`window.__agenda.checar()`);
  await nav.sleep(1200);
  ok('aviso de sessão expirada', (await toast()).includes('sessão expirou'), await toast());
} catch (e) {
  falhas++;
  console.log('  ERRO   ' + e.message);
} finally {
  await nav.fechar();
}
console.log(`\n${falhas ? falhas + ' de ' + total + ' verificações falharam.' : 'Todas as ' + total + ' verificações passaram.'}`);
process.exit(falhas ? 1 : 0);
