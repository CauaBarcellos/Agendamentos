// Teste no navegador do calendário: visão do mês, visão da semana, arrastar para reagendar, "Mudar dia" e permissões.
// Uso (na pasta tests/browser):  php preparar.php && node calendario.mjs && php limpar.php
import { abrirNavegador } from './cdp.mjs';
import { execFileSync } from 'node:child_process';
import { mkdirSync } from 'node:fs';

const B = 'http://localhost/agendamentos';
const PW = 'Zq8mTe42xYw';
const FOTOS = process.env.FOTOS || '';
if (FOTOS) mkdirSync(FOTOS, { recursive: true });
let falhas = 0, total = 0;
const ok = (nome, cond, det = '') => { total++; if (!cond) falhas++; console.log((cond ? '  ok    ' : '  FALHA ') + nome + (cond || !det ? '' : '  → ' + det)); };
const php = (c) => execFileSync('C:/xampp2/php/php.exe', ['-r', '$_SERVER["SCRIPT_NAME"]="x";$_SERVER["HTTP_HOST"]="localhost";require "C:/xampp2/htdocs/agendamentos/inc/bootstrap.php";' + c]).toString();
const hoje = php('echo hoje();'), amanha = php('echo soma_dias(hoje(), 1);'), ontem = php('echo soma_dias(hoje(), -1);');
const col = (forn, campo) => php(`echo q("SELECT ${campo} FROM agendamentos WHERE fornecedor = ?", ["${forn}"])->fetchColumn();`);
const idDe = (forn) => col(forn, 'id');

// Notas para a bandeja: sem data, atrasada, do ES que chegou (sem dia) e do ES que ainda não chegou.
const uid = php('echo q("SELECT id FROM usuarios WHERE login = \\"tmp.a\\"")->fetchColumn();');
for (const [forn, uf, dataR, chegou] of [['ZZCAL SEMDATA', 'RJ', null, null], ['ZZCAL ATRASADA', 'RJ', ontem, null], ['ZZCAL ES CHEGOU', 'ES', null, hoje], ['ZZCAL ES ANTIGA', 'ES', amanha, null], ['ZZCAL VELHA', 'RJ', amanha, null]]) {
  php(`q("INSERT INTO agendamentos (empresa, uf, fornecedor, nota_fiscal, volumes, volumes_num, data_receber, chegou_es_em, entregue, origem, criado_por, criado_em) VALUES (\\"GREEN MED\\", ?, ?, \\"7\\", \\"3\\", 3, ?, ?, \\"N\\", \\"portal\\", ${uid}, NOW())", ["${uf}", "${forn}", ${dataR ? `"${dataR}"` : 'null'}, ${chegou ? `"${chegou}"` : 'null'}]);`);
}
// leitor (só consulta)
php(`q("INSERT INTO usuarios (nome, login, senha_hash, perfil, ativo, trocar_senha, criado_em) VALUES (\\"Leo Leitor\\", \\"tmp.leitor\\", ?, \\"leitor\\", 1, 0, NOW())", [password_hash("${PW}", PASSWORD_DEFAULT)]);`);

const nav = await abrirNavegador({ porta: 9401, largura: 1366, altura: 1000 });
const entrar = async (login) => {
  await nav.ir(B + '/logout.php');
  await nav.ir(B + '/login.php');
  await nav.js(`document.querySelector('#login').value='${login}'; document.querySelector('#senha').value='${PW}'; document.querySelector('form').submit();`);
  await nav.esperar(`document.readyState === 'complete' && !location.pathname.endsWith('login.php')`, 10000, 'entrar como ' + login);
};
const cartao = (forn) => `[...document.querySelectorAll('#cal .cal-nota')].find(n => n.textContent.toLowerCase().includes('${forn.toLowerCase()}'))`;
// Simula arrastar e soltar (os mesmos eventos que o navegador dispara).
const arrastar = (forn, dia) => nav.js(`(() => {
  const n = ${cartao(forn)}, alvo = document.querySelector('.cal-col[data-dia="${dia}"] .cal-lista') || document.querySelector('.cal-col[data-dia="${dia}"]');
  if (!n || !alvo) return 'sem cartão ou dia';
  const dt = new DataTransfer();
  n.dispatchEvent(new DragEvent('dragstart', { bubbles: true, dataTransfer: dt }));
  const ev = new DragEvent('dragover', { bubbles: true, cancelable: true, dataTransfer: dt });
  alvo.dispatchEvent(ev);
  const aceitou = ev.defaultPrevented;
  alvo.dispatchEvent(new DragEvent('drop', { bubbles: true, cancelable: true, dataTransfer: dt }));
  n.dispatchEvent(new DragEvent('dragend', { bubbles: true, dataTransfer: dt }));
  return aceitou ? 'aceitou' : 'recusou';
})()`);
const toast = () => nav.js(`document.getElementById('toast')?.textContent || ''`);

try {
  await entrar('tmp.a');

  console.log('Visão do mês');
  await nav.ir(B + '/calendario.php');
  ok('aba "Calendário" no topo', await nav.js(`[...document.querySelectorAll('nav.tabs .tab')].some(t => t.textContent.includes('Calendário') && t.getAttribute('aria-current') === 'page')`));
  const nHoje = php(`echo q("SELECT COUNT(*) FROM agendamentos WHERE data_receber = ?", ["${hoje}"])->fetchColumn();`);
  ok('hoje destacado com o número certo de notas', (await nav.js(`document.querySelector('.cal-cel.hoje .cal-n')?.textContent.replace(/\\D/g, '')`)) === nHoje, nHoje);
  ok('o mês tem de 28 a 42 dias na grade (semanas completas)', await nav.js(`(() => { const n = document.querySelectorAll('.cal-cel').length; return n % 7 === 0 && n >= 28 && n <= 42; })()`));
  ok('clicar no dia leva para a agenda daquele dia', (await nav.js(`document.querySelector('.cal-cel.hoje').getAttribute('href')`)) === 'index.php?dia=' + hoje);
  if (FOTOS) await nav.foto(FOTOS + '/cal-1-mes.png');
  await nav.js(`document.querySelector('.cal-seta.prox').click()`);
  await nav.esperar(`document.readyState === 'complete' && location.search.includes('d=')`, 8000);
  ok('seta avança para o mês seguinte', !(await nav.js(`!!document.querySelector('.cal-cel.hoje')`)) || (await nav.js(`location.search`)).includes('d='));

  console.log('Visão da semana (semana de amanhã)');
  await nav.ir(B + '/calendario.php?ver=semana&d=' + amanha);
  ok('7 colunas de dias', (await nav.js(`document.querySelectorAll('.cal-col').length`)) === 7);
  ok('bandeja com "Sem data", "Atrasadas" e "Chegaram no ES"', await nav.js(`['Sem data','Atrasadas','Chegaram no ES'].every(t => [...document.querySelectorAll('.cal-grupo summary')].some(s => s.textContent.includes(t)))`));
  ok('nota do ES que ainda não chegou não pode ser arrastada', await nav.js(`!${cartao('zzcal es antiga')}.classList.contains('movel')`));
  ok('dia que já passou não aceita nota', !(await nav.js(`!!document.querySelector('.cal-col[data-dia="${ontem}"]')`)) || (await nav.js(`!document.querySelector('.cal-col[data-dia="${ontem}"]').hasAttribute('data-alvo')`)));
  if (FOTOS) await nav.foto(FOTOS + '/cal-2-semana.png');

  console.log('Arrastar para reagendar');
  ok('soltar "sem data" em amanhã é aceito', (await arrastar('zzcal semdata', amanha)) === 'aceitou');
  await nav.esperar(`(document.getElementById('toast')?.textContent || '').includes('passou para')`, 8000, 'aviso');
  ok('gravou o novo dia', col('ZZCAL SEMDATA', 'data_receber') === amanha);
  await nav.esperar(`!!document.querySelector('.cal-col[data-dia="${amanha}"]') && [...document.querySelectorAll('.cal-col[data-dia="${amanha}"] .cal-nota')].some(n => n.textContent.toLowerCase().includes('zzcal semdata')) && ![...document.querySelectorAll('.cal-bandeja .cal-nota')].some(n => n.textContent.toLowerCase().includes('zzcal semdata'))`, 8000, 'tela atualizar');
  ok('saiu da bandeja e apareceu no dia', true);
  await arrastar('zzcal es chegou', amanha);
  await nav.esperar(`(document.getElementById('toast')?.textContent || '').includes('ZZCAL ES') || (document.getElementById('toast')?.textContent || '').toLowerCase().includes('zzcal es')`, 8000, 'aviso ES');
  ok('nota do ES que chegou também pode ser agendada arrastando', col('ZZCAL ES CHEGOU', 'data_receber') === amanha);
  const hist = php(`echo q("SELECT detalhes FROM historico WHERE agendamento_id = ? ORDER BY id DESC LIMIT 1", [${idDe('ZZCAL SEMDATA')}])->fetchColumn();`);
  ok('fica no histórico (dia antigo → novo)', hist.includes(amanha), hist);

  console.log('Tela desatualizada');
  await nav.ir(B + '/calendario.php?ver=semana&d=' + amanha);
  php(`q("UPDATE agendamentos SET data_receber = ? WHERE fornecedor = \\"ZZCAL VELHA\\"", [soma_dias(hoje(), 3)]);`);
  const destino = await nav.js(`[...document.querySelectorAll('.cal-col[data-alvo]')].map(c => c.dataset.dia).find(d => d !== '${amanha}') || ''`);
  if (destino) {
    await arrastar('zzcal velha', destino);
    await nav.esperar(`(document.getElementById('toast')?.textContent || '').includes('mudou enquanto')`, 8000, 'aviso de conflito');
    ok('quem mudou antes vence: aviso e a nota volta para onde estava', col('ZZCAL VELHA', 'data_receber') === php('echo soma_dias(hoje(), 3);') && (await nav.js(`!!document.querySelector('.cal-col[data-dia="${amanha}"]') && [...document.querySelectorAll('.cal-col[data-dia="${amanha}"] .cal-nota')].some(n => n.textContent.toLowerCase().includes('zzcal velha'))`)));
  } else ok('(sem outro dia futuro nesta semana para o teste de conflito)', true);

  console.log('"Mudar dia" (sem arrastar, para celular e teclado)');
  await nav.ir(B + '/calendario.php?ver=semana&d=' + amanha);
  const novo = php('echo soma_dias(hoje(), 2);');
  await nav.js(`(() => { const n = ${cartao('zzcal atrasada')}; const d = n.querySelector('details'); d.open = true; const f = d.querySelector('form'); f.data_receber.value = '${novo}'; f.submit(); })()`);
  await nav.esperar(`document.readyState === 'complete' && !!document.querySelector('.flash')`, 8000, 'mensagem');
  ok('"Mudar dia" grava e volta para o calendário', col('ZZCAL ATRASADA', 'data_receber') === novo && (await nav.js('location.pathname')).endsWith('calendario.php'));
  const passado = await nav.js(`fetch('acao.php', { method: 'POST', headers: { 'X-Requested-With': 'fetch' }, body: new URLSearchParams({ csrf: document.querySelector('input[name=csrf]').value, acao: 'reagendar', id: '${idDe('ZZCAL ATRASADA')}', de: '${novo}', data_receber: '${ontem}' }) }).then(r => r.json())`);
  ok('não deixa mandar para um dia que já passou', passado.ok === false && col('ZZCAL ATRASADA', 'data_receber') === novo, JSON.stringify(passado));
  const recebida = await nav.js(`(() => { const n = [...document.querySelectorAll('#cal .cal-nota.feita')][0]; return n ? n.classList.contains('movel') : false; })()`);
  ok('nota já recebida não se move', recebida === false);

  console.log('Ao vivo: outra pessoa muda o dia');
  await nav.ir(B + '/calendario.php?ver=semana&d=' + amanha);
  await nav.esperar(`typeof window.__cal === 'object'`, 8000, 'calendário carregado');
  const bruno = php('echo q("SELECT id FROM usuarios WHERE login = \\"tmp.b\\"")->fetchColumn();');
  const naColuna = (forn, dia) => nav.js(`!!document.querySelector('.cal-col[data-dia="${dia}"]') && [...document.querySelectorAll('.cal-col[data-dia="${dia}"] .cal-nota')].some(n => n.textContent.toLowerCase().includes('${forn}'))`);
  const fpAntes = await nav.js(`document.getElementById('cal').dataset.fp`);
  // Bruno tira a nota "sem data" de amanhã e devolve para sem data (pelo banco, como se fosse outra tela)
  php(`q("UPDATE agendamentos SET data_receber = NULL, atualizado_por = ${bruno}, atualizado_em = NOW() WHERE fornecedor = \\"ZZCAL SEMDATA\\"");`);
  await nav.js(`window.__cal.checar()`);
  await nav.esperar(`document.getElementById('cal').dataset.fp !== '${fpAntes}'`, 8000, 'calendário atualizar');
  ok('a nota saiu de amanhã sem recarregar a página', !(await naColuna('zzcal semdata', amanha)));
  ok('e voltou para a bandeja "Sem data"', await nav.js(`[...document.querySelectorAll('.cal-bandeja .cal-nota')].some(n => n.textContent.toLowerCase().includes('zzcal semdata'))`));
  ok('aviso diz quem mudou', (await toast()).includes('Bruno Teste atualizou o calendário'), await toast());

  console.log('Ao vivo: não troca a tela enquanto a pessoa está mexendo');
  await nav.js(`(() => { const d = ${cartao('zzcal velha')}.querySelector('details'); d.open = true; })()`);
  const fp2 = await nav.js(`document.getElementById('cal').dataset.fp`);
  php(`q("UPDATE agendamentos SET data_receber = ?, atualizado_por = ${bruno}, atualizado_em = NOW() WHERE fornecedor = \\"ZZCAL SEMDATA\\"", ["${amanha}"]);`);
  await nav.js(`window.__cal.checar()`);
  await nav.sleep(1500);
  ok('com "Mudar dia" aberto, a tela não muda', (await nav.js(`document.getElementById('cal').dataset.fp`)) === fp2 && await nav.js(`${cartao('zzcal velha')}.querySelector('details').open`));
  await nav.js(`${cartao('zzcal velha')}.querySelector('details').open = false`);
  await nav.js(`window.__cal.checar()`);
  await nav.esperar(`document.getElementById('cal').dataset.fp !== '${fp2}'`, 8000, 'atualizar depois de fechar');
  ok('ao fechar, atualiza na consulta seguinte', await naColuna('zzcal semdata', amanha));

  console.log('Ao vivo: visão do mês');
  await nav.ir(B + '/calendario.php?d=' + amanha);
  await nav.esperar(`typeof window.__cal === 'object'`, 8000);
  const celula = `[...document.querySelectorAll('.cal-cel')].find(c => c.getAttribute('href') === 'index.php?dia=${amanha}')`;
  const antes = +(await nav.js(`(${celula})?.querySelector('.cal-n')?.textContent.replace(/\\D/g, '') || 0`));
  php(`q("INSERT INTO agendamentos (empresa, uf, fornecedor, nota_fiscal, data_receber, entregue, origem, criado_por, criado_em, atualizado_por, atualizado_em) VALUES (\\"GREEN MED\\", \\"RJ\\", \\"ZZCAL NOVA\\", \\"1\\", ?, \\"N\\", \\"portal\\", ${bruno}, NOW(), ${bruno}, NOW())", ["${amanha}"]);`);
  await nav.js(`window.__cal.checar()`);
  await nav.esperar(`+((${celula})?.querySelector('.cal-n')?.textContent.replace(/\\D/g, '') || 0) === ${antes + 1}`, 8000, 'contagem do dia aumentar');
  ok('nota nova aparece na contagem do dia', true);

  console.log('Permissões');
  await entrar('tmp.leitor');
  await nav.ir(B + '/calendario.php?ver=semana&d=' + amanha);
  ok('leitor vê o calendário, mas sem bandeja e sem arrastar', await nav.js(`!document.querySelector('.cal-bandeja') && !document.querySelector('.cal-nota.movel') && !document.querySelector('.cal-col[data-alvo]')`));
  await entrar('tmp.es');
  await nav.ir(B + '/calendario.php');
  ok('filial ES não abre o calendário do RJ', (await nav.js('location.pathname')).endsWith('es.php'));

  console.log('Celular');
  await entrar('tmp.a');
  await nav.tela(390, 844, true);
  for (const p of ['calendario.php', 'calendario.php?ver=semana&d=' + amanha]) {
    await nav.ir(B + '/' + p);
    ok(`${p.includes('semana') ? 'semana' : 'mês'} sem rolagem lateral`, await nav.js(`document.documentElement.scrollWidth <= 391`), String(await nav.js(`document.documentElement.scrollWidth`)));
  }
  ok('na semana, os dias vêm antes da bandeja', await nav.js(`document.querySelector('.cal-dias').getBoundingClientRect().top < document.querySelector('.cal-bandeja').getBoundingClientRect().top`));
  ok('"Mudar dia" sempre visível no toque', await nav.js(`getComputedStyle(document.querySelector('.cal-nota.movel .cal-mover > summary')).opacity === '1'`));
  if (FOTOS) await nav.foto(FOTOS + '/cal-3-celular.png');
} catch (e) {
  falhas++;
  console.log('  ERRO   ' + e.message);
} finally {
  await nav.fechar();
}
console.log(`\n${falhas ? falhas + ' de ' + total + ' verificações falharam.' : 'Todas as ' + total + ' verificações passaram.'}`);
process.exit(falhas ? 1 : 0);
