<?php
/** Cria usuários e notas de teste para os testes no navegador. Uso: php preparar.php   (limpar.php desfaz) */
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
$_SERVER['SCRIPT_NAME'] = 'x.php'; $_SERVER['HTTP_HOST'] = 'localhost';
require dirname(__DIR__, 2) . '/inc/bootstrap.php';
$pw = 'Zq8mTe42xYw';
foreach (q('SELECT id FROM agendamentos WHERE fornecedor LIKE "ZZ%"')->fetchAll(PDO::FETCH_COLUMN) as $i) { q('DELETE FROM historico WHERE agendamento_id = ?', [$i]); q('DELETE FROM agendamentos WHERE id = ?', [$i]); }
q('DELETE FROM usuarios WHERE login LIKE "tmp.%"');
foreach (['tmp.a' => 'Ana Teste', 'tmp.b' => 'Bruno Teste', 'tmp.adm' => 'Admin Teste', 'tmp.es' => 'Elisa Filial'] as $login => $nome) {
    q('INSERT INTO usuarios (nome, login, senha_hash, perfil, ativo, trocar_senha, criado_em) VALUES (?,?,?,?,1,0,NOW())', [$nome, $login, password_hash($pw, PASSWORD_DEFAULT), $login === 'tmp.adm' ? 'admin' : ($login === 'tmp.es' ? 'filial_es' : 'operador')]);
}
$uid = (int)q('SELECT id FROM usuarios WHERE login = "tmp.a"')->fetchColumn();
$h = date('Y-m-d');
$n = 0;
foreach (['ZZTRANSP UM' => 4, 'ZZTRANSP DOIS' => 3] as $tr => $qtd) {
    for ($i = 1; $i <= $qtd; $i++) {
        q('INSERT INTO agendamentos (data_agendamento, empresa, uf, transportadora, fornecedor, produto, categoria, nota_fiscal, volumes, volumes_num, data_receber, entregue, origem, criado_por, criado_em, atualizado_por, atualizado_em)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,"N","portal",?,NOW(),?,NOW())', [$h, 'GREEN MED', 'RJ', $tr, 'ZZFORN ' . chr(64 + $i) . ($tr === 'ZZTRANSP UM' ? '1' : '2'), 'MATERIAL', 'Material', (string)(880000 + $n), (string)($i * 2), $i * 2, $h, $uid, $uid]);
        $n++;
    }
}
echo json_encode(['senha' => $pw, 'notas' => $n, 'dia' => $h]);
