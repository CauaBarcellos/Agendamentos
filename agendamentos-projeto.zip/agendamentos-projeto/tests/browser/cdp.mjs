// Controlador mínimo do Chrome (protocolo DevTools) — sem dependências, só Node 22+.
import { spawn } from 'node:child_process';
import { mkdtempSync, writeFileSync, existsSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const CHROME = ['C:/Program Files/Google/Chrome/Application/chrome.exe', 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe'];
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export async function abrirNavegador({ porta = 9333, largura = 1400, altura = 900, mobile = false, extras = [] } = {}) {
  const exe = CHROME.find((p) => existsSync(p)) ?? CHROME[0];
  const dir = mkdtempSync(join(tmpdir(), 'chrome-'));
  const proc = spawn(exe, ['--headless=new', `--remote-debugging-port=${porta}`, `--user-data-dir=${dir}`, '--no-first-run', '--disable-gpu', '--hide-scrollbars', `--window-size=${largura},${altura}`, ...extras, 'about:blank'], { stdio: 'ignore' });
  let alvo;
  for (let i = 0; i < 50 && !alvo; i++) {
    try { alvo = await (await fetch(`http://127.0.0.1:${porta}/json/new?about:blank`, { method: 'PUT' })).json(); } catch { await sleep(200); }
  }
  if (!alvo) { proc.kill(); throw new Error('Chrome não respondeu'); }
  const ws = new WebSocket(alvo.webSocketDebuggerUrl);
  await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });
  let id = 0; const pend = new Map(); const eventos = [];
  ws.onmessage = (m) => {
    const d = JSON.parse(m.data);
    if (d.id && pend.has(d.id)) { const { res, rej } = pend.get(d.id); pend.delete(d.id); d.error ? rej(new Error(d.error.message)) : res(d.result); }
    else if (d.method) eventos.push(d);
  };
  // sessionId: para falar com outro alvo (ex.: o service worker) anexado com flatten
  const send = (method, params = {}, sessionId) => new Promise((res, rej) => { const i = ++id; pend.set(i, { res, rej }); ws.send(JSON.stringify({ id: i, method, params, ...(sessionId ? { sessionId } : {}) })); });
  await send('Page.enable'); await send('Runtime.enable');
  await send('Emulation.setDeviceMetricsOverride', { width: largura, height: altura, deviceScaleFactor: 1, mobile });

  const api = {
    send, eventos,
    async ir(url) { eventos.length = 0; await send('Page.navigate', { url }); await api.esperarCarga(); },
    async esperarCarga(ms = 15000) { const t = Date.now(); while (Date.now() - t < ms) { if (eventos.some((e) => e.method === 'Page.loadEventFired')) return; await sleep(50); } throw new Error('timeout de carga'); },
    async js(expr) {
      const r = await send('Runtime.evaluate', { expression: expr, awaitPromise: true, returnByValue: true });
      if (r.exceptionDetails) throw new Error(r.exceptionDetails.exception?.description || r.exceptionDetails.text);
      return r.result.value;
    },
    async esperar(expr, ms = 10000, msg = expr) { const t = Date.now(); while (Date.now() - t < ms) { try { if (await api.js(expr)) return true; } catch {} await sleep(100); } throw new Error('timeout esperando: ' + msg); },
    async arquivos(seletor, caminhos) {
      await api.esperar(`!!document.querySelector(${JSON.stringify(seletor)})`, 8000, seletor);
      const { root } = await send('DOM.getDocument', {});
      const { nodeId } = await send('DOM.querySelector', { nodeId: root.nodeId, selector: seletor });
      await send('DOM.setFileInputFiles', { nodeId, files: caminhos });
    },
    async tela(largura, altura, mobile = false) {
      await send('Emulation.setDeviceMetricsOverride', { width: largura, height: altura, deviceScaleFactor: 1, mobile });
      await send('Emulation.setTouchEmulationEnabled', { enabled: mobile, maxTouchPoints: mobile ? 5 : 1 }); // celular: toque, sem mouse (hover)
    },
    async foto(arquivo) { const r = await send('Page.captureScreenshot', { format: 'png' }); writeFileSync(arquivo, Buffer.from(r.data, 'base64')); },
    async fechar() { try { ws.close(); } catch {} proc.kill(); },
    sleep,
  };
  return api;
}
