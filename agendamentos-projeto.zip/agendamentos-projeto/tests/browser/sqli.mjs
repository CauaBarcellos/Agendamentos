// Teste de injeção de SQL (e de script na tela) contra o site local.
// Manda entradas típicas de ataque em todos os campos de busca/filtro/formulário e confere que:
//   - nada vira erro 500 nem mostra mensagem do banco;
//   - "OR 1=1" não traz notas a mais;
//   - "SLEEP()" não atrasa a resposta;
//   - o texto malicioso é gravado como texto comum (a tabela continua lá) e aparece escapado na tela.
// Uso (na pasta tests/browser):  php preparar.php && node sqli.mjs && php limpar.php
import { execFileSync } from 'node:child_process';

const B = 'http://localhost/agendamentos';
const PW = 'Zq8mTe42xYw';
let falhas = 0, total = 0;
const ok = (nome, cond, det = '') => { total++; if (!cond) falhas++; console.log((cond ? '  ok    ' : '  FALHA ') + nome + (cond || !det ? '' : '  → ' + det)); };

class Sessao {
  jar = new Map();
  guardar(r) { for (const c of r.headers.getSetCookie()) { const [nv] = c.split(';'); const i = nv.indexOf('='); this.jar.set(nv.slice(0, i), nv.slice(i + 1)); } }
  cookie() { return [...this.jar].map(([k, v]) => k + '=' + v).join('; '); }
  async pedir(caminho, opc = {}) {
    const t = performance.now();
    const r = await fetch(B + caminho, { redirect: 'manual', ...opc, headers: { cookie: this.cookie(), ...(opc.headers || {}) } });
    this.guardar(r);
    const texto = await r.text();
    return { status: r.status, texto, ms: performance.now() - t, local: r.headers.get('location') || '' };
  }
  get(caminho) { return this.pedir(caminho); }
  post(caminho, campos) { return this.pedir(caminho, { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams(campos) }); }
  async csrf(caminho) { const r = await this.get(caminho); return /name="csrf"[^>]*value="([^"]+)"/.exec(r.texto)?.[1] ?? ''; }
}

const php = (codigo) => execFileSync('C:/xampp2/php/php.exe', ['-r', '$_SERVER["SCRIPT_NAME"]="x";$_SERVER["HTTP_HOST"]="localhost";require "C:/xampp2/htdocs/agendamentos/inc/bootstrap.php";' + codigo]).toString();

const ATAQUES = [
  "' OR '1'='1", "' OR 1=1 -- ", "\" OR \"1\"=\"1", "') OR ('1'='1", "' UNION SELECT 1,2,3,4,5 -- ",
  "'; DROP TABLE agendamentos; -- ", "1; DELETE FROM usuarios; -- ", "' AND SLEEP(4) -- ", "1' AND (SELECT 1 FROM (SELECT SLEEP(4))x) -- ",
  "\\' OR 1=1 #", "%' OR '%'='", "admin'/*", "' OR ''='", "1 OR 1=1", "' ; SELECT * FROM usuarios -- ", "<script>alert(1)</script>",
];
const ASSINATURA_ERRO = /SQLSTATE|syntax error|PDOException|mysqli|You have an error in your SQL|Warning:|Fatal error|Stack trace|on line \d+/i;

const ana = new Sessao(), adm = new Sessao(), filial = new Sessao();
const totalNotas = () => +php('echo q("SELECT COUNT(*) FROM agendamentos")->fetchColumn();');
const totalUsuarios = () => +php('echo q("SELECT COUNT(*) FROM usuarios")->fetchColumn();');

try {
  const notas0 = totalNotas(), usuarios0 = totalUsuarios(), admins0 = php('echo q("SELECT COUNT(*) FROM usuarios WHERE perfil=\\"admin\\"")->fetchColumn();');

  console.log('Entrar (portal e admin)');
  let r = await ana.post('/login.php', { login: 'tmp.a', senha: PW });
  ok('portal: login normal funciona', r.status === 302, String(r.status));
  r = await adm.post('/admin/login.php', { login: 'tmp.adm', senha: PW });
  ok('admin: login normal funciona', r.status === 302, String(r.status));
  r = await filial.post('/login.php', { login: 'tmp.es', senha: PW });
  ok('filial ES: login normal funciona', r.status === 302, String(r.status));

  console.log('Tela de login com ataques (tentativas poucas, para não bloquear o IP)');
  for (const [i, a] of ["admin' OR '1'='1' -- ", "' OR 1=1 -- "].entries()) {
    const s = new Sessao();
    r = await s.post('/login.php', { login: a, senha: a });
    ok(`login.php #${i + 1}: não entra e não dá erro`, r.status === 200 && !ASSINATURA_ERRO.test(r.texto) && /incorretos/.test(r.texto), `${r.status} ${r.local}`);
  }
  r = await new Sessao().post('/admin/login.php', { login: "' OR '1'='1' -- ", senha: "x' OR '1'='1" });
  ok('admin/login.php: não entra e não dá erro', r.status === 200 && !ASSINATURA_ERRO.test(r.texto), `${r.status} ${r.local}`);

  console.log('Buscas e filtros (GET) com ' + ATAQUES.length + ' ataques em cada parâmetro');
  const rotas = [
    ['registros.php', ['q', 'tr', 'emp', 'st', 'uf', 'de', 'ate', 'ord', 'dir', 'p'], ana],
    ['exportar.php', ['q', 'tr', 'st', 'uf', 'de', 'ate', 'ord', 'dir'], ana],
    ['index.php', ['dia', 'emp'], ana],
    ['recebidas.php', ['q'], ana],
    ['es.php', ['q'], filial],
    ['entrada.php', ['q'], ana],
    ['receber.php', ['id', 'volta'], ana],
    ['receber_grupo.php', ['ids[]'], ana],
    ['calendario.php', ['ver', 'd'], ana],
    ['push.php', ['acao'], ana],
    ['agendamento.php', ['id', 'editar'], ana],
    ['admin/historico.php', ['q', 'u', 'acao', 'de', 'ate', 'p'], adm],
  ];
  const base = {};
  for (const [rota, params, s] of rotas) {
    let erros = 0, lentos = 0, vazamentos = 0, extra = 0, tot = 0, detalhe = '';
    base[rota] = (await s.get('/' + rota)).texto.length;
    for (const p of params) for (const a of ATAQUES) {
      tot++;
      const x = await s.get(`/${rota}?${p}=${encodeURIComponent(a)}`);
      if (x.status >= 500) { erros++; detalhe ||= `${p}=${a} → HTTP ${x.status}`; }
      if (ASSINATURA_ERRO.test(x.texto)) { vazamentos++; detalhe ||= `${p}=${a} → mensagem de erro na tela`; }
      if (x.ms > 2500) { lentos++; detalhe ||= `${p}=${a} → ${Math.round(x.ms)} ms`; }
      if (/<script>alert\(1\)<\/script>/.test(x.texto)) { vazamentos++; detalhe ||= `${p}=${a} → script sem escapar`; }
    }
    ok(`${rota}: ${tot} ataques sem erro 500, sem mensagem do banco, sem atraso, sem script solto`, !erros && !lentos && !vazamentos, detalhe);
  }

  console.log('Todas as telas abrem sem erro (consultas preparadas de verdade)');
  const idNota = php('echo q("SELECT id FROM agendamentos ORDER BY id DESC LIMIT 1")->fetchColumn();');
  const idUsu = php('echo q("SELECT id FROM usuarios WHERE login=\\"tmp.a\\"")->fetchColumn();');
  for (const [s, rotas2] of [[ana, ['/index.php', '/index.php?dia=atrasados', '/index.php?dia=semdata', '/index.php?emp=ESTEVIA', '/index.php?emp=todas', '/registros.php?st=pend&de=2026-01-01&ate=2026-12-31&uf=ES&tr=a&q=a+b+c&ord=forn&dir=asc&p=2', '/recebidas.php', '/recebidas.php?q=amed', '/importar.php', '/agendamento.php', '/agendamento.php?id=' + idNota, '/agendamento.php?id=' + idNota + '&editar=1', '/senha.php', '/exportar.php?st=entregue', '/estado.php']],
                               [adm, ['/admin/index.php', '/admin/index.php?id=' + idUsu, '/admin/painel.php', '/admin/historico.php', '/admin/historico.php?acao=criou&q=a&u=' + idUsu + '&de=2026-01-01&ate=2026-12-31', '/admin/historico.php?csv=1', '/admin/backup.php']]]) {
    let ruins = [];
    for (const rt of rotas2) { const x = await s.get(rt); if (x.status >= 500 || ASSINATURA_ERRO.test(x.texto)) ruins.push(rt + ' → ' + x.status); }
    ok(`${rotas2.length} telas ${s === ana ? 'do portal' : 'do admin'} abrem sem erro`, !ruins.length, ruins.join(' | '));
  }
  console.log('Admin: criar, editar e redefinir senha de usuário (com texto malicioso)');
  const ta = await adm.csrf('/admin/index.php');
  r = await adm.post('/admin/index.php', { csrf: ta, id: '0', nome: "Teste'; DROP TABLE usuarios; --", login: 'tmp.sqli', perfil: 'leitor', ativo: '1', senha: 'Kx7pQw93mZt' });
  ok('criar usuário com nome malicioso funciona (redireciona)', r.status === 302, `${r.status}`);
  const novoId = php('echo q("SELECT id FROM usuarios WHERE login=\\"tmp.sqli\\"")->fetchColumn();');
  ok('o usuário foi gravado e a tabela continua', +novoId > 0 && totalUsuarios() === usuarios0 + 1);
  r = await adm.post('/admin/index.php', { csrf: ta, acao: 'redefinir', id: String(novoId) });
  ok('redefinir senha não dá erro', r.status < 500 && !ASSINATURA_ERRO.test(r.texto), String(r.status));
  r = await adm.post('/admin/index.php', { csrf: ta, id: String(novoId) + ' OR 1=1', nome: 'X', login: "tmp.sqli' OR '1'='1", perfil: 'leitor', ativo: '1' });
  ok('editar com id e login maliciosos não dá erro', r.status < 500 && !ASSINATURA_ERRO.test(r.texto), String(r.status));
  ok('nenhum outro usuário foi alterado', php('echo q("SELECT COUNT(*) FROM usuarios WHERE perfil=\\"admin\\"")->fetchColumn();') === admins0);
  console.log('"OR 1=1" não traz mais notas do que a busca comum');
  const contar = (t) => { const m = /de (\d[\d.]*) registro/.exec(t); return m ? +m[1].replace(/\./g, '') : (/Nada encontrado/.test(t) ? 0 : -1); };
  const semResultado = contar((await ana.get('/registros.php?q=' + encodeURIComponent('zzxqnadaencontrado'))).texto);
  for (const a of ["' OR '1'='1", "' OR 1=1 -- ", "\" OR \"1\"=\"1", "') OR ('1'='1", "1 OR 1=1"]) {
    const n = contar((await ana.get('/registros.php?q=' + encodeURIComponent(a))).texto);
    ok(`registros q=${a}  → ${n} resultado(s)`, n === semResultado && semResultado === 0, `esperado 0, veio ${n}`);
    const n2 = contar((await ana.get('/registros.php?tr=' + encodeURIComponent(a))).texto);
    ok(`registros tr=${a}  → ${n2} resultado(s)`, n2 === 0, `esperado 0, veio ${n2}`);
  }
  const rec = (await ana.get('/recebidas.php?q=' + encodeURIComponent("' OR '1'='1"))).texto;
  ok("recebidas q=' OR '1'='1 não lista nada", /Nada encontrado/.test(rec));

  console.log('Tempo: SLEEP() não atrasa a resposta');
  const t = await ana.get('/registros.php?q=' + encodeURIComponent("' AND SLEEP(4) -- "));
  ok('registros q=SLEEP(4) responde rápido', t.ms < 2500, Math.round(t.ms) + ' ms');
  const t2 = await ana.get('/registros.php?ord=' + encodeURIComponent('data_receber,(SELECT SLEEP(4))'));
  ok('registros ord=…SLEEP(4) responde rápido (ordenação só aceita lista fixa)', t2.ms < 2500, Math.round(t2.ms) + ' ms');

  console.log('Gravar texto malicioso (formulário) e conferir que é só texto');
  const veneno = "ZZSQLI'); DROP TABLE agendamentos; -- <script>alert(1)</script>";
  const tok = await ana.csrf('/agendamento.php');
  r = await ana.post('/agendamento.php', { csrf: tok, acao: 'salvar', fornecedor: veneno, transportadora: "x' OR '1'='1", nota_fiscal: "9'; DROP TABLE usuarios; --", volumes: '1', produto: veneno, observacao: veneno, empresa: "GREEN MED' OR '1'='1", uf: "RJ'; --", data_receber: "2026-10-30'; DROP TABLE historico; --" });
  ok('formulário aceitou/recusou sem erro 500', r.status < 500 && !ASSINATURA_ERRO.test(r.texto), String(r.status));
  const r2 = await ana.post('/agendamento.php', { csrf: tok, acao: 'salvar', fornecedor: veneno, transportadora: 'ZZ TRANSP', nota_fiscal: '9001', volumes: '1', produto: 'X', empresa: 'GREEN MED', uf: 'RJ', data_receber: '2026-10-30', data_agendamento: '2026-10-22' });
  ok('nota com texto malicioso foi gravada normalmente', r2.status === 302, `${r2.status} ${r2.texto.slice(0, 80)}`);
  const gravado = php('echo q("SELECT fornecedor FROM agendamentos WHERE fornecedor LIKE \\"ZZSQLI%\\" ORDER BY id DESC LIMIT 1")->fetchColumn();');
  ok('o texto ficou guardado inteiro, como texto comum (o sistema grava em maiúsculas)', gravado.toUpperCase().includes('DROP TABLE AGENDAMENTOS') && gravado.includes("');"), gravado.slice(0, 60));
  ok('tabelas continuam existindo', php('echo (int)(bool)db()->query("SHOW TABLES LIKE \\"agendamentos\\"")->fetch() + (int)(bool)db()->query("SHOW TABLES LIKE \\"usuarios\\"")->fetch() + (int)(bool)db()->query("SHOW TABLES LIKE \\"historico\\"")->fetch();') === '3');
  const lista = (await ana.get('/registros.php?q=ZZSQLI')).texto;
  ok('na tela o <script> aparece escapado (não executa)', lista.includes('ZZSQLI') && !/<script>alert\(1\)<\/script>/.test(lista) && /&lt;script&gt;/i.test(lista));
  const idv = php('echo q("SELECT id FROM agendamentos WHERE fornecedor LIKE \\"ZZSQLI%\\" ORDER BY id DESC LIMIT 1")->fetchColumn();');
  const det = (await ana.get('/agendamento.php?id=' + idv)).texto;
  ok('no detalhe também fica escapado', !/<script>alert\(1\)<\/script>/.test(det) && /&lt;script&gt;/i.test(det));
  const ex = (await ana.get('/exportar.php?q=ZZSQLI')).texto;
  ok('exportar CSV responde sem erro', ex.includes('ZZSQLI') && !ASSINATURA_ERRO.test(ex));

  console.log('Importação (planilha colada) com ataques');
  const tok2 = await ana.csrf('/importar.php');
  r = await ana.post('/importar.php', { csrf: tok2, acao: 'ler', empresa: 'GREEN MED', uf: 'RJ', data_receber: '2026-10-30', texto: "Fornecedor;NF;Volumes\n" + veneno + ";1'; DROP TABLE agendamentos; --;5\n' OR '1'='1;2;3" });
  ok('prévia mostra as linhas sem erro e com texto escapado', r.status === 200 && !ASSINATURA_ERRO.test(r.texto) && !/<script>alert\(1\)<\/script>/.test(r.texto), String(r.status));
  r = await ana.post('/importar.php', { csrf: tok2, acao: 'gravar', dados: JSON.stringify([{ inc: 1, fornecedor: "ZZSQLI2'); DROP TABLE agendamentos; --", nota_fiscal: "1' OR '1'='1", volumes: "5'; --", transportadora: 'T', produto: 'P', empresa: "X' OR 1=1", uf: "' OR 1", data_receber: "2026-10-30' OR 1=1", chave_nfe: "1' OR '1'='1", origem: 'csv' }]) });
  ok('gravar com JSON malicioso não dá erro 500', r.status < 500 && !ASSINATURA_ERRO.test(r.texto), String(r.status));

  console.log('Sem acesso: quem não está logado não vê nada, nem com ataque');
  const anon = new Sessao();
  for (const rota of ['/registros.php?q=' + encodeURIComponent("' OR 1=1 -- "), '/exportar.php?q=x', '/estado.php', '/admin/historico.php?q=x', '/admin/index.php']) {
    r = await anon.get(rota);
    ok(`anônimo em ${rota.split('?')[0]} é mandado para o login`, r.status === 302 || r.status === 401 || r.status === 403, String(r.status));
  }

  console.log('Integridade ao final');
  ok('só o usuário de teste foi criado (nenhum apagado)', totalUsuarios() === usuarios0 + 1, `${usuarios0} → ${totalUsuarios()}`);
  const novas = totalNotas() - notas0;
  ok('só entrou 1 ou 2 notas de teste (nada apagado nem duplicado)', novas >= 1 && novas <= 3, String(novas));
} catch (e) {
  falhas++;
  console.log('  ERRO   ' + e.message);
}
console.log(`\n${falhas ? falhas + ' de ' + total + ' verificações falharam.' : 'Todas as ' + total + ' verificações passaram.'}`);
process.exit(falhas ? 1 : 0);
