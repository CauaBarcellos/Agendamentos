// Teste no navegador do fluxo RJ ⇄ ES:
//   ES registra a nota que chegou → RJ só vê e escolhe o dia → ES vê o pedido → RJ dá entrada → ES vê que chegou no RJ.
//   Também confere as permissões: o ES só usa a tela da filial; o RJ não cadastra nem edita notas do ES.
// Uso (na pasta tests/browser):  php preparar.php && node es.mjs && php limpar.php
import { abrirNavegador } from './cdp.mjs';
import { execFileSync } from 'node:child_process';
import { mkdirSync } from 'node:fs';

const B = 'http://localhost/agendamentos';
const PW = 'Zq8mTe42xYw';
const FOTOS = process.env.FOTOS || '';
if (FOTOS) mkdirSync(FOTOS, { recursive: true });
let falhas = 0, total = 0;
const ok = (nome, cond, det = '') => { total++; if (!cond) falhas++; console.log((cond ? '  ok    ' : '  FALHA ') + nome + (cond || !det ? '' : '  → ' + det)); };
const php = (c) => execFileSync('C:/xampp2/php/php.exe', ['-r', '$_SERVER["SCRIPT_NAME"]="x";$_SERVER["HTTP_HOST"]="localhost";require "C:/xampp2/htdocs/agendamentos/inc/bootstrap.php";' + c]).toString();
const hoje = php('echo hoje();'), ontem = php('echo soma_dias(hoje(), -1);'), amanha = php('echo soma_dias(hoje(), 1);'), depois = php('echo soma_dias(hoje(), 2);');
const brd = (d) => d.split('-').reverse().join('/');
const idDe = (forn) => php(`echo q("SELECT id FROM agendamentos WHERE fornecedor = \\"${forn}\\"")->fetchColumn();`);
const campo = (forn, c) => php(`echo q("SELECT ${c} FROM agendamentos WHERE fornecedor = \\"${forn}\\"")->fetchColumn();`);

const es = await abrirNavegador({ porta: 9341, largura: 1300, altura: 1000 });
const rio = await abrirNavegador({ porta: 9342, largura: 1300, altura: 1000 });
const entrar = async (nav, login, espera) => {
  await nav.ir(B + '/login.php');
  await nav.js(`document.querySelector('#login').value='${login}'; document.querySelector('#senha').value='${PW}'; document.querySelector('form').submit();`);
  await nav.esperar(espera, 10000, 'entrar como ' + login);
};
const flash = (nav) => nav.js(`document.querySelector('.flash')?.textContent.trim() || ''`);
const carregou = (nav, cond = 'true') => nav.esperar(`document.readyState === 'complete' && (${cond})`, 8000);
const item = (sec, nome) => `[...document.querySelectorAll('${sec} .esitem')].find(i => i.textContent.toLowerCase().includes('${nome}'))`;
const registrar = (forn, nf, extra = '') => es.js(`const f=document.getElementById('es-nova'); f.fornecedor.value='${forn}'; f.produto.value='soro'; f.nota_fiscal.value='${nf}'; f.volumes.value='3'; f.transportadora.value='zztransp es'; f.chegou_es_em.value='${hoje}'; ${extra} f.submit();`);

try {
  console.log('ES: acesso só à tela da filial');
  await entrar(es, 'tmp.es', `location.pathname.endsWith('es.php') && document.readyState === 'complete'`);
  ok('ao entrar vai direto para a tela da filial', true);
  ok('não mostra as abas do RJ nem "Novo"/"Importar"', await es.js(`!document.querySelector('nav.tabs') && !document.querySelector('header .btn')`));
  for (const p of ['index.php', 'registros.php', 'agendamento.php', 'importar.php', 'recebidas.php']) {
    await es.ir(B + '/' + p);
    ok(`${p} manda de volta para a filial`, (await es.js('location.pathname')).endsWith('es.php'), await es.js('location.pathname'));
  }
  const r403 = await es.js(`fetch('acao.php', {method:'POST', body: new URLSearchParams({acao:'entregue', id:'1'})}).then(r => r.url)`);
  ok('o ES não consegue dar entrada (acao.php devolve para a filial)', r403.endsWith('es.php'), r403);

  console.log('ES: registrar nota que chegou');
  await es.ir(B + '/es.php');
  await registrar('zzes nova', '990001');
  await carregou(es, `!!document.querySelector('.flash')`);
  ok('mensagem confirma o registro', (await flash(es)).includes('O RJ foi avisado'), await flash(es));
  ok('aparece em "Aguardando o RJ escolher o dia"', !!(await es.js(`${item('.es-aguardando', 'zzes nova')}?.textContent`)));
  ok('gravada como nota do ES, sem dia de receber', campo('ZZES NOVA', 'CONCAT(uf, origem, chegou_es_em, IFNULL(data_receber, \\"-\\"))') === 'ESes' + hoje + '-');
  await registrar('ZZES NOVA', '990001');
  await carregou(es, `!!document.querySelector('.flash.erro')`);
  ok('registrar a mesma NF de novo é recusado', (await flash(es)).includes('já foi registrada'), await flash(es));
  await registrar('ZZES FUTURA', '990002', `f.chegou_es_em.removeAttribute('max'); f.chegou_es_em.value='${amanha}';`);
  await carregou(es, `!!document.querySelector('.flash.erro')`);
  ok('dia de chegada no futuro é recusado', (await flash(es)).includes('dia em que chegou'), await flash(es));
  ok('com erro, o formulário fica aberto', await es.js(`document.querySelector('.es-nova-box').open`));
  await registrar('zzes engano', '990003');
  await carregou(es, `!!document.querySelector('.flash')`);
  await es.js(`window.confirm = () => true; ${item('.es-aguardando', 'zzes engano')}.querySelector('form button').click();`);
  await carregou(es, `(document.querySelector('.flash')?.textContent || '').includes('desfeito')`);
  ok('"Desfazer" apaga o registro feito por engano', !(await es.js(`${item('.es-aguardando', 'zzes engano')}?.textContent || ''`)) && idDe('ZZES ENGANO') === '');

  console.log('RJ: só vê e escolhe o dia');
  await entrar(rio, 'tmp.a', `typeof window.__agenda === 'object'`);
  ok('aparece "Chegaram no ES" nas pendências', await rio.js(`!!document.querySelector('.rail a.day.es')`));
  await rio.ir(B + '/index.php?dia=es');
  await rio.esperar(`typeof window.__agenda === 'object'`, 8000);
  const naFila = () => rio.js(`[...document.querySelectorAll('#painel .row')].filter(r => r.dataset.busca.includes('zzes')).length`);
  ok('a nota está na fila', (await naFila()) === 1, String(await naFila()));
  ok('sem "Receber todas" nem ✓ na fila', await rio.js(`!document.querySelector('#painel .gh-all') && !document.querySelector('#painel .row .check')`));
  ok('não aparece em "Sem data"', !(await rio.js(`fetch('index.php?dia=semdata').then(r => r.text())`)).toLowerCase().includes('zzes'));

  const id = idDe('ZZES NOVA');
  await rio.ir(B + '/agendamento.php?id=' + id);
  ok('detalhe da nota do ES: sem botão Editar', await rio.js(`![...document.querySelectorAll('.cardfoot a')].some(a => a.textContent.includes('Editar'))`));
  ok('sem "Dar entrada" antes de escolher o dia', await rio.js(`![...document.querySelectorAll('.cardfoot a, .cardfoot button')].some(b => b.textContent.includes('Dar entrada'))`));
  ok('tem o campo para escolher o dia', await rio.js(`!!document.querySelector('form.es-receber-det')`));
  await rio.ir(B + '/agendamento.php?id=' + id + '&editar=1');
  ok('abrir a edição pelo endereço não mostra formulário', await rio.js(`!document.querySelector('form.formcard')`));
  const tentativa = await rio.js(`(() => { const fd = new FormData(); fd.set('csrf', document.querySelector('input[name=csrf]').value); fd.set('acao','salvar'); fd.set('id','${id}'); fd.set('fornecedor','HACK'); fd.set('data_receber','${amanha}'); return fetch('agendamento.php?id=${id}', {method:'POST', body: fd}).then(r => r.status); })()`);
  ok('o RJ não consegue alterar os dados da nota do ES', campo('ZZES NOVA', 'fornecedor') === 'ZZES NOVA', String(tentativa));
  const ent = await rio.js(`(() => { const fd = new FormData(); fd.set('csrf', document.querySelector('input[name=csrf]').value); fd.set('acao','entregue'); fd.set('id','${id}'); return fetch('acao.php', {method:'POST', body: fd, headers:{'X-Requested-With':'fetch'}}).then(r => r.json()); })()`);
  ok('nem dar entrada antes de escolher o dia', campo('ZZES NOVA', 'entregue') === 'N', JSON.stringify(ent));
  await rio.ir(B + '/agendamento.php');
  ok('no "Novo agendamento" o RJ não escolhe UF ES', await rio.js(`!document.querySelector('select[name=uf]')`));

  console.log('RJ escolhe o dia');
  await rio.ir(B + '/index.php?dia=es');
  await rio.esperar(`typeof window.__agenda === 'object'`, 8000);
  const formFila = `[...document.querySelectorAll('#painel .row')].find(r => r.dataset.busca.includes('zzes nova')).querySelector('form.es-receber')`;
  await rio.js(`const f=${formFila}; f.data_receber.removeAttribute('min'); f.data_receber.value='${ontem}'; f.submit();`);
  await carregou(rio, `!!document.querySelector('.flash.erro')`);
  ok('dia que já passou é recusado', (await flash(rio)).includes('dia futuro'), await flash(rio));
  await rio.esperar(`typeof window.__agenda === 'object'`, 8000);
  await rio.js(`const f=${formFila}; f.data_receber.value='${amanha}'; f.submit();`);
  await carregou(rio, `(document.querySelector('.flash')?.textContent || '').includes('vai ser recebida')`);
  ok('agendado para amanhã', campo('ZZES NOVA', 'data_receber') === amanha);
  await rio.ir(B + '/agendamento.php?id=' + id);
  const velho = await rio.js(`(() => { const fd = new FormData(); fd.set('csrf', document.querySelector('input[name=csrf]').value); fd.set('acao','receber_es'); fd.set('id','${id}'); fd.set('de',''); fd.set('data_receber','${depois}'); return fetch('acao.php', {method:'POST', body: fd, headers:{'X-Requested-With':'fetch'}}).then(r => r.json()); })()`);
  ok('tela desatualizada não sobrescreve o dia escolhido', velho.ok === false && campo('ZZES NOVA', 'data_receber') === amanha, JSON.stringify(velho));
  await rio.js(`const f=document.querySelector('form.es-receber-det'); f.data_receber.value='${depois}'; f.submit();`);
  await carregou(rio, `(document.querySelector('.flash')?.textContent || '').includes('vai ser recebida')`);
  ok('no detalhe dá para mudar o dia', campo('ZZES NOVA', 'data_receber') === depois);

  console.log('ES vê o pedido do RJ');
  await es.ir(B + '/es.php');
  const ped = await es.js(`${item('.es-pedidos', 'zzes nova')}?.textContent || ''`);
  ok(`aparece em "O RJ pediu para enviar" com o dia ${brd(depois)}`, ped.includes(brd(depois)) && ped.toLowerCase().includes('soro'), ped.trim());
  ok('saiu de "Aguardando"', !(await es.js(`${item('.es-aguardando', 'zzes nova')}?.textContent || ''`)));
  ok('o ES não pode mais desfazer', !(await es.js(`${item('.es-pedidos', 'zzes nova')}.querySelector('form')`)));
  if (FOTOS) await es.foto(FOTOS + '/es-1-pedidos.png');

  console.log('RJ dá entrada → ES vê que chegou');
  await rio.ir(B + '/index.php?dia=' + depois);
  await rio.esperar(`typeof window.__agenda === 'object'`, 8000);
  await rio.js(`[...document.querySelectorAll('#painel .row')].find(r => r.dataset.busca.includes('zzes nova')).querySelector('.check').click()`);
  await rio.esperar(`!!document.querySelector('dialog.rec-modal[open] form')`, 6000, 'janela de conferência');
  await rio.js(`const f=document.querySelector('dialog.rec-modal form'); f.querySelector('input[value=sim]').checked=true; f.requestSubmit();`);
  await rio.esperar(`![...document.querySelectorAll('#painel .row')].some(r => r.dataset.busca.includes('zzes nova'))`, 8000, 'entrada');
  ok('entrada dada na agenda', campo('ZZES NOVA', 'entregue') === 'S');
  await es.ir(B + '/es.php');
  ok('o ES vê "Chegou no RJ em ' + brd(hoje) + '"', (await es.js(`${item('.es-chegaram', 'zzes nova')}?.textContent || ''`)).includes('Chegou no RJ em ' + brd(hoje)));
  await rio.ir(B + '/recebidas.php?q=zzes');
  ok('aparece em Recebidas ES', (await rio.js(`document.querySelector('table').textContent.toLowerCase()`)).includes('zzes nova'));
  await rio.ir(B + '/agendamento.php?id=' + id);
  const det = await rio.js(`document.querySelector('.detail').textContent`);
  ok('histórico mostra quem registrou e quem agendou', det.includes('Elisa Filial') && det.includes('Ana Teste'));

  console.log('ES vê também as notas antigas (planilha)');
  await es.ir(B + '/es.php');
  ok('pendente antiga do ES aparece em "O RJ pediu para enviar"', (await es.js(`document.querySelectorAll('.es-pedidos .esitem').length`)) >= 1);
  const antigas = +php('echo q("SELECT COUNT(*) FROM agendamentos WHERE uf=\\"ES\\" AND entregue=\\"S\\"")->fetchColumn() + q("SELECT COUNT(*) FROM recebidas_es")->fetchColumn();');
  ok('link para o histórico completo', (await es.js(`document.querySelector('.es-chegaram a[href*=historico]')?.textContent || ''`)).includes(antigas.toLocaleString('pt-BR')));
  await es.ir(B + '/es.php?historico=1');
  ok(`histórico mostra todas as ${antigas} que já chegaram no RJ`, (await es.js(`document.querySelectorAll('.es-chegaram .esitem').length`)) === Math.min(antigas, 1000));
  await es.ir(B + '/es.php?historico=1&q=zzes');
  ok('busca no histórico funciona', (await es.js(`document.querySelectorAll('.es-chegaram .esitem').length`)) === 1);

  console.log('Celular');
  await es.tela(390, 844, true);
  await es.ir(B + '/es.php');
  ok('tela da filial sem rolagem lateral', await es.js(`document.documentElement.scrollWidth <= 391`), String(await es.js(`document.documentElement.scrollWidth`)));
  if (FOTOS) await es.foto(FOTOS + '/es-2-celular.png');
} catch (e) {
  falhas++;
  console.log('  ERRO   ' + e.message);
} finally {
  await es.fechar();
  await rio.fechar();
}
console.log(`\n${falhas ? falhas + ' de ' + total + ' verificações falharam.' : 'Todas as ' + total + ' verificações passaram.'}`);
process.exit(falhas ? 1 : 0);
