// Teste no navegador: portaria (código de barras / NF) → conferência do recebimento (volumes, divergência, fotos).
// Uso (na pasta tests/browser):  php preparar.php && node receber.mjs && php limpar.php
import { abrirNavegador } from './cdp.mjs';
import { execFileSync } from 'node:child_process';
import { mkdirSync } from 'node:fs';

const B = 'http://localhost/agendamentos';
const PW = 'Zq8mTe42xYw';
const FX = 'C:/xampp2/htdocs/agendamentos/tests/fixtures/';
const FOTOS = process.env.FOTOS || '';
if (FOTOS) mkdirSync(FOTOS, { recursive: true });
let falhas = 0, total = 0;
const ok = (nome, cond, det = '') => { total++; if (!cond) falhas++; console.log((cond ? '  ok    ' : '  FALHA ') + nome + (cond || !det ? '' : '  → ' + det)); };
const php = (c) => execFileSync('C:/xampp2/php/php.exe', ['-r', '$_SERVER["SCRIPT_NAME"]="x";$_SERVER["HTTP_HOST"]="localhost";require "C:/xampp2/htdocs/agendamentos/inc/bootstrap.php";' + c]).toString();
const nota = (nf, c) => php(`echo q("SELECT ${c.replace(/"/g, '\\"')} FROM agendamentos WHERE nota_fiscal = \\"${nf}\\" AND fornecedor LIKE \\"ZZ%\\"")->fetchColumn();`);

// Monta uma chave de acesso de 44 dígitos válida (com dígito verificador) para a NF pedida.
function chave(nNF, dvErrado = false) {
  const base = '33' + '2610' + '12345678000199' + '55' + '001' + String(nNF).padStart(9, '0') + '1' + '12345678';
  let soma = 0, peso = 2;
  for (let i = base.length - 1; i >= 0; i--) { soma += +base[i] * peso; peso = peso === 9 ? 2 : peso + 1; }
  let dv = 11 - (soma % 11); if (dv >= 10) dv = 0;
  return base + (dvErrado ? (dv + 1) % 10 : dv);
}

const nav = await abrirNavegador({ porta: 9361, largura: 1300, altura: 1000 });
const flash = () => nav.js(`document.querySelector('.flash')?.textContent.trim() || ''`);
const carregou = (cond = 'true') => nav.esperar(`document.readyState === 'complete' && (${cond})`, 10000);
try {
  await nav.ir(B + '/login.php');
  await nav.js(`document.querySelector('#login').value='tmp.a'; document.querySelector('#senha').value='${PW}'; document.querySelector('form').submit();`);
  await nav.esperar(`typeof window.__agenda === 'object'`, 10000, 'entrar');

  console.log('Portaria');
  ok('botão "Dar entrada" no topo', await nav.js(`[...document.querySelectorAll('header a.btn')].some(a => a.textContent.includes('Dar entrada'))`));
  const pp = await nav.js(`fetch('entrada.php').then(r => r.headers.get('permissions-policy'))`);
  ok('câmera liberada só para o próprio site', /camera=\(self\)/.test(pp || ''), pp);
  await nav.ir(B + '/entrada.php');
  ok('campo do código já vem com o cursor (leitor USB)', await nav.js(`document.activeElement && document.activeElement.id === 'ent-q'`));
  ok('botão "Ler com a câmera"', await nav.js(`!!document.getElementById('ent-cam')`));
  await nav.js(`document.getElementById('ent-q').value='880001'; document.getElementById('ent-form').submit();`);
  await carregou(`!!document.querySelector('.esitem')`);
  ok('achou a nota pelo número da NF', (await nav.js(`document.querySelectorAll('.esitem').length`)) === 1);
  if (FOTOS) await nav.foto(FOTOS + '/rec-1-portaria.png');
  await nav.js(`document.querySelector('.esitem a.btn.primary').click()`);
  await carregou(`!!document.getElementById('form-receber')`);
  ok('abriu a conferência', (await nav.js('location.pathname')).endsWith('receber.php'));

  console.log('Conferência: validações');
  await nav.js(`document.getElementById('vol_recebidos').value='1'; document.querySelector('input[value=sim]').checked=true; document.getElementById('form-receber').submit();`);
  await carregou(`!!document.querySelector('.flash.erro')`);
  ok('volumes diferentes com "tudo certo" é recusado', (await flash()).includes('não batem'), await flash());
  await nav.js(`document.getElementById('vol_recebidos').value='3'; document.querySelector('input[value=nao]').checked=true; document.getElementById('form-receber').submit();`);
  await carregou(`!!document.querySelector('.flash.erro')`);
  ok('problema sem explicação é recusado', (await flash()).includes('Descreva'), await flash());
  ok('nada foi gravado ainda', nota('880001', 'entregue') === 'N');

  console.log('Conferência com divergência e foto');
  await nav.js(`const v=document.getElementById('vol_recebidos'); v.value='3'; v.dispatchEvent(new Event('input',{bubbles:true}));`);
  ok('volume menor marca "teve problema" e "Falta" sozinho', await nav.js(`document.querySelector('input[value=nao]').checked && document.querySelector('input[value=falta]').checked && !document.getElementById('rec-div').hidden`));
  await nav.js(`document.querySelector('input[value=avaria]').checked=true; document.getElementById('obs').value='1 caixa amassada e faltou 1 volume';`);
  await nav.arquivos('#rec-fotos', [FX + 'foto.png']);
  await nav.esperar(`document.querySelectorAll('#rec-prev img').length === 1`, 8000, 'miniatura da foto');
  ok('mostra a miniatura da foto', true);
  if (FOTOS) await nav.foto(FOTOS + '/rec-2-conferencia.png');
  await nav.js(`document.getElementById('form-receber').submit()`);
  await carregou(`(location.pathname.endsWith('entrada.php')) && !!document.querySelector('.flash')`);
  ok('volta para a portaria pronta para a próxima', await nav.js(`document.activeElement && document.activeElement.id === 'ent-q'`));
  ok('mensagem: com divergência e 1 foto', (await flash()).includes('com divergência') && (await flash()).includes('1 foto'), await flash());
  ok('gravou: entrada, 3 volumes, falta + avaria', nota('880001', 'CONCAT(entregue, "|", vol_recebidos, "|", divergencia)') === 'S|3|falta,avaria', nota('880001', 'CONCAT(entregue, "|", vol_recebidos, "|", divergencia)'));
  const id1 = nota('880001', 'id');
  ok('foto guardada', php(`echo q("SELECT COUNT(*) FROM fotos WHERE agendamento_id = ${id1}")->fetchColumn();`) === '1');

  await nav.ir(B + '/agendamento.php?id=' + id1);
  const det = await nav.js(`document.querySelector('.detail').textContent`);
  ok('detalhe mostra "Recebida c/ divergência", volumes e o motivo', det.includes('Recebida c/ divergência') && det.includes('3 de 4 esperados') && det.includes('Falta de volume, Avaria') && det.includes('caixa amassada'));
  await nav.esperar(`[...document.querySelectorAll('.fotos-nota img')].every(i => i.complete && i.naturalWidth > 0)`, 8000, 'foto carregar');
  ok('a foto aparece no detalhe', (await nav.js(`document.querySelectorAll('.fotos-nota img').length`)) === 1);
  const fotoId = php(`echo q("SELECT id FROM fotos WHERE agendamento_id = ${id1}")->fetchColumn();`);
  const anon = await fetch(B + '/foto.php?id=' + fotoId, { redirect: 'manual' });
  ok('foto não abre para quem não está logado', anon.status === 302, String(anon.status));
  const direto = await fetch(B + '/uploads/' + php(`echo q("SELECT arquivo FROM fotos WHERE id = ${fotoId}")->fetchColumn();`));
  ok('pasta uploads bloqueada no navegador', direto.status === 403, String(direto.status));
  if (FOTOS) await nav.foto(FOTOS + '/rec-3-detalhe.png');

  console.log('Registros e exportação');
  await nav.ir(B + '/registros.php?st=divergencia&q=zzforn');
  ok('filtro "Com divergência" acha a nota', (await nav.js(`document.querySelector('table').textContent`)).includes('880001'));
  const csv = await nav.js(`fetch('exportar.php?st=divergencia&q=zzforn').then(r => r.text())`);
  ok('CSV traz volumes recebidos e divergência', csv.includes('Divergência') && csv.includes('Falta de volume, Avaria'));

  console.log('Código de barras (chave da NF-e)');
  const idChave = nota('880002', 'id');
  php(`q("UPDATE agendamentos SET chave_nfe = ? WHERE id = ${idChave}", ["${chave(880002)}"]);`);
  await nav.ir(B + '/entrada.php?q=' + chave(880002));
  ok('chave gravada: vai direto para a conferência', (await nav.js('location.pathname')).endsWith('receber.php') && (await nav.js('location.search')).includes('id=' + idChave));
  ok('"tudo certo" já vem com os volumes esperados', (await nav.js(`document.getElementById('vol_recebidos').value`)) === '6');
  await nav.js(`document.querySelector('input[value=sim]').checked=true; document.getElementById('form-receber').submit();`);
  await carregou(`!!document.querySelector('.flash')`);
  ok('entrada sem divergência gravada', nota('880002', 'CONCAT(entregue, "|", vol_recebidos, "|", IFNULL(divergencia, "-"))') === 'S|6|-');
  await nav.ir(B + '/entrada.php?q=' + chave(880002));
  ok('ler de novo a mesma nota mostra "Já recebida"', (await nav.js(`document.querySelector('.esitem')?.textContent || ''`)).includes('Já recebida'));
  await nav.ir(B + '/entrada.php?q=' + chave(880003, true));
  ok('código lido com erro é avisado (dígito verificador)', (await flash()).includes('não confere'), await flash());
  await nav.ir(B + '/entrada.php?q=' + chave(880003));
  ok('chave sem cadastro acha pelo número da NF', (await flash()).includes('achei pelo número') && (await nav.js(`document.querySelectorAll('.esitem').length`)) === 1, await flash());

  console.log('Pela agenda: o ✓ abre a conferência numa janela');
  await nav.ir(B + '/index.php');
  await nav.esperar(`typeof window.__agenda === 'object'`, 8000);
  const id5 = nota('880005', 'id');
  await nav.js(`[...document.querySelectorAll('#painel .row')].find(r => r.dataset.id === '${id5}').querySelector('.check').click()`);
  await nav.esperar(`!!document.querySelector('dialog.rec-modal[open] form')`, 6000, 'janela');
  ok('janela mostra a nota certa', (await nav.js(`document.querySelector('dialog.rec-modal h1').textContent`)).includes('B2'));
  await nav.js(`const v=document.querySelector('dialog.rec-modal #vol_recebidos'); v.value='3'; v.dispatchEvent(new Event('input',{bubbles:true})); document.querySelector('dialog.rec-modal input[value=avaria]').checked=true; document.querySelector('dialog.rec-modal #obs').value='caixa molhada';`);
  ok('na janela, volume menor também marca "teve problema" e "Falta"', await nav.js(`document.querySelector('dialog.rec-modal input[value=nao]').checked && document.querySelector('dialog.rec-modal input[value=falta]').checked && !document.querySelector('dialog.rec-modal #rec-div').hidden`));
  await nav.arquivos('dialog.rec-modal #rec-fotos', [FX + 'foto.png']);
  await nav.esperar(`document.querySelectorAll('dialog.rec-modal #rec-prev img').length === 1`, 8000, 'miniatura na janela');
  if (FOTOS) await nav.foto(FOTOS + '/rec-5-janela.png');
  await nav.js(`document.querySelector('dialog.rec-modal form').requestSubmit()`);
  await nav.esperar(`![...document.querySelectorAll('#painel .row')].some(r => r.dataset.id === '${id5}')`, 10000, 'linha sumir');
  ok('a nota sai da agenda sem trocar de página', (await nav.js('location.pathname')).endsWith('index.php') && !(await nav.js(`!!document.querySelector('dialog.rec-modal')`)));
  ok('aviso com "Desfazer" diz que teve divergência', (await nav.js(`document.getElementById('toast').textContent`)).includes('divergência') && await nav.js(`!!document.querySelector('#toast button')`));
  ok('gravou volumes, divergência e a foto', nota('880005', 'CONCAT(vol_recebidos, "|", divergencia)') === '3|falta,avaria' && php(`echo q("SELECT COUNT(*) FROM fotos WHERE agendamento_id = ${id5}")->fetchColumn();`) === '1');
  await nav.js(`document.querySelector('#toast button').click()`);
  await nav.esperar(`document.readyState === 'complete' && [...document.querySelectorAll('#painel .row')].some(r => r.dataset.id === '${id5}')`, 10000, 'desfazer');
  ok('"Desfazer" volta a nota e limpa a divergência', nota('880005', 'CONCAT(entregue, "|", IFNULL(divergencia, "-"))') === 'N|-');
  if (FOTOS) {
    await nav.tela(390, 844, true);
    await nav.js(`[...document.querySelectorAll('#painel .row')].find(r => r.dataset.id === '${id5}').querySelector('.check').click()`);
    await nav.esperar(`!!document.querySelector('dialog.rec-modal[open] form')`, 6000, 'janela no celular');
    await nav.foto(FOTOS + '/rec-6-janela-celular.png');
    await nav.js(`document.querySelector('dialog.rec-modal [data-fechar]').click()`);
    await nav.tela(1300, 1000, false);
  }

  console.log('Duas pessoas na mesma nota');
  const id4 = nota('880004', 'id');
  await nav.ir(B + '/receber.php?id=' + id4);
  php(`q("UPDATE agendamentos SET entregue = \\"S\\", entregue_em = NOW() WHERE id = ${id4}");`);
  await nav.js(`document.querySelector('input[value=sim]').checked=true; document.getElementById('form-receber').submit();`);
  await carregou(`!!document.querySelector('.flash.erro')`);
  ok('a segunda pessoa é avisada e nada é sobrescrito', /Outra pessoa|já teve entrada/.test(await flash()) && nota('880004', 'IFNULL(vol_recebidos, "-")') === '-', await flash());

  console.log('Reabrir limpa a conferência');
  await nav.ir(B + '/agendamento.php?id=' + id1);
  await nav.js(`[...document.querySelectorAll('.cardfoot button')].find(b => b.textContent.includes('Reabrir')).click()`);
  await carregou(`!!document.querySelector('.flash')`);
  ok('nota reaberta sem divergência nem volumes recebidos', nota('880001', 'CONCAT(entregue, "|", IFNULL(vol_recebidos, "-"), "|", IFNULL(divergencia, "-"))') === 'N|-|-');

  console.log('"Receber todas" com conferência (janela do grupo)');
  await nav.ir(B + '/index.php');
  await nav.esperar(`typeof window.__agenda === 'object'`, 8000);
  const grupo = `[...document.querySelectorAll('#painel .grp')].find(g => g.querySelector('.tname').textContent.toLowerCase().includes('zztransp dois'))`;
  await nav.js(`${grupo}.querySelector('.gh-all button').click()`);
  await nav.esperar(`!!document.querySelector('dialog.rec-modal[open] form.rec-grupo')`, 6000, 'janela do grupo');
  ok('abre a janela com as notas do grupo', (await nav.js(`document.querySelectorAll('dialog.rec-modal .rg-item').length`)) === 2, String(await nav.js(`document.querySelectorAll('dialog.rec-modal .rg-item').length`)));
  const id6 = nota('880006', 'id'), item6 = `document.querySelector('dialog.rec-modal .rg-item[data-id="${id6}"]')`;
  // volume diferente sem marcar problema: o servidor recusa tudo e aponta a nota
  await nav.js(`${item6}.querySelector('input[name$="[vol_recebidos]"]').value = '1'; document.querySelector('dialog.rec-modal form').requestSubmit();`);
  await nav.esperar(`!!document.querySelector('dialog.rec-modal .rg-item.com-erro')`, 6000, 'erro na nota');
  ok('a nota com problema fica marcada em vermelho com o motivo', (await nav.js(`${item6}.querySelector('.rg-erro').textContent`)).includes('não batem'));
  ok('nada foi gravado (tudo ou nada)', nota('880005', 'entregue') === 'N' && nota('880006', 'entregue') === 'N');
  await nav.js(`const v = ${item6}.querySelector('input[name$="[vol_recebidos]"]'); v.dispatchEvent(new Event('input', { bubbles: true })); ${item6}.querySelector('textarea').value = 'faltaram 5 caixas';`);
  ok('volume menor marca "Teve problema" e "Falta" nessa nota', await nav.js(`${item6}.querySelector('.rg-prob input').checked && ${item6}.querySelector('input[value=falta]').checked && !${item6}.querySelector('.rg-div').hidden`));
  await nav.arquivos(`dialog.rec-modal .rg-item[data-id="${id6}"] .rg-fotos`, [FX + 'foto.png']);
  await nav.esperar(`${item6}.querySelectorAll('.rec-prev img').length === 1`, 8000, 'miniatura no grupo');
  if (FOTOS) await nav.foto(FOTOS + '/rec-7-grupo.png');
  await nav.js(`document.querySelector('dialog.rec-modal form').requestSubmit()`);
  await nav.esperar(`!document.querySelector('dialog.rec-modal') && !${grupo}`, 10000, 'grupo sumir');
  ok('as 2 notas saem da agenda', true);
  ok('aviso: 2 recebidas, 1 com divergência', (await nav.js(`document.getElementById('toast').textContent`)).includes('2 notas recebidas, 1 com divergência'), await nav.js(`document.getElementById('toast').textContent`));
  ok('a nota certa ficou sem divergência', nota('880005', 'CONCAT(entregue, "|", vol_recebidos, "|", IFNULL(divergencia, "-"))') === 'S|4|-');
  ok('a nota com problema ficou com falta, 1 volume e a foto', nota('880006', 'CONCAT(entregue, "|", vol_recebidos, "|", divergencia)') === 'S|1|falta' && php(`echo q("SELECT COUNT(*) FROM fotos WHERE agendamento_id = ${id6}")->fetchColumn();`) === '1');

  console.log('Celular');
  await nav.tela(390, 844, true);
  for (const p of ['entrada.php?q=zzforn', 'receber.php?id=' + id1]) {
    await nav.ir(B + '/' + p);
    ok(`${p.split('?')[0]} sem rolagem lateral e sem o botão "+" por cima`, await nav.js(`document.documentElement.scrollWidth <= 391 && getComputedStyle(document.querySelector('.topin>.btn.primary')).display === 'none'`));
  }
  if (FOTOS) await nav.foto(FOTOS + '/rec-4-celular.png');
} catch (e) {
  falhas++;
  console.log('  ERRO   ' + e.message);
} finally {
  await nav.fechar();
}
console.log(`\n${falhas ? falhas + ' de ' + total + ' verificações falharam.' : 'Todas as ' + total + ' verificações passaram.'}`);
process.exit(falhas ? 1 : 0);
