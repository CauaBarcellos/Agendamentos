// Teste da leitura pela câmera: o Chrome recebe uma "câmera falsa" mostrando o código de barras de uma NF-e
// (vídeo gerado por gerar_video.cjs) e a tela de portaria tem que achar a nota sozinha.
// Uso (na pasta tests/browser):  php preparar.php && node camera.mjs && php limpar.php
import { abrirNavegador } from './cdp.mjs';
import { execFileSync } from 'node:child_process';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const B = 'http://localhost/agendamentos';
const PW = 'Zq8mTe42xYw';
let falhas = 0, total = 0;
const ok = (nome, cond, det = '') => { total++; if (!cond) falhas++; console.log((cond ? '  ok    ' : '  FALHA ') + nome + (cond || !det ? '' : '  → ' + det)); };
const php = (c) => execFileSync('C:/xampp2/php/php.exe', ['-r', '$_SERVER["SCRIPT_NAME"]="x";$_SERVER["HTTP_HOST"]="localhost";require "C:/xampp2/htdocs/agendamentos/inc/bootstrap.php";' + c]).toString();

function chave(nNF) {
  const base = '33' + '2610' + '12345678000199' + '55' + '001' + String(nNF).padStart(9, '0') + '1' + '12345678';
  let soma = 0, peso = 2;
  for (let i = base.length - 1; i >= 0; i--) { soma += +base[i] * peso; peso = peso === 9 ? 2 : peso + 1; }
  let dv = 11 - (soma % 11); if (dv >= 10) dv = 0;
  return base + dv;
}

const ch = chave(880003);
const id = php('echo q("SELECT id FROM agendamentos WHERE nota_fiscal = \\"880003\\" AND fornecedor LIKE \\"ZZ%\\"")->fetchColumn();');
php(`q("UPDATE agendamentos SET chave_nfe = ? WHERE id = ${id}", ["${ch}"]);`);
const video = join(tmpdir(), 'camera-nfe.y4m').replace(/\\/g, '/');
execFileSync('node', ['gerar_video.cjs', ch, video]);

const nav = await abrirNavegador({ porta: 9371, largura: 900, altura: 1000, extras: ['--use-fake-ui-for-media-stream', '--use-fake-device-for-media-stream', '--use-file-for-fake-video-capture=' + video] });
try {
  await nav.ir(B + '/login.php');
  await nav.js(`document.querySelector('#login').value='tmp.a'; document.querySelector('#senha').value='${PW}'; document.querySelector('form').submit();`);
  await nav.esperar(`typeof window.__agenda === 'object'`, 10000, 'entrar');
  await nav.ir(B + '/entrada.php');
  const nativo = await nav.js(`'BarcodeDetector' in window`);
  console.log(`Leitura pela câmera (${nativo ? 'leitor do navegador' : 'biblioteca ZXing'})`);
  await nav.js(`document.getElementById('ent-cam').click()`);
  await nav.esperar(`!document.getElementById('ent-camera').hidden || !!document.getElementById('ent-status').textContent`, 5000, 'abrir câmera');
  ok('a câmera abre', await nav.js(`!document.getElementById('ent-camera').hidden`), await nav.js(`document.getElementById('ent-status').textContent`));
  await nav.esperar(`location.pathname.endsWith('receber.php')`, 20000, 'ler o código e abrir a conferência');
  ok('leu o código de barras e abriu a conferência da nota certa', (await nav.js('location.search')).includes('id=' + id), await nav.js('location.search'));

  console.log('Sem permissão de câmera');
  await nav.ir(B + '/entrada.php');
  await nav.js(`navigator.mediaDevices.getUserMedia = () => Promise.reject(Object.assign(new Error('x'), { name: 'NotAllowedError' })); document.getElementById('ent-cam').click();`);
  await nav.esperar(`document.getElementById('ent-status').textContent.length > 0 && document.getElementById('ent-camera').hidden`, 8000);
  ok('explica como liberar a câmera', (await nav.js(`document.getElementById('ent-status').textContent`)).includes('bloqueada'));
  ok('o campo continua disponível para digitar', await nav.js(`!!document.getElementById('ent-q') && !document.getElementById('ent-cam').hidden`));
} catch (e) {
  falhas++;
  console.log('  ERRO   ' + e.message);
} finally {
  await nav.fechar();
}
console.log(`\n${falhas ? falhas + ' de ' + total + ' verificações falharam.' : 'Todas as ' + total + ' verificações passaram.'}`);
process.exit(falhas ? 1 : 0);
