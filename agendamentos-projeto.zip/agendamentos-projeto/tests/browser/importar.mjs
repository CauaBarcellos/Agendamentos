// Teste no navegador: importação de NF-e (XML), planilha (CSV) e conferência da prévia.
// Uso (na pasta tests/browser):  php preparar.php && node importar.mjs && php limpar.php
import { abrirNavegador } from './cdp.mjs';
import { mkdirSync, writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { tmpdir } from 'node:os';

const B = 'http://localhost/agendamentos';
const PW = 'Zq8mTe42xYw';
const FX = 'C:/xampp2/htdocs/agendamentos/tests/fixtures/';
const FOTOS = process.env.FOTOS || '';
if (FOTOS) mkdirSync(FOTOS, { recursive: true });
let falhas = 0, total = 0;
const ok = (nome, cond, det = '') => { total++; if (!cond) falhas++; console.log((cond ? '  ok    ' : '  FALHA ') + nome + (cond || !det ? '' : '  → ' + det)); };

const nav = await abrirNavegador({ largura: 1400, altura: 1100 });
try {
  await nav.ir(B + '/login.php');
  await nav.js(`document.querySelector('#login').value='tmp.a'; document.querySelector('#senha').value='${PW}'; document.querySelector('form').submit();`);
  await nav.esperar(`location.pathname.endsWith('index.php') && document.readyState === 'complete' && !!document.getElementById('painel')`, 10000, 'entrar na agenda');

  console.log('Tela de importação');
  await nav.ir(B + '/importar.php');
  ok('botão "Importar" está no cabeçalho', await nav.js(`!![...document.querySelectorAll('header .btn')].find(b => b.textContent.includes('Importar'))`));
  ok('área de arrastar arquivos existe', await nav.js(`!!document.getElementById('dz')`));
  if (FOTOS) await nav.foto(FOTOS + '/imp-1-form.png');

  console.log('Enviar 2 XMLs, 1 XML malicioso e 1 CSV');
  await nav.arquivos('#arquivos', [FX + 'nfe_teuto.xml', FX + 'nfe_estevia_es.xml', FX + 'nfe_xxe.xml', FX + 'lote.csv']);
  await nav.esperar(`document.getElementById('dz-lista').textContent.includes('4 arquivos')`, 4000, 'lista de arquivos');
  ok('lista os 4 arquivos escolhidos', true);
  await nav.js(`document.querySelector('form.formcard button.primary').click()`);
  await nav.esperar(`!!document.getElementById('form-importar')`, 15000, 'prévia');
  const linhas = () => nav.js(`document.querySelectorAll('#form-importar tbody tr').length`);
  ok('prévia com 6 notas', (await linhas()) === 6, String(await linhas()));
  ok('aviso explica o XML recusado', (await nav.js(`document.querySelector('.flash.erro')?.textContent || ''`)).includes('nfe_xxe.xml'));
  ok('notas do RJ vêm marcadas; a de destino ES vem travada (quem registra é a filial)', await nav.js(`[...document.querySelectorAll('#form-importar tbody tr')].every(t => { const c = t.querySelector('[data-f="inc"]'), es = t.querySelector('[data-f="uf"]').value === 'ES'; return es ? (c.disabled && !c.checked) : c.checked; })`));
  ok('contagem mostra "5 de 6"', (await nav.js(`document.getElementById('imp-contagem').textContent`)).startsWith('5 de 6'));
  await nav.js(`document.getElementById('imp-marcar').click(); document.getElementById('imp-marcar').click();`);
  ok('"Marcar todas" não marca a nota do ES', (await nav.js(`document.getElementById('imp-contagem').textContent`)).startsWith('5 de 6'));
  ok('Teuto identificou GREEN MED', (await nav.js(`[...document.querySelectorAll('#form-importar tbody tr')].find(t => t.querySelector('[data-f="fornecedor"]').value === 'TEUTO').querySelector('[data-f="empresa"]').value`)) === 'GREEN MED');
  ok('Descarpack identificou ESTEVIA e UF ES', (await nav.js(`(() => { const t=[...document.querySelectorAll('#form-importar tbody tr')].find(t => t.querySelector('[data-f="fornecedor"]').value === 'DESCARPACK'); return t.querySelector('[data-f="empresa"]').value + '/' + t.querySelector('[data-f="uf"]').value; })()`)) === 'ESTEVIA/ES');
  if (FOTOS) await nav.foto(FOTOS + '/imp-2-previa.png');

  console.log('Editar a prévia');
  await nav.js(`[...document.querySelectorAll('#form-importar tbody tr')].find(t => t.querySelector('[data-f="fornecedor"]').value === 'HOSPFAR').querySelector('[data-f="inc"]').click()`);
  ok('desmarcar uma nota atualiza a contagem (4 de 6)', (await nav.js(`document.getElementById('imp-contagem').textContent`)).startsWith('4 de 6'));
  await nav.js(`document.getElementById('imp-data-todas').value='2027-01-14'; document.getElementById('imp-aplicar-data').click(); document.getElementById('imp-emp-todas').value='ESSENCIAL'; document.getElementById('imp-aplicar-emp').click();`);
  ok('"Aplicar a todas" mudou a data de todas', await nav.js(`[...document.querySelectorAll('#form-importar [data-f="data_receber"]')].every(i => i.value === '2027-01-14')`));
  await nav.js(`[...document.querySelectorAll('#form-importar tbody tr')].find(t => t.querySelector('[data-f="fornecedor"]').value === 'MEDIX').querySelector('[data-f="volumes"]').value = '9'`);

  console.log('Gravar');
  await nav.js(`document.getElementById('imp-gravar').click()`);
  await nav.esperar(`location.pathname.endsWith('index.php')`, 15000, 'ir para a agenda');
  await nav.esperar(`!!document.getElementById('painel')`, 8000);
  ok('foi para o dia 14/01/2027 (sem notas da planilha)', (await nav.js(`location.search`)).includes('dia=2027-01-14'), await nav.js(`location.search`));
  ok('mensagem "4 notas importadas"', (await nav.js(`document.querySelector('.flash')?.textContent || ''`)).includes('4 notas importadas'), await nav.js(`document.querySelector('.flash')?.textContent || ''`));
  ok('4 notas na agenda do dia', (await nav.js(`document.querySelectorAll('#painel .row').length`)) === 4, String(await nav.js(`document.querySelectorAll('#painel .row').length`)));
  ok('todas como Essencial (empresa aplicada)', await nav.js(`[...document.querySelectorAll('#painel .row .tag')].every(t => t.textContent.includes('Essencial'))`));
  ok('volume editado (Medix = 9) foi gravado', await nav.js(`[...document.querySelectorAll('#painel .row')].some(r => r.dataset.busca.includes('medix') && r.querySelector('.vol').textContent.trim().startsWith('9'))`));
  if (FOTOS) await nav.foto(FOTOS + '/imp-3-agenda.png');

  console.log('Reimportar os mesmos arquivos');
  await nav.ir(B + '/importar.php');
  await nav.arquivos('#arquivos', [FX + 'nfe_teuto.xml', FX + 'nfe_estevia_es.xml']);
  await nav.js(`document.querySelector('form.formcard button.primary').click()`);
  await nav.esperar(`!!document.getElementById('form-importar')`, 15000, 'prévia 2');
  ok('a nota do RJ aparece como "Já cadastrada" (a do ES continua travada)', (await nav.js(`document.querySelectorAll('#form-importar .st.s-atrasado').length`)) === 1);
  ok('e vêm desmarcadas', await nav.js(`[...document.querySelectorAll('#form-importar [data-f="inc"]')].every(c => !c.checked)`));
  ok('botão Gravar fica desativado sem nada marcado', await nav.js(`document.getElementById('imp-gravar').disabled`));

  console.log('Prévia desatualizada: outra pessoa cadastra a mesma nota antes de gravar');
  const csvTmp = tmpdir().replace(/\\/g, '/') + '/zz_corrida.csv';
  writeFileSync(csvTmp, 'Fornecedor;NF;Data\nZZCORRIDA;777001;2026-10-31\nZZ' + 'B'.repeat(400) + ';777002;2026-10-31\n');
  await nav.ir(B + '/importar.php');
  await nav.arquivos('#arquivos', [csvTmp]);
  await nav.js(`document.querySelector('form.formcard button.primary').click()`);
  await nav.esperar(`!!document.getElementById('form-importar')`, 15000, 'prévia corrida');
  ok('nome gigante foi cortado em 150 caracteres na prévia', (await nav.js(`[...document.querySelectorAll('#form-importar [data-f="fornecedor"]')].map(i => i.value.length).sort((a,b)=>b-a)[0]`)) <= 150);
  const PHP_INS = '$_SERVER["SCRIPT_NAME"]="x";$_SERVER["HTTP_HOST"]="localhost";require "C:/xampp2/htdocs/agendamentos/inc/bootstrap.php";q("INSERT INTO agendamentos (empresa,fornecedor,nota_fiscal,origem,entregue,criado_por) VALUES (\\"GREEN MED\\",\\"ZZCORRIDA\\",\\"777001\\",\\"portal\\",\\"N\\",(SELECT id FROM usuarios WHERE login=\\"tmp.a\\"))");';
  execFileSync('C:/xampp2/php/php.exe', ['-r', PHP_INS]);
  await nav.js(`document.getElementById('imp-gravar').click()`);
  await nav.esperar(`!!document.querySelector('.flash')`, 15000, 'mensagem após gravar');
  const msg = await nav.js(`document.querySelector('.flash').textContent`);
  ok('a nota repetida NÃO foi gravada de novo', msg.includes('já foi cadastrada por outra pessoa'), msg);
  ok('a outra nota (nome gigante) foi gravada normalmente', msg.includes('1 nota importada'), msg);

  console.log('Planilha diz "recebido" para nota que já existe e está atrasada');
  const ontem = execFileSync('C:/xampp2/php/php.exe', ['-r', 'echo date("Y-m-d", strtotime("-1 day"));']).toString();
  const amanha2 = execFileSync('C:/xampp2/php/php.exe', ['-r', 'echo date("Y-m-d", strtotime("+1 day"));']).toString();
  const br = (d) => d.split('-').reverse().join('/');
  const phpq = (c) => execFileSync('C:/xampp2/php/php.exe', ['-r', '$_SERVER["SCRIPT_NAME"]="x";$_SERVER["HTTP_HOST"]="localhost";require "C:/xampp2/htdocs/agendamentos/inc/bootstrap.php";' + c]).toString();
  phpq(`q("INSERT INTO agendamentos (empresa, uf, fornecedor, nota_fiscal, volumes, volumes_num, data_receber, entregue, origem, criado_por, criado_em) VALUES (\\"GREEN MED\\", \\"RJ\\", \\"ZZBAIXA\\", \\"555001\\", \\"5\\", 5, ?, \\"N\\", \\"portal\\", (SELECT id FROM usuarios WHERE login = \\"tmp.a\\"), NOW())", ["${ontem}"]);`);
  const col = (forn, c) => phpq(`echo q("SELECT ${c} FROM agendamentos WHERE fornecedor = ?", ["${forn}"])->fetchColumn();`);
  await nav.ir(B + '/importar.php');
  await nav.js(`document.querySelector('textarea[name=texto]').value = ${JSON.stringify(`Fornecedor;NF;Data;Recebido\nZZBAIXA;555001;${br(ontem)};${br(ontem)}\nZZNOVA RECEBIDA;555002;${br(ontem)};sim\nZZPENDENTE;555003;${br(amanha2)};não`)}; document.querySelector('form.formcard button.primary').click();`);
  await nav.esperar(`!!document.getElementById('form-importar')`, 15000, 'prévia com recebido');
  const linhaDe = (forn) => `[...document.querySelectorAll('#form-importar tbody tr')].find(t => t.querySelector('[data-f="fornecedor"]').value === '${forn}')`;
  ok('a nota existente aparece como "Já cadastrada" e não vai ser criada de novo', await nav.js(`${linhaDe('ZZBAIXA')}.textContent.includes('Já cadastrada') && !${linhaDe('ZZBAIXA')}.querySelector('[data-f="inc"]').checked`));
  const txtBaixa = await nav.js(`${linhaDe('ZZBAIXA')}.querySelector('.imp-baixa')?.textContent || ''`);
  ok(`mostra o que vai mudar: "Atrasado → Recebida em ${br(ontem)}"`, txtBaixa.includes('Atrasado') && txtBaixa.includes('Recebida em ' + br(ontem)), txtBaixa.trim());
  ok('"Dar entrada" vem marcado (você pode desmarcar)', await nav.js(`${linhaDe('ZZBAIXA')}.querySelector('[data-f="baixa"]').checked`));
  ok('nota nova já recebida avisa que entra como recebida', (await nav.js(`${linhaDe('ZZNOVA RECEBIDA')}.textContent`)).includes('já entra como recebida'));
  ok('contagem mostra "1 vai receber entrada"', (await nav.js(`document.getElementById('imp-contagem').textContent`)).includes('1 vai receber entrada'), await nav.js(`document.getElementById('imp-contagem').textContent`));
  if (FOTOS) await nav.foto(FOTOS + '/imp-5-recebido.png');
  await nav.js(`document.getElementById('imp-gravar').click()`);
  await nav.esperar(`document.readyState === 'complete' && !!document.querySelector('.flash')`, 15000, 'gravar');
  const msgB = await nav.js(`document.querySelector('.flash').textContent`);
  ok('mensagem conta a entrada pela planilha', msgB.includes('recebeu entrada pela planilha'), msgB);
  ok('a nota atrasada ficou recebida, no dia que a planilha disse', col('ZZBAIXA', `CONCAT(entregue, '|', DATE(entregue_em))`) === 'S|' + ontem, col('ZZBAIXA', `CONCAT(entregue, '|', DATE(entregue_em))`));
  ok('não criou nota repetida', phpq('echo q("SELECT COUNT(*) FROM agendamentos WHERE fornecedor = \\"ZZBAIXA\\"")->fetchColumn();') === '1');
  ok('histórico diz que a entrada veio da planilha', phpq(`echo q("SELECT detalhes FROM historico WHERE agendamento_id = ? AND acao = \\"entregue\\"", [${col('ZZBAIXA', 'id')}])->fetchColumn();`).includes('planilha'));
  ok('a nota nova entrou já como recebida', col('ZZNOVA RECEBIDA', 'entregue') === 'S');
  ok('a que a planilha diz "não" ficou aguardando', col('ZZPENDENTE', 'entregue') === 'N');

  console.log('Celular (390 px)');
  await nav.tela(390, 900, true);
  await nav.ir(B + '/importar.php');
  ok('sem rolagem horizontal na tela de envio', await nav.js(`document.documentElement.scrollWidth <= window.innerWidth + 1`), String(await nav.js(`document.documentElement.scrollWidth`)));
  if (FOTOS) await nav.foto(FOTOS + '/imp-4-celular.png');
} catch (e) {
  falhas++;
  console.log('  ERRO   ' + e.message);
} finally {
  await nav.fechar();
}
console.log(`\n${falhas ? falhas + ' de ' + total + ' verificações falharam.' : 'Todas as ' + total + ' verificações passaram.'}`);
process.exit(falhas ? 1 : 0);
