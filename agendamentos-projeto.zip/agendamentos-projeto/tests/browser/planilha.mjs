// Teste no navegador da troca pela planilha nova (/admin/planilha.php). ATENÇÃO: troca as notas da planilha no banco local.
// Uso (na pasta tests/browser):  php preparar.php && node planilha.mjs <planilha.json> && php limpar.php
import { abrirNavegador } from './cdp.mjs';
import { execFileSync } from 'node:child_process';

const B = 'http://localhost/agendamentos';
const ARQ = process.argv[2];
let falhas = 0, total = 0;
const ok = (nome, cond, det = '') => { total++; if (!cond) falhas++; console.log((cond ? '  ok    ' : '  FALHA ') + nome + (cond || !det ? '' : '  → ' + det)); };
const php = (c) => execFileSync('C:/xampp2/php/php.exe', ['-r', '$_SERVER["SCRIPT_NAME"]="x";$_SERVER["HTTP_HOST"]="localhost";require "C:/xampp2/htdocs/agendamentos/inc/bootstrap.php";' + c]).toString();
const mil = (n) => String(n).replace(/\B(?=(\d{3})+(?!\d))/g, '.');
const sq = (t) => "'" + String(t).replace(/'/g, "''") + "'";
const conta = (w) => +php(`echo q("SELECT COUNT(*) FROM agendamentos WHERE ${w}")->fetchColumn();`);
const esperado = JSON.parse(execFileSync('C:/xampp2/php/php.exe', ['-r', 'echo json_encode(array_map("count", json_decode(file_get_contents($argv[1]), true)));', '--', ARQ]).toString());

// uma nota criada pelo site com o mesmo fornecedor + NF de uma linha da planilha: tem que ficar, e a linha ser pulada
const umaDaPlanilha = JSON.parse(execFileSync('C:/xampp2/php/php.exe', ['-r', '$j=json_decode(file_get_contents($argv[1]),true); foreach($j["agendamentos"] as $a) if($a[9] !== "" && $a[5] !== "") { echo json_encode([$a[5], $a[9]]); break; }', '--', ARQ]).toString());
// criado_por = tmp.adm, para o limpar.php apagar depois
php(`q("INSERT INTO agendamentos (empresa, uf, fornecedor, nota_fiscal, entregue, origem, criado_em, criado_por) VALUES (\\"GREEN MED\\", \\"RJ\\", ?, ?, \\"N\\", \\"portal\\", NOW(), (SELECT id FROM usuarios WHERE login = \\"tmp.adm\\"))", [${JSON.stringify(umaDaPlanilha[0])}, ${JSON.stringify(umaDaPlanilha[1])}]);`);
const doSiteAntes = conta(`origem <> 'planilha'`);

const nav = await abrirNavegador({ porta: 9461, largura: 1200, altura: 1000 });
try {
  await nav.ir(B + '/admin/login.php');
  await nav.js(`document.querySelector('#login').value='tmp.adm'; document.querySelector('#senha').value='Zq8mTe42xYw'; document.querySelector('form').submit();`);
  await nav.esperar(`document.readyState === 'complete' && !location.pathname.endsWith('login.php')`, 10000, 'entrar no admin');
  await nav.ir(B + '/admin/planilha.php');
  ok('aba "Planilha" no admin', await nav.js(`[...document.querySelectorAll('nav.tabs .tab')].some(t => t.textContent.includes('Planilha') && t.getAttribute('aria-current') === 'page')`));

  console.log('Arquivo errado é recusado');
  const errado = 'C:/xampp2/htdocs/agendamentos/tests/fixtures/lote.csv';
  await nav.arquivos('input[name=arquivo]', [errado]);
  await nav.js(`document.querySelector('input[name=arquivo]').closest('form').submit()`);
  await nav.esperar(`document.readyState === 'complete' && !!document.querySelector('.flash.erro')`, 10000);
  ok('mostra que não é o formato da planilha', (await nav.js(`document.querySelector('.flash.erro').textContent`)).includes('formato'));

  console.log('Enviar a planilha nova e ver a prévia');
  await nav.arquivos('input[name=arquivo]', [ARQ]);
  await nav.js(`document.querySelector('input[name=arquivo]').closest('form').submit()`);
  await nav.esperar(`document.readyState === 'complete' && document.body.textContent.includes('Arquivo recebido') && !!document.getElementById('form-substituir')`, 15000, 'prévia');
  const prev = await nav.js(`document.getElementById('form-substituir').textContent`);
  ok(`prévia mostra ${esperado.agendamentos - 1} notas a carregar (uma pulada)`, prev.includes('Carregar (planilha nova)' + mil(esperado.agendamentos - 1) + ' notas'), prev.slice(0, 300));
  ok('prévia avisa a nota do site que vai ser mantida (pulada da planilha)', prev.includes('Pular') && prev.includes(umaDaPlanilha[0]));
  ok('nada mudou ainda', conta(`fornecedor = ${sq(umaDaPlanilha[0])} AND nota_fiscal = ${sq(umaDaPlanilha[1])}`) >= 1 && conta(`origem = 'planilha'`) > 0);

  console.log('Confirmação obrigatória');
  await nav.js(`const f = document.getElementById('form-substituir'); f.confirmo.checked = true; f.palavra.value = 'sim'; f.submit();`);
  await nav.esperar(`document.readyState === 'complete' && !!document.querySelector('.flash.erro')`, 10000);
  ok('sem digitar SUBSTITUIR não troca nada', (await nav.js(`document.querySelector('.flash.erro').textContent`)).includes('SUBSTITUIR'));

  console.log('Substituir');
  const antesPlanilha = conta(`origem = 'planilha'`);
  await nav.js(`const f = document.getElementById('form-substituir'); f.confirmo.checked = true; f.palavra.value = 'substituir'; f.submit();`);
  await nav.esperar(`document.readyState === 'complete' && document.body.textContent.includes('Pronto: planilha nova carregada')`, 60000, 'troca');
  const fim = await nav.js(`document.querySelector('.formcard').textContent`);
  ok(`apagou as ${antesPlanilha} da planilha antiga`, fim.includes(mil(antesPlanilha)), fim.slice(0, 300));
  ok(`carregou ${esperado.agendamentos - 1} (uma pulada por já existir no site)`, conta(`origem = 'planilha'`) === esperado.agendamentos - 1, String(conta(`origem = 'planilha'`)));
  ok('as notas criadas pelo site ficaram', conta(`origem <> 'planilha'`) === doSiteAntes);
  ok(`Recebidas ES: ${esperado.recebidas}`, +php('echo q("SELECT COUNT(*) FROM recebidas_es")->fetchColumn();') === esperado.recebidas);
  const bkp = /backup_antes_planilha_[\d_-]+\.sql(\.gz)?/.exec(fim)?.[0];
  ok('fez backup antes', !!bkp && +execFileSync('C:/xampp2/php/php.exe', ['-r', 'echo filesize($argv[1]);', '--', 'C:/xampp2/htdocs/agendamentos/backups/' + bkp]).toString() > 10000, String(bkp));
  ok('apagou o arquivo da planilha do servidor', execFileSync('C:/xampp2/php/php.exe', ['-r', 'echo is_file("C:/xampp2/htdocs/agendamentos/dados/planilha_enviada.json") ? "tem" : "não";']).toString() === 'não');
  await nav.ir(B + '/login.php');
  await nav.js(`document.querySelector('#login').value='tmp.a'; document.querySelector('#senha').value='Zq8mTe42xYw'; document.querySelector('form').submit();`);
  await nav.esperar(`document.readyState === 'complete' && !location.pathname.endsWith('login.php')`, 10000, 'entrar na agenda');
  ok('a agenda abre e mostra as notas', await nav.js(`!document.querySelector('.erro500') && document.body.textContent.includes('Agenda')`));
} catch (e) {
  falhas++;
  console.log('  ERRO   ' + e.message);
} finally {
  await nav.fechar();
}
console.log(`\n${falhas ? falhas + ' de ' + total + ' verificações falharam.' : 'Todas as ' + total + ' verificações passaram.'}`);
process.exit(falhas ? 1 : 0);
