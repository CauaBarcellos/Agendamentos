import { abrirNavegador } from './cdp.mjs';
const D = process.argv[2], B = 'http://localhost/agendamentos', FX = 'C:/xampp2/htdocs/agendamentos/tests/fixtures/';
const nav = await abrirNavegador({ largura: 390, altura: 844, mobile: true });
const medir = async (p, n) => {
  await nav.sleep(500);
  const w = await nav.js(`document.documentElement.scrollWidth`);
  console.log(p.padEnd(22), 'largura', w, w > 391 ? 'ROLAGEM HORIZONTAL' : 'ok');
  await nav.foto(D + '/' + n + '.png');
};
try {
  await nav.tela(390, 844, true);
  await nav.ir(B + '/admin/login.php'); await medir('admin/login', 'a1-admin-login');
  await nav.js(`document.querySelector('#login').value='tmp.adm'; document.querySelector('#senha').value='Zq8mTe42xYw'; document.querySelector('form').submit();`);
  await nav.esperar(`location.pathname.endsWith('/admin/index.php') || location.pathname.endsWith('/admin/')`, 10000);
  await nav.esperarCarga().catch(()=>{});
  await medir('admin/index', 'a2-admin-usuarios');
  for (const [p, n] of [['painel.php', 'a3-admin-painel'], ['historico.php', 'a4-admin-historico'], ['backup.php', 'a5-admin-backup']]) { await nav.ir(B + '/admin/' + p); await medir('admin/' + p, n); }
  await nav.ir(B + '/login.php'); await medir('login', 'm1-login');
  await nav.js(`document.querySelector('#login').value='tmp.a'; document.querySelector('#senha').value='Zq8mTe42xYw'; document.querySelector('form').submit();`);
  await nav.esperar(`typeof window.__agenda === 'object'`, 10000);
  const href = await nav.js(`document.querySelector('.row[data-href]').dataset.href`);
  await nav.ir(B + '/' + href); await medir('detalhe da nota', 'm2-detalhe');
  await nav.js(`window.scrollTo(0, 99999)`); await nav.sleep(300); await nav.foto(D + '/m2b-detalhe-fim.png');
  await nav.ir(B + '/importar.php');
  await nav.arquivos('#arquivos', [FX + 'nfe_teuto.xml', FX + 'nfe_estevia_es.xml', FX + 'lote.csv']);
  await nav.js(`document.querySelector('form.formcard button.primary').click()`);
  await nav.esperar(`!!document.getElementById('form-importar')`, 15000);
  await medir('importar: prévia', 'm3-previa');
  await nav.js(`document.getElementById('imp-gravar').scrollIntoView()`); await nav.sleep(300); await nav.foto(D + '/m3b-previa-fim.png');
} catch (e) { console.log('ERR', e.message); } finally { await nav.fechar(); }
process.exit(0);
