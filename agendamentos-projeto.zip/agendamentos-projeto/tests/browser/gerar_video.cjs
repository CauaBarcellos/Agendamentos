// Gera um "vídeo de câmera" (formato y4m) mostrando o código de barras CODE-128 (tipo C) de uma chave de NF-e,
// igual ao do DANFE. Confere a imagem lendo de volta com o leitor da ZXing antes de salvar.
// Uso: node gerar_video.cjs <chave44> <saida.y4m>
const fs = require('fs');
global.self = global; // a versão UMD da biblioteca espera um "self"
const Z = require('../../assets/vendor/zxing.min.js');
const [chave, saida] = process.argv.slice(2);
const P = Z.Code128Reader.CODE_PATTERNS;

// Code 128 C: início (105), pares de dígitos, dígito de controle (mod 103), fim (106)
const cod = [105];
for (let i = 0; i < chave.length; i += 2) cod.push(+chave.substr(i, 2));
cod.push(cod.reduce((s, v, i) => s + v * (i || 1), 0) % 103, 106);
const modulos = [];
for (const c of cod) Array.from(P[c]).forEach((larg, k) => { for (let n = 0; n < larg; n++) modulos.push(k % 2 === 0 ? 1 : 0); });

const W = 640, H = 480, ESC = 2, ALT = 150, QUADROS = 20;
const larg = modulos.length * ESC, ox = Math.floor((W - larg) / 2), oy = Math.floor((H - ALT) / 2);
const y = Buffer.alloc(W * H, 235); // fundo claro (Y em 16..235)
for (let j = 0; j < ALT; j++) for (let i = 0; i < larg; i++) if (modulos[Math.floor(i / ESC)]) y[(oy + j) * W + ox + i] = 16;

// confere: a ZXing lê a mesma chave nessa imagem?
const lum = new Uint8ClampedArray(W * H); y.forEach((v, i) => { lum[i] = v; });
const fonte = new Z.RGBLuminanceSource(lum, W, H);
const lido = new Z.Code128Reader().decode(new Z.BinaryBitmap(new Z.HybridBinarizer(fonte)), new Map()).getText();
if (lido !== chave) { console.error('imagem gerada não confere:', lido); process.exit(1); }

const uv = Buffer.alloc((W / 2) * (H / 2), 128);
const partes = [Buffer.from(`YUV4MPEG2 W${W} H${H} F10:1 Ip A1:1 C420jpeg\n`)];
for (let q = 0; q < QUADROS; q++) partes.push(Buffer.from('FRAME\n'), y, uv, uv);
fs.writeFileSync(saida, Buffer.concat(partes));
console.log('ok', modulos.length + ' módulos, conferido pela ZXing');
