// Confere o topo do site em várias larguras: nada encavalado, nada cortado, sem rolagem lateral.
// Uso (na pasta tests/browser):  php preparar.php && node topo.mjs && php limpar.php
import { abrirNavegador } from './cdp.mjs';

const B = 'http://localhost/agendamentos';
let falhas = 0, total = 0;
const ok = (nome, cond, det = '') => { total++; if (!cond) falhas++; console.log((cond ? '  ok    ' : '  FALHA ') + nome + (cond || !det ? '' : '  → ' + det)); };

const nav = await abrirNavegador({ porta: 9381, largura: 1400, altura: 900 });
try {
  await nav.ir(B + '/login.php');
  await nav.js(`document.querySelector('#login').value='tmp.a'; document.querySelector('#senha').value='Zq8mTe42xYw'; document.querySelector('form').submit();`);
  await nav.esperar(`typeof window.__agenda === 'object'`, 10000, 'entrar');
  for (const w of [1440, 1280, 1200, 1100, 1024, 960, 900, 861, 860, 768, 600, 390, 360]) {
    await nav.tela(w, 900, w <= 600);
    await nav.sleep(150);
    // Elementos visíveis do topo que se sobrepõem (cada par só uma vez).
    const r = await nav.js(`(() => {
      const els = [...document.querySelectorAll('header .brand, header .tab, header .topin > .btn, header .user, header .logo-emp')]
        .filter(e => { const s = getComputedStyle(e); return s.display !== 'none' && s.visibility !== 'hidden' && e.getBoundingClientRect().width > 0 && s.position !== 'fixed' && !e.closest('nav.tabs[style*=fixed]') && getComputedStyle(e.closest('nav') || e).position !== 'fixed'; });
      const bate = [];
      for (let i = 0; i < els.length; i++) for (let j = i + 1; j < els.length; j++) {
        const a = els[i].getBoundingClientRect(), b = els[j].getBoundingClientRect();
        if (a.left < b.right - 1 && b.left < a.right - 1 && a.top < b.bottom - 1 && b.top < a.bottom - 1) bate.push((els[i].textContent.trim() || els[i].className).slice(0, 14) + ' x ' + (els[j].textContent.trim() || els[j].className).slice(0, 14));
      }
      return JSON.stringify({ bate, larg: document.documentElement.scrollWidth });
    })()`);
    const { bate, larg } = JSON.parse(r);
    ok(`${w}px: topo sem sobreposição e sem rolagem lateral`, !bate.length && larg <= w + 1, bate.join('; ') + (larg > w + 1 ? ` (largura ${larg})` : ''));
  }
} catch (e) {
  falhas++;
  console.log('  ERRO   ' + e.message);
} finally {
  await nav.fechar();
}
console.log(`\n${falhas ? falhas + ' de ' + total + ' verificações falharam.' : 'Todas as ' + total + ' verificações passaram.'}`);
process.exit(falhas ? 1 : 0);
