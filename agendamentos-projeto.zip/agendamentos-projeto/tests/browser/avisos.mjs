// Teste de ponta a ponta dos avisos no celular (Web Push de verdade, pelo serviço do Google) e do app instalável.
// Dois navegadores: um com administrador do RJ (tmp.adm), outro com a filial ES (tmp.es). Uma terceira pessoa (tmp.a)
// age por HTTP. Confere que cada aviso chega como notificação no navegador certo.
// Uso (na pasta tests/browser):  php preparar.php && node avisos.mjs && php limpar.php   (precisa de internet)
import { abrirNavegador } from './cdp.mjs';
import { execFileSync } from 'node:child_process';

const B = 'http://localhost/agendamentos';
const PW = 'Zq8mTe42xYw';
let falhas = 0, total = 0;
const ok = (nome, cond, det = '') => { total++; if (!cond) falhas++; console.log((cond ? '  ok    ' : '  FALHA ') + nome + (cond || !det ? '' : '  → ' + det)); };
const php = (c) => execFileSync('C:/xampp2/php/php.exe', ['-r', '$_SERVER["SCRIPT_NAME"]="x";$_SERVER["HTTP_HOST"]="localhost";require "C:/xampp2/htdocs/agendamentos/inc/bootstrap.php";' + c]).toString();
const inscricoes = (login) => +php(`echo q("SELECT COUNT(*) FROM push_inscricoes p JOIN usuarios u ON u.id = p.usuario_id WHERE u.login = ?", ["${login}"])->fetchColumn();`);
const amanha = php('echo soma_dias(hoje(), 1);');

// Pessoa que age por HTTP (sem navegador): login com cookie.
class Sessao {
  jar = new Map();
  guardar(r) { for (const c of r.headers.getSetCookie()) { const [nv] = c.split(';'); const i = nv.indexOf('='); this.jar.set(nv.slice(0, i), nv.slice(i + 1)); } }
  async pedir(caminho, opc = {}) { const r = await fetch(B + caminho, { redirect: 'manual', ...opc, headers: { cookie: [...this.jar].map(([k, v]) => k + '=' + v).join('; '), ...(opc.headers || {}) } }); this.guardar(r); return { status: r.status, texto: await r.text() }; }
  post(caminho, campos, extra = {}) { return this.pedir(caminho, { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded', ...extra }, body: new URLSearchParams(campos) }); }
  async csrf(caminho) { return /name="csrf"[^>]*value="([^"]+)"/.exec((await this.pedir(caminho)).texto)?.[1] ?? ''; }
}

async function abrir(porta, login) {
  const nav = await abrirNavegador({ porta, largura: 1100, altura: 900 });
  await nav.send('Browser.grantPermissions', { permissions: ['notifications'], origin: 'http://localhost' });
  await nav.ir(B + '/login.php');
  await nav.js(`document.querySelector('#login').value='${login}'; document.querySelector('#senha').value='${PW}'; document.querySelector('form').submit();`);
  await nav.esperar(`document.readyState === 'complete' && !location.pathname.endsWith('login.php') && !!document.getElementById('app-itens')`, 10000, 'entrar ' + login);
  // registra se algum envio ao push.php levar "https://" (o firewall da hospedagem bloqueia com erro 406)
  await nav.js(`window.__comHttps = 0; const f0 = window.fetch; window.fetch = function (u, o) { if (String(u).includes('push.php') && o && o.body instanceof FormData) { for (const [, v] of o.body) if (String(v).includes('://')) window.__comHttps++; } return f0.apply(this, arguments); };`);
  return nav;
}
// Espera uma notificação com esse título aparecer no navegador.
// O aviso chega pelo serviço do Google, o service worker decifra e entrega à página aberta (window.__avisos).
// (O Chrome sem tela usado nos testes não tem central de notificações; no celular a notificação aparece normalmente.)
const notificacao = (nav, titulo, ms = 90000) => nav.esperar(`(window.__avisos || []).some(a => a.titulo === ${JSON.stringify(titulo)})`, ms, 'aviso "' + titulo + '"');
const dados = (nav, titulo) => nav.js(`(() => { const a = (window.__avisos || []).find(a => a.titulo === ${JSON.stringify(titulo)}); return a ? JSON.stringify({ corpo: a.corpo, url: a.url }) : ''; })()`);
const recebeu = (nav, titulo) => nav.js(`(window.__avisos || []).some(a => a.titulo === ${JSON.stringify(titulo)})`);
const ativar = async (nav) => {
  await nav.esperar(`!document.getElementById('avisos-bt').hidden`, 8000, 'botão de avisos');
  await nav.sleep(2500); // o Chrome recém-aberto do teste leva um instante para conectar ao serviço de push do Google
  await nav.js(`document.querySelector('details.user').open = true; document.getElementById('avisos-bt').click();`);
  await nav.esperar(`(document.getElementById('toast')?.textContent || '').includes('ativados')`, 45000, 'ativar avisos');
};

let rj, es;
try {
  console.log('App instalável');
  rj = await abrir(9431, 'tmp.adm');
  const man = await rj.send('Page.getAppManifest', {});
  const md = JSON.parse(man.data || '{}');
  ok('manifesto sem erros, com nome, tela cheia e ícones 192/512', !man.errors.length && md.short_name === 'Agendamentos' && md.display === 'standalone' && ['192x192', '512x512'].every((s) => md.icons.some((i) => i.sizes === s)), JSON.stringify(man.errors));
  ok('ícone "maskable" para o Android', md.icons.some((i) => i.purpose === 'maskable'));
  ok('service worker ativo no portal', (await rj.js(`navigator.serviceWorker.ready.then(r => r.scope + '|' + !!r.active)`)) === B + '/|true');
  ok('menu tem "Ativar avisos neste aparelho"', await rj.js(`!document.getElementById('avisos-bt').hidden || true`) && (await rj.js(`document.getElementById('avisos-bt').textContent`)).includes('Ativar avisos'));

  console.log('Ativar avisos e aviso de teste');
  await ativar(rj);
  ok('inscrição gravada para o administrador', inscricoes('tmp.adm') === 1, String(inscricoes('tmp.adm')));
  ok('nenhum envio ao servidor leva "https://" (o firewall da HostGator bloquearia com 406)', (await rj.js('window.__comHttps')) === 0, String(await rj.js('window.__comHttps')));
  ok('botão vira "Desativar" e aparece "Enviar aviso de teste"', (await rj.js(`document.getElementById('avisos-bt').textContent`)).includes('Desativar') && await rj.js(`!document.getElementById('avisos-teste').hidden`));
  await rj.js(`document.getElementById('avisos-teste').click()`);
  // o próprio aviso pode chegar antes da resposta e aparecer por cima da mensagem "enviado"
  await rj.esperar(`(document.getElementById('toast')?.textContent || '').includes('enviado') || (window.__avisos || []).some(a => a.titulo === 'Aviso de teste')`, 60000, 'envio do teste').catch(async (e) => { throw new Error(e.message + ' | mensagem na tela: ' + (await rj.js(`document.getElementById('toast')?.textContent || ''`))); });
  await notificacao(rj, 'Aviso de teste');
  ok('o aviso de teste chegou de verdade (via serviço do Google)', true);
  const dt = JSON.parse(await dados(rj, 'Aviso de teste'));
  ok('chegou decifrado, com o texto certo', dt.corpo.includes('funcionando'), JSON.stringify(dt));

  console.log('Os 4 avisos');
  es = await abrir(9432, 'tmp.es');
  await ativar(es);
  ok('inscrição gravada para a filial ES', inscricoes('tmp.es') === 1);

  // 1) ES registra chegada → RJ
  await es.ir(B + '/es.php');
  await es.js(`const f=document.getElementById('es-nova'); f.fornecedor.value='zzaviso forn'; f.produto.value='soro'; f.nota_fiscal.value='77001'; f.chegou_es_em.value='${php('echo hoje();')}'; f.submit();`);
  await notificacao(rj, 'Chegou nota no ES');
  const d1 = JSON.parse(await dados(rj, 'Chegou nota no ES'));
  ok('1) ES registrou chegada → RJ recebe "Chegou nota no ES"', d1.corpo.includes('Zzaviso Forn') && d1.corpo.includes('77001') && d1.url === 'index.php?dia=es', JSON.stringify(d1));
  ok('   quem registrou (ES) não recebe o próprio aviso', !(await recebeu(es, 'Chegou nota no ES')));

  // 2) RJ escolhe o dia → ES
  const idNota = php('echo q("SELECT id FROM agendamentos WHERE fornecedor = \\"ZZAVISO FORN\\"")->fetchColumn();');
  await rj.ir(B + '/agendamento.php?id=' + idNota);
  await rj.js(`const f=document.querySelector('form.es-receber-det'); f.data_receber.value='${amanha}'; f.submit();`);
  await notificacao(es, 'O RJ pediu uma nota');
  const d2 = JSON.parse(await dados(es, 'O RJ pediu uma nota'));
  ok('2) RJ escolheu o dia → ES recebe "O RJ pediu uma nota"', d2.corpo.includes('Zzaviso Forn') && d2.url === 'es.php', JSON.stringify(d2));

  // 3) Entrada com divergência (feita por outra pessoa do RJ) → administrador e ES (a nota é do ES)
  const ana = new Sessao();
  await ana.post('/login.php', { login: 'tmp.a', senha: PW });
  const tok = await ana.csrf('/receber.php?id=' + idNota);
  await ana.post('/receber.php', { csrf: tok, id: idNota, vol_recebidos: '1', tudo_ok: 'nao', 'tipos[]': 'avaria', obs: 'caixa molhada' });
  await notificacao(rj, 'Entrada com divergência');
  const d3 = JSON.parse(await dados(rj, 'Entrada com divergência'));
  ok('3) entrada com divergência → administrador recebe, com o motivo', d3.corpo.includes('Zzaviso Forn') && d3.corpo.includes('avaria') && d3.corpo.includes('caixa molhada') && d3.url === 'agendamento.php?id=' + idNota, JSON.stringify(d3));
  await notificacao(es, 'Chegou no RJ com divergência');
  ok('   e a filial ES também (a nota era dela)', true);

  // 4) Resumo da manhã das atrasadas (cron)
  const saida = execFileSync('C:/xampp2/php/php.exe', ['C:/xampp2/htdocs/agendamentos/avisos_cron.php', '--forcar']).toString();
  await notificacao(rj, 'Notas atrasadas');
  const d4 = JSON.parse(await dados(rj, 'Notas atrasadas'));
  ok('4) resumo das atrasadas → RJ recebe, com link para "Atrasados"', d4.corpo.includes('para trás') && d4.url === 'index.php?dia=atrasados', JSON.stringify(d4) + ' | ' + saida.trim());
  ok('   o ES não recebe o resumo do RJ', !(await recebeu(es, 'Notas atrasadas')));
  const de_novo = execFileSync('C:/xampp2/php/php.exe', ['C:/xampp2/htdocs/agendamentos/avisos_cron.php']).toString();
  ok('   não manda o resumo duas vezes no mesmo dia', de_novo.includes('já enviado'));

  console.log('Sem internet');
  // corta a rede da página e também do service worker (que é quem busca as páginas)
  const semRede = { offline: true, latency: 0, downloadThroughput: -1, uploadThroughput: -1 };
  const alvos = (await rj.send('Target.getTargets')).targetInfos.filter((t) => t.type === 'service_worker' && t.url.startsWith(B));
  const sessoes = [];
  for (const t of alvos) { const { sessionId } = await rj.send('Target.attachToTarget', { targetId: t.targetId, flatten: true }); await rj.send('Network.enable', {}, sessionId); await rj.send('Network.emulateNetworkConditions', semRede, sessionId); sessoes.push(sessionId); }
  await rj.send('Network.enable');
  await rj.send('Network.emulateNetworkConditions', semRede);
  await rj.ir(B + '/index.php').catch(() => {});
  await rj.esperar(`document.readyState === 'complete'`, 8000).catch(() => {});
  ok('sem conexão mostra a página "Sem conexão" do app', (await rj.js(`document.body.innerText`)).includes('Sem conexão'), `service workers: ${alvos.length}`);
  const comRede = { offline: false, latency: 0, downloadThroughput: -1, uploadThroughput: -1 };
  for (const sid of sessoes) await rj.send('Network.emulateNetworkConditions', comRede, sid);
  await rj.send('Network.emulateNetworkConditions', comRede);

  console.log('Desativar');
  await rj.ir(B + '/index.php');
  await rj.esperar(`document.readyState === 'complete' && !document.getElementById('avisos-bt').hidden`, 10000);
  await rj.js(`document.querySelector('details.user').open = true; document.getElementById('avisos-bt').click();`);
  await rj.esperar(`(document.getElementById('toast')?.textContent || '').includes('desativados')`, 15000, 'desativar');
  ok('"Desativar" apaga a inscrição deste aparelho', inscricoes('tmp.adm') === 0);
  const r = await ana.post('/push.php', { csrf: tok, acao: 'inscrever', endpoint: 'https://evil.example.com/x', p256dh: 'x', auth: 'y' });
  ok('endereço de push desconhecido é recusado', r.status === 400 && inscricoes('tmp.a') === 0, String(r.status));
} catch (e) {
  falhas++;
  console.log('  ERRO   ' + e.message);
} finally {
  if (rj) await rj.fechar();
  if (es) await es.fechar();
}
console.log(`\n${falhas ? falhas + ' de ' + total + ' verificações falharam.' : 'Todas as ' + total + ' verificações passaram.'}`);
process.exit(falhas ? 1 : 0);
