// Gera os ícones do app (PNG) desenhando o mesmo "A" verde do favicon no Chrome.
//  - icon-192.png / icon-512.png: quadrado arredondado (ícone normal)
//  - icon-maskable-512.png: fundo verde até a borda e o "A" na área segura (Android recorta em círculo/gota)
//  - badge-96.png: silhueta branca em fundo transparente (ícone pequeno da barra de notificações do Android)
// Uso: node gerar_icones.mjs
import { abrirNavegador } from './cdp.mjs';

const DEST = 'C:/xampp2/htdocs/agendamentos/assets/';
const svg = (tam, { maskable = false, badge = false } = {}) => `<svg xmlns="http://www.w3.org/2000/svg" width="${tam}" height="${tam}" viewBox="0 0 100 100">
  ${badge ? '' : `<rect width="100" height="100" ${maskable ? '' : 'rx="22"'} fill="#2fb57a"/>`}
  <text x="50" y="${maskable ? 64 : 68}" text-anchor="middle" font-family="Segoe UI,Arial,sans-serif" font-size="${maskable ? 44 : 56}" font-weight="700" fill="${badge ? '#ffffff' : '#06140e'}">A</text></svg>`;

const nav = await abrirNavegador({ porta: 9411, largura: 600, altura: 600 });
try {
  for (const [arq, tam, op] of [['icon-192.png', 192, {}], ['icon-512.png', 512, {}], ['icon-maskable-512.png', 512, { maskable: true }], ['badge-96.png', 96, { badge: true }]]) {
    await nav.ir('about:blank');
    await nav.js(`document.documentElement.style.background = 'transparent'; document.body.style.margin = '0'; document.body.innerHTML = ${JSON.stringify(svg(tam, op))};`);
    await nav.send('Emulation.setDefaultBackgroundColorOverride', { color: { r: 0, g: 0, b: 0, a: 0 } });
    const r = await nav.send('Page.captureScreenshot', { format: 'png', clip: { x: 0, y: 0, width: tam, height: tam, scale: 1 } });
    const { writeFileSync } = await import('node:fs');
    writeFileSync(DEST + arq, Buffer.from(r.data, 'base64'));
    console.log('ok', arq);
  }
} catch (e) { console.log('ERRO', e.message); } finally { await nav.fechar(); }
process.exit(0);
