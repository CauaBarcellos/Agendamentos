<?php
/** Remove tudo que preparar.php criou. */
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
$_SERVER['SCRIPT_NAME'] = 'x.php'; $_SERVER['HTTP_HOST'] = 'localhost';
require dirname(__DIR__, 2) . '/inc/bootstrap.php';
$uids = q('SELECT id FROM usuarios WHERE login LIKE "tmp.%"')->fetchAll(PDO::FETCH_COLUMN);
$n = 0;
// fotos das notas de teste (registro e arquivo), antes de apagar as notas
foreach (q('SELECT f.id, f.arquivo FROM fotos f JOIN agendamentos a ON a.id = f.agendamento_id
            WHERE a.fornecedor LIKE "ZZ%" OR a.criado_por IN (SELECT id FROM usuarios WHERE login LIKE "tmp.%")')->fetchAll() as $fo) {
    @unlink(uploads_dir() . '/' . $fo['arquivo']);
    q('DELETE FROM fotos WHERE id = ?', [$fo['id']]);
}
foreach ($uids as $u) q('DELETE FROM push_inscricoes WHERE usuario_id = ?', [$u]);
foreach ($uids as $u) {
    foreach (q('SELECT id FROM agendamentos WHERE criado_por = ?', [$u])->fetchAll(PDO::FETCH_COLUMN) as $i) { q('DELETE FROM historico WHERE agendamento_id = ?', [$i]); q('DELETE FROM agendamentos WHERE id = ?', [$i]); $n++; }
    q('DELETE FROM historico WHERE usuario_id = ?', [$u]);
    q('DELETE FROM usuarios WHERE id = ?', [$u]);
}
q('DELETE FROM agendamentos WHERE fornecedor LIKE "ZZ%"');
q('DELETE FROM login_falhas');
echo "limpo: $n notas, " . count($uids) . " usuários\n";
