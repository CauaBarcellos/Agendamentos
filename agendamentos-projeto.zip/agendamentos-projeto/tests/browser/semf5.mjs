// Teste no navegador: o site se atualiza sem F5.
//  - Registros, Recebidas ES, Filial ES e o Painel do admin trocam os dados sozinhos quando outra pessoa mexe;
//  - versão nova do site (arquivo novo no servidor) recarrega a página sozinha, menos quando há formulário digitado.
// Uso (na pasta tests/browser):  php preparar.php && node semf5.mjs && php limpar.php
import { abrirNavegador } from './cdp.mjs';
import { execFileSync } from 'node:child_process';

const B = 'http://localhost/agendamentos';
const PW = 'Zq8mTe42xYw';
const CSS = 'C:/xampp2/htdocs/agendamentos/assets/style.css';
let falhas = 0, total = 0;
const ok = (nome, cond, det = '') => { total++; if (!cond) falhas++; console.log((cond ? '  ok    ' : '  FALHA ') + nome + (cond || !det ? '' : '  → ' + det)); };
const php = (c) => execFileSync('C:/xampp2/php/php.exe', ['-r', '$_SERVER["SCRIPT_NAME"]="x";$_SERVER["HTTP_HOST"]="localhost";require "C:/xampp2/htdocs/agendamentos/inc/bootstrap.php";' + c]).toString();
const espera = (ms) => new Promise((r) => setTimeout(r, ms));
// "outra pessoa" mexe direto no banco (como se fosse em outro computador)
const mexer = (sql) => php(`q(${JSON.stringify(sql)});`);
const mtimeOriginal = +php(`echo filemtime(${JSON.stringify(CSS)});`);
const subirVersaoNova = (n) => php(`touch(${JSON.stringify(CSS)}, ${mtimeOriginal + n});`);
const voltarVersao = () => php(`touch(${JSON.stringify(CSS)}, ${mtimeOriginal});`);

const nav = await abrirNavegador({ porta: 9463, largura: 1300, altura: 950 });
const entrar = async (url, u) => {
  await nav.ir(url);
  await nav.js(`document.querySelector('#login').value='${u}'; document.querySelector('#senha').value='${PW}'; document.querySelector('form').submit();`);
  await nav.esperar(`document.readyState === 'complete' && !location.pathname.endsWith('login.php')`, 10000, 'entrar como ' + u);
};
const marcar = () => nav.js(`window.__marca = 1`); // some se a página recarregar
const recarregou = async () => !(await nav.js(`window.__marca === 1`));
const checar = () => nav.js(`window.__site.checar && window.__site.checar(), 1`);
// hora da última atividade do admin, lida do arquivo da sessão do navegador
const tsAdmin = async () => {
  const { cookies } = await nav.send('Network.getCookies', { urls: [B + '/'] });
  const s = cookies.find((c) => c.name === 'agend_sess');
  const dados = s ? execFileSync('C:/xampp2/php/php.exe', ['-r', 'echo @file_get_contents($argv[1]);', '--', 'C:/xampp2/tmp/sess_' + s.value]).toString() : '';
  return +(/adm\|a:\d+:\{.*?s:2:"ts";i:(\d+);/.exec(dados)?.[1] || 0);
};

try {
  await entrar(B + '/login.php', 'tmp.a');

  console.log('Registros: muda sozinho, sem recarregar e sem perder o que está digitado na busca');
  await nav.ir(B + '/registros.php?q=ZZFORN');
  await marcar();
  ok('tabela marcada para atualizar sozinha', await nav.js(`!!document.querySelector('#reg-tabela[data-vivo]') && !!document.querySelector('#resumo[data-vivo]')`));
  await nav.js(`(() => { const b = document.querySelector('.toolbar input[name=q]'); b.focus(); b.value = 'ZZFORN abc'; })()`);
  mexer(`UPDATE agendamentos SET volumes = '777', volumes_num = 777, atualizado_em = NOW() + INTERVAL 1 SECOND WHERE fornecedor = 'ZZFORN A1'`);
  await checar();
  await nav.esperar(`document.getElementById('reg-tabela').textContent.includes('777')`, 8000, 'volume novo na tabela');
  ok('o volume novo apareceu na tabela', true);
  ok('sem recarregar a página', !(await recarregou()));
  ok('a busca digitada continua lá (e com o cursor)', await nav.js(`(() => { const b = document.querySelector('.toolbar input[name=q]'); return b.value === 'ZZFORN abc' && document.activeElement === b; })()`));

  console.log('Recebidas ES');
  await nav.ir(B + '/recebidas.php');
  await marcar();
  mexer(`INSERT INTO recebidas_es (linha_planilha, fornecedor, nota_fiscal, volumes, data_recebido_rj) VALUES (0, 'ZZREC SEMF5', '445566', '3', CURDATE())`);
  // aqui sem empurrão: espera o relógio da própria página (a cada ~8 s)
  await nav.esperar(`document.getElementById('rcb-tabela').textContent.includes('445566')`, 15000, 'recebida nova');
  ok('a recebida nova apareceu sozinha, no tempo normal da página', !(await recarregou()));

  console.log('Versão nova do site');
  await nav.ir(B + '/registros.php');
  const cssAntes = await nav.js(`document.querySelector('link[href*="style.css"]').getAttribute('href')`);
  await marcar();
  subirVersaoNova(7);
  await checar();
  await nav.esperar(`window.__marca !== 1 && document.readyState === 'complete'`, 8000, 'recarregar com a versão nova');
  ok('a página recarregou sozinha', true);
  ok('já com o arquivo novo (sem Ctrl+F5)', (await nav.js(`document.querySelector('link[href*="style.css"]').getAttribute('href')`)) !== cssAntes);
  ok('avisa que o site foi atualizado', (await nav.js(`(document.getElementById('toast') || {}).textContent || ''`)).includes('versão nova'));

  console.log('Agenda: também pega a versão nova');
  await nav.ir(B + '/index.php');
  await marcar();
  subirVersaoNova(14);
  await nav.js(`window.__agenda.checar(), 1`);
  await nav.esperar(`window.__marca !== 1 && document.readyState === 'complete'`, 8000, 'agenda recarregar');
  ok('a agenda recarregou sozinha', true);

  console.log('Filial ES: com o formulário digitado não recarrega, mas os dados continuam em dia');
  voltarVersao();
  await nav.ir(B + '/logout.php');
  await entrar(B + '/login.php', 'tmp.es');
  await nav.ir(B + '/es.php');
  await marcar();
  await nav.js(`(() => { document.querySelector('.es-nova-box').open = true; const f = document.getElementById('fornecedor'); f.focus(); f.value = 'ZZDIGITADO'; f.dispatchEvent(new Event('input', { bubbles: true })); f.blur(); })()`);
  subirVersaoNova(21);
  mexer(`INSERT INTO agendamentos (empresa, uf, fornecedor, nota_fiscal, entregue, origem, chegou_es_em, criado_em, criado_por) VALUES ('GREEN MED', 'ES', 'ZZES SEMF5', '998877', 'N', 'es', CURDATE(), NOW(), (SELECT id FROM usuarios WHERE login = 'tmp.a'))`);
  await checar();
  await nav.esperar(`document.getElementById('es-listas').textContent.includes('998877')`, 8000, 'nota nova na lista do ES');
  ok('a nota nova apareceu em "Aguardando o RJ"', await nav.js(`document.querySelector('.es-aguardando') && document.querySelector('.es-aguardando').textContent.includes('998877')`));
  await espera(2500);
  await checar();
  await espera(1500);
  ok('não recarregou por cima do que estava digitado', !(await recarregou()));
  ok('o texto digitado continua no formulário', (await nav.js(`document.getElementById('fornecedor').value`)) === 'ZZDIGITADO');
  mexer(`UPDATE agendamentos SET data_receber = CURDATE() + INTERVAL 2 DAY, atualizado_em = NOW() + INTERVAL 2 SECOND WHERE fornecedor = 'ZZES SEMF5'`);
  await checar();
  await nav.esperar(`document.querySelector('.es-pedidos').textContent.includes('998877')`, 8000, 'pedido do RJ');
  ok('quando o RJ escolhe o dia, a nota passa para "O RJ pediu para enviar" sozinha', !(await recarregou()));
  voltarVersao();

  console.log('Painel do admin');
  await entrar(B + '/admin/login.php', 'tmp.adm');
  await nav.ir(B + '/admin/painel.php');
  await marcar();
  const num = () => nav.js(`+[...document.querySelectorAll('#adm-painel .stat')].find(s => s.textContent.includes('Aguardando entrega')).querySelector('.v').textContent.replace(/\\D/g, '')`);
  const antes = await num();
  const tsAntes = await tsAdmin();
  await espera(1500);
  mexer(`INSERT INTO agendamentos (empresa, uf, fornecedor, nota_fiscal, entregue, origem, data_receber, criado_em, criado_por) VALUES ('GREEN MED', 'RJ', 'ZZADM SEMF5', '112233', 'N', 'portal', CURDATE() + INTERVAL 3 DAY, NOW(), (SELECT id FROM usuarios WHERE login = 'tmp.a'))`);
  await checar();
  await nav.esperar(`+[...document.querySelectorAll('#adm-painel .stat')].find(s => s.textContent.includes('Aguardando entrega')).querySelector('.v').textContent.replace(/\\D/g, '') === ${antes + 1}`, 8000, 'número do painel');
  ok(`"Aguardando entrega" foi de ${antes} para ${antes + 1} sozinho`, !(await recarregou()));
  // a atualização automática não pode segurar o admin logado para sempre (bloqueio por 30 min sem uso)
  ok('a atualização automática não conta como uso do admin', tsAntes > 0 && (await tsAdmin()) === tsAntes, `${tsAntes} → ${await tsAdmin()}`);
  await nav.ir(B + '/admin/painel.php');
  ok('abrir uma página do admin de verdade conta', (await tsAdmin()) > tsAntes);
} catch (e) {
  falhas++;
  console.log('  ERRO   ' + e.message);
} finally {
  voltarVersao();
  try { mexer(`DELETE FROM recebidas_es WHERE fornecedor = 'ZZREC SEMF5'`); } catch {}
  await nav.fechar();
}
console.log(`\n${falhas ? falhas + ' de ' + total + ' verificações falharam.' : 'Todas as ' + total + ' verificações passaram.'}`);
process.exit(falhas ? 1 : 0);
