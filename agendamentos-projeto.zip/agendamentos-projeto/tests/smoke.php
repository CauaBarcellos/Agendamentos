<?php
/**
 * Testes rápidos (sem dependências). Uso:  php tests/smoke.php
 * Só roda pela linha de comando. Não altera dados.
 */
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
$_SERVER['SCRIPT_NAME'] = 'tests/smoke.php';
$_SERVER['HTTP_HOST'] = 'localhost';
require dirname(__DIR__) . '/inc/bootstrap.php';
require dirname(__DIR__) . '/inc/backup.php';

$falhas = 0; $total = 0;
function ok(string $nome, bool $cond, string $detalhe = ''): void
{
    global $falhas, $total;
    $total++;
    if (!$cond) $falhas++;
    echo ($cond ? '  ok   ' : '  FALHA ') . $nome . ($cond || !$detalhe ? '' : "  → $detalhe") . "\n";
}

echo "Helpers\n";
ok('status_de: entregue', status_de(['entregue' => 'S', 'data_receber' => '2020-01-01']) === 'entregue');
ok('status_de: atrasado', status_de(['entregue' => 'N', 'data_receber' => '2000-01-01']) === 'atrasado');
ok('status_de: hoje', status_de(['entregue' => 'N', 'data_receber' => hoje()]) === 'hoje');
ok('status_de: sem data', status_de(['entregue' => 'N', 'data_receber' => null]) === 'semdata');
ok('titulo()', titulo('TELECARGA REGINA') === 'Telecarga Regina');
ok('soma_dias()', soma_dias('2026-10-22', 1) === '2026-10-23');
ok('volta_segura bloqueia URL externa', volta_segura('https://evil.com') === 'index.php' && volta_segura('//evil.com') === 'index.php');
ok('volta_segura aceita página interna', volta_segura('index.php?dia=2026-10-22') === 'index.php?dia=2026-10-22');

echo "Senhas\n";
ok('rejeita com menos de 6 caracteres', senha_invalida('abc12') !== null);
ok('rejeita só números', senha_invalida('123456') !== null);
ok('rejeita só letras', senha_invalida('abcdef') !== null);
ok('aceita 6 caracteres com letra e número', senha_invalida('abc123') === null && senha_invalida('1a2b3c') === null);
ok('aceita letra com acento', senha_invalida('çãé123') === null);

echo "Importação (NF-e / planilha)\n";
$fx = __DIR__ . '/fixtures/';
$r = nfe_ler_xml(file_get_contents($fx . 'nfe_teuto.xml'), 'teuto');
ok('XML NF-e: lê uma nota', count($r) === 1 && $r[0]['ok']);
$d = $r[0]['dados'] ?? [];
ok('XML: número sem zeros à esquerda', ($d['nota_fiscal'] ?? '') === '12345');
ok('XML: chave de 44 dígitos', strlen($d['chave_nfe'] ?? '') === 44);
ok('XML: soma os volumes (8+4)', ($d['volumes'] ?? '') === '12');
ok('XML: transportadora e emitente', ($d['transportadora'] ?? '') === 'TELECARGA TRANSPORTES LTDA' && ($d['emitente'] ?? '') === 'TEUTO BRASILEIRO S/A');
$padrao = ['empresa' => 'ESSENCIAL', 'uf' => 'RJ', 'data_receber' => '2026-10-23'];
$l = imp_linha_de_nfe($d, $padrao, ['TEUTO'], ['TELECARGA']);
ok('XML: reaproveita o nome já cadastrado do fornecedor', $l['fornecedor'] === 'TEUTO');
ok('XML: reaproveita o nome da transportadora', $l['transportadora'] === 'TELECARGA');
ok('XML: identifica a empresa pelo destinatário', $l['empresa'] === 'GREEN MED');
ok('XML: categoria do produto (medicamento)', $l['produto'] === 'MEDICAMENTO');
$l2 = imp_linha_de_nfe(nfe_ler_xml(file_get_contents($fx . 'nfe_estevia_es.xml'))[0]['dados'], $padrao, [], []);
ok('XML (ISO-8859-1): destino ES e empresa Estevia', $l2['uf'] === 'ES' && $l2['empresa'] === 'ESTEVIA');
ok('XML sem transportadora gera aviso', in_array('NF sem transportadora informada.', $l2['aviso'], true));
ok('XML de evento é recusado', !nfe_ler_xml(file_get_contents($fx . 'nfe_evento.xml'))[0]['ok']);
$x = nfe_ler_xml(file_get_contents($fx . 'nfe_xxe.xml'));
ok('XML com DOCTYPE/ENTITY (XXE) é recusado', !$x[0]['ok'] && str_contains($x[0]['erro'], 'DOCTYPE'));
ok('XML corrompido é recusado', !nfe_ler_xml(file_get_contents($fx . 'nfe_invalido.xml'))[0]['ok']);
ok('XML enorme é recusado', !nfe_ler_xml(str_repeat('<a/>', 1000000))[0]['ok']);
$t = imp_ler_tabela(file_get_contents($fx . 'lote.csv'));
ok('Planilha: ignora a linha em branco (4 linhas)', count($t) === 4);
$c = imp_linha_de_tabela($t[1], $padrao);
ok('Planilha: data "27/10" vira o ano atual', $c['data_receber'] === date('Y') . '-10-27');
ok('Planilha: "3 cx" vira 3 volumes', $c['volumes'] === '3');
$c4 = imp_linha_de_tabela($t[3], $padrao);
ok('Planilha: data inválida 31/02 usa a padrão e avisa', $c4['data_receber'] === '2026-10-23' && count($c4['aviso']) === 2);
ok('Planilha: separa por tabulação (colado do Excel)', count(imp_ler_tabela("Fornecedor\tNF\nTEUTO\t1\nMEDIX\t2")) === 2);
ok('Planilha sem coluna Fornecedor é rejeitada', imp_ler_tabela("Nome;NF\nA;1") === []);
ok('Datas: aceita 22/10/26 e 2026-10-22', imp_data('22/10/26') === '2026-10-22' && imp_data('2026-10-22') === '2026-10-22' && imp_data('99/99/2026') === null);
$gig = imp_linha_de_tabela(['fornecedor' => str_repeat('A', 5000), 'nota_fiscal' => str_repeat('9', 400), 'volumes' => '99999999999999'], $padrao);
ok('Planilha: campo gigante é cortado no tamanho da coluna', mb_strlen($gig['fornecedor']) <= 150 && mb_strlen($gig['nota_fiscal']) <= 60 && strlen($gig['volumes']) <= 8);
ok('imp_cortar respeita acentos (multibyte)', mb_strlen(imp_cortar(str_repeat('Ç', 300), 120)) === 120);

// ZIP: bomba (60 MB compactados em KB), nome com ../ e conteúdo normal
$tmp = sys_get_temp_dir();
$arq = fn($path, $nome) => ['name' => $nome, 'tmp_name' => $path, 'error' => UPLOAD_ERR_OK, 'size' => filesize($path)];
$zb = "$tmp/smoke_bomba.zip"; @unlink($zb);
$z = new ZipArchive(); $z->open($zb, ZipArchive::CREATE); $z->addFromString('g.xml', '<NFe>' . str_repeat(' ', 40 * 1024 * 1024) . '</NFe>'); $z->close();
[$lb, $pb] = imp_coletar([$arq($zb, 'bomba.zip')], '', $padrao);
ok('ZIP-bomba é recusado sem estourar a memória', !$lb && $pb && memory_get_peak_usage() < 200 * 1024 * 1024);
$zt = "$tmp/smoke_trav.zip"; @unlink($zt);
$z = new ZipArchive(); $z->open($zt, ZipArchive::CREATE); $z->addFromString('../../evil.xml', file_get_contents($fx . 'nfe_teuto.xml')); $z->addFromString('b.xml', file_get_contents($fx . 'nfe_estevia_es.xml')); $z->close();
[$lt] = imp_coletar([$arq($zt, 'trav.zip')], '', $padrao);
ok('ZIP com "../" no nome: lê o conteúdo e não grava nada em disco', count($lt) === 2 && !file_exists(dirname(sys_get_temp_dir(), 3) . '/evil.xml'));
@unlink($zb); @unlink($zt);
[$l500] = imp_coletar([], "Fornecedor;NF\n" . implode("\n", array_map(fn($i) => "F$i;$i", range(1, 650))), $padrao);
ok('Planilha: no máximo 500 notas por importação', count($l500) === 500);
ok('Tipo de arquivo não aceito gera aviso', imp_coletar([['name' => 'virus.exe', 'tmp_name' => $fx . 'lote.csv', 'error' => UPLOAD_ERR_OK, 'size' => 10]], '', $padrao)[1] !== []);
[$lx, $px] = imp_coletar([['name' => 'lote.xlsx', 'tmp_name' => $fx . 'lote.xlsx', 'error' => UPLOAD_ERR_OK, 'size' => filesize($fx . 'lote.xlsx')]], '', $padrao);
ok('Planilha .xlsx: lê 2 notas (texto compartilhado e inline)', count($lx) === 2 && !$px && $lx[0]['fornecedor'] === 'XLSXFORN' && $lx[1]['fornecedor'] === 'INLINEFORN');
ok('Planilha .xlsx: número vira texto limpo e data do Excel vira data', $lx[0]['nota_fiscal'] === '123456' && $lx[0]['volumes'] === '7' && $lx[0]['data_receber'] === '2026-10-22');
$fake = sys_get_temp_dir() . '/smoke_fake.xlsx'; file_put_contents($fake, 'isso não é um zip');
ok('Planilha .xlsx: arquivo inválido gera aviso, não erro', imp_coletar([['name' => 'x.xlsx', 'tmp_name' => $fake, 'error' => UPLOAD_ERR_OK, 'size' => 17]], '', $padrao)[1] !== []);
@unlink($fake);
ok('Recebido: data de ontem vira data', (imp_recebido(date('d/m/Y', strtotime('-1 day')))['data'] ?? '') === date('Y-m-d', strtotime('-1 day')));
ok('Recebido: "sim", "x", "Recebido" contam como recebido', imp_recebido('sim') !== null && imp_recebido('X') !== null && imp_recebido('Recebido') !== null);
ok('Recebido: vazio, "não" e "pendente" não contam', imp_recebido('') === null && imp_recebido('Não') === null && imp_recebido('pendente') === null);
ok('Recebido: data no futuro é ignorada com aviso', imp_recebido(date('d/m/Y', strtotime('+3 day')), $av) === null && $av !== null);
ok('Recebido: valor estranho é ignorado com aviso', imp_recebido('talvez', $av2) === null && $av2 !== null);
$lr = imp_ler_tabela("Fornecedor;NF;Recebido\nTEUTO;1;sim");
ok('Planilha: coluna "Recebido" é reconhecida', ($lr[0]['recebido'] ?? null) === 'sim', json_encode($lr));
echo "Banco\n";
foreach (['usuarios', 'agendamentos', 'historico', 'login_falhas'] as $t) {
    ok("tabela $t existe", (bool)db()->query("SHOW TABLES LIKE '$t'")->fetch());
}
ok('coluna usuarios.trocar_senha', (bool)db()->query("SHOW COLUMNS FROM usuarios LIKE 'trocar_senha'")->fetch());
$chaveT = '99999999999999999999999999999999999999999999';
q('INSERT INTO agendamentos (empresa, fornecedor, nota_fiscal, chave_nfe, origem, entregue) VALUES ("GREEN MED", "ZZSMOKE", "424242", ?, "xml", "N")', [$chaveT]);
$idT = (int)db()->lastInsertId();
ok('Duplicada: reconhece pela chave da NF-e', (imp_duplicada($chaveT, 'OUTRO NOME', '1')['id'] ?? 0) === $idT);
ok('Duplicada: reconhece por fornecedor + número', (imp_duplicada('', 'ZZSMOKE', '424242')['id'] ?? 0) === $idT);
ok('Duplicada: nota diferente não é duplicada', imp_duplicada('', 'ZZSMOKE', '424243') === null);
q('DELETE FROM agendamentos WHERE id = ?', [$idT]);
ok('coluna agendamentos.chave_nfe existe', (bool)db()->query("SHOW COLUMNS FROM agendamentos LIKE 'chave_nfe'")->fetch());
ok('existe administrador ativo', (int)q("SELECT COUNT(*) FROM usuarios WHERE perfil='admin' AND ativo=1")->fetchColumn() > 0);
$h = fopen('php://memory', 'w+');
$bytes = backup_sql($h);
rewind($h);
$dump = stream_get_contents($h);
ok('backup gera SQL com as tabelas', $bytes > 0 && str_contains($dump, 'CREATE TABLE `agendamentos`') && str_contains($dump, 'CREATE TABLE `usuarios`'));

echo "Recebimento\n";
$monta = function (string $base): string {
    $soma = 0; $peso = 2;
    for ($i = 42; $i >= 0; $i--) { $soma += (int)$base[$i] * $peso; $peso = $peso === 9 ? 2 : $peso + 1; }
    $dv = 11 - ($soma % 11);
    return $base . ($dv >= 10 ? 0 : $dv);
};
$ch = $monta('3326101234567800019955001000424242112345678');
ok('chave_valida aceita chave correta', chave_valida($ch));
ok('chave_valida recusa dígito errado', !chave_valida(substr($ch, 0, 43) . (((int)$ch[43] + 1) % 10)));
ok('chave_valida recusa tamanho errado', !chave_valida('123') && !chave_valida($ch . '1'));
ok('status_de: recebida com divergência', status_de(['entregue' => 'S', 'divergencia' => 'falta', 'data_receber' => '2020-01-01']) === 'divergencia');
ok('divergencia_txt', divergencia_txt('falta,avaria') === 'Falta de volume, Avaria');

$_SESSION['u'] = ['id' => null];
q('INSERT INTO agendamentos (empresa, fornecedor, nota_fiscal, volumes, volumes_num, data_receber, entregue, origem) VALUES ("GREEN MED", "ZZSMOKE REC", "3697 / 0424242 / 3699", "5", 5, ?, "N", "portal")', [hoje()]);
$idR = (int)db()->lastInsertId();
$b = entrada_buscar('424242');
ok('busca pela NF acha número no meio de uma lista ("3697 / 0424242")', in_array($idR, array_map('intval', array_column($b['itens'], 'id')), true));
ok('busca pela NF não confunde com número maior (4242)', !in_array($idR, array_map('intval', array_column(entrada_buscar('4242')['itens'], 'id')), true));
$b = entrada_buscar($ch);
ok('chave sem cadastro acha pelo número da NF', in_array($idR, array_map('intval', array_column($b['itens'], 'id')), true) && !isset($b['id']));
q('UPDATE agendamentos SET chave_nfe = ? WHERE id = ?', [$ch, $idR]);
ok('chave cadastrada: vai direto para a nota', (entrada_buscar($ch)['id'] ?? 0) === $idR);
$r = q('SELECT * FROM agendamentos WHERE id = ?', [$idR])->fetch();
ok('entrada registrada', receber_registrar($r, 4, 'falta', 'faltou 1'));
ok('a segunda entrada da mesma nota é recusada', !receber_registrar($r, 5, null, null));
ok('gravou volumes e divergência da primeira', q('SELECT CONCAT(vol_recebidos, divergencia) FROM agendamentos WHERE id = ?', [$idR])->fetchColumn() === '4falta');
q('DELETE FROM historico WHERE agendamento_id = ?', [$idR]);
q('DELETE FROM agendamentos WHERE id = ?', [$idR]);
unset($_SESSION['u']);
ok('tabela fotos existe', (bool)db()->query("SHOW TABLES LIKE 'fotos'")->fetch());
ok('pasta uploads protegida (.htaccess)', is_file(uploads_dir() . '/.htaccess') && str_contains(file_get_contents(uploads_dir() . '/.htaccess'), 'denied'));
echo "Segurança\n";
foreach (['config.php', 'config.producao.php', 'inc/db.php', 'dados/planilha.json', 'sql/schema.sql', 'backups/'] as $arq) {
    $base = 'http://localhost/' . basename(dirname(__DIR__)) . '/' . $arq;
    $ctx = stream_context_create(['http' => ['ignore_errors' => true, 'timeout' => 5]]);
    $r = @file_get_contents($base, false, $ctx);
    $codigo = isset($http_response_header[0]) && preg_match('/ (\d{3}) /', $http_response_header[0], $m) ? (int)$m[1] : 0;
    ok("$arq bloqueado (HTTP $codigo)", $codigo === 403 || $codigo === 404 || $codigo === 0);
}

echo "\n" . ($falhas ? "$falhas de $total testes falharam.\n" : "Todos os $total testes passaram.\n");
exit($falhas ? 1 : 0);
