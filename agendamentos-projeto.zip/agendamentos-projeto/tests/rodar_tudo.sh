#!/bin/sh
# Roda todos os testes: unitários/integração (smoke) e os dois testes no navegador.
# Uso: sh tests/rodar_tudo.sh   (precisa de Apache+MySQL do XAMPP rodando e do Chrome/Edge)
cd "$(dirname "$0")/.." || exit 1
PHP=${PHP:-C:/xampp2/php/php.exe}
falhou=0
"$PHP" tests/smoke.php || falhou=1
cd tests/browser || exit 1
for t in live importar sqli es receber camera topo calendario semf5 avisos; do
  "$PHP" preparar.php && node $t.mjs || falhou=1
  "$PHP" limpar.php
done
[ $falhou = 0 ] && echo "TUDO OK" || { echo "HÁ FALHAS"; exit 1; }
