<?php
// Consulta leve feita pelas páginas abertas (a cada poucos segundos): devolve só as "impressões digitais" dos dados
// (fp: agenda da empresa escolhida; tudo: o que as outras páginas mostram) e a versão dos arquivos do site.
require __DIR__ . '/inc/bootstrap.php';
require __DIR__ . '/inc/admin_auth.php';
header('Content-Type: application/json; charset=utf-8');
$u = usuario();
$adm = adm_usuario(); // o admin tem login próprio; não renova o tempo de inatividade dele
if (!$u && !($adm && time() - ($adm['ts'] ?? 0) < ADM_OCIOSO)) { http_response_code(401); echo json_encode(['ok' => false, 'msg' => 'sessao']); exit; }
$id = (int)($u['id'] ?? $adm['id']);
$emp = $EMP;
session_write_close(); // não trava as outras abas enquanto consulta o banco
$autor = agenda_ultimo_autor($emp);
echo json_encode(['ok' => true, 'fp' => agenda_fp($emp), 'tudo' => site_fp(), 'v' => site_versao(), 'eu' => $id, 'autor_id' => (int)$autor['id'], 'autor' => $autor['nome']], JSON_UNESCAPED_UNICODE);
