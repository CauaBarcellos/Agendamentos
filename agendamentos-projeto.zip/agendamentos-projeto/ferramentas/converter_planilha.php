<?php
/**
 * Converte a planilha "AGENDAMENTOS FORNECEDOR" (.xlsx) para o mesmo formato de dados/planilha.json da carga inicial:
 *   agendamentos: [linha, data_agend, empresa, uf, transportadora, fornecedor, filial, produto, categoria, nf, volumes, volumes_num, data_receber, ref, entregue, observacao, email, vianna]
 *   recebidas:    [linha, data_emissao, transportadora, fornecedor, material, nf, volumes, status, data_recebido_rj, observacao]
 * Lê em fluxo (a aba tem 1 milhão de linhas vazias formatadas).
 * Uso: php converter_planilha.php <arquivo.xlsx> <saida.json> [--valores]   (--valores: só mostra os valores distintos de algumas colunas)
 * O planilha.json gerado é o que se envia em Admin > Planilha (ou se coloca em dados/ antes do install.php).
 */
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require dirname(__DIR__) . '/inc/helpers.php';
[$_, $arq, $saida] = $argv + [null, null, null];
if (!$arq || !is_file($arq)) die("Uso: php converter_planilha.php <arquivo.xlsx> <saida.json>\n");
$soValores = in_array('--valores', $argv, true);

$z = new ZipArchive;
if ($z->open($arq) !== true) die("não abriu\n");
$ss = [];
$x = new XMLReader();
$x->XML($z->getFromName('xl/sharedStrings.xml'));
while ($x->read() && !($x->nodeType === XMLReader::ELEMENT && $x->localName === 'si')) {}
while ($x->nodeType === XMLReader::ELEMENT && $x->localName === 'si') {
    $si = new SimpleXMLElement($x->readOuterXML());
    $t = '';
    foreach ($si->xpath('.//*[local-name()="t"][not(ancestor::*[local-name()="rPh"])]') as $tt) $t .= (string)$tt;
    $ss[] = $t;
    if (!$x->next('si')) break;
}
// qual sheetN é cada aba
$w = $z->getFromName('xl/workbook.xml');
$rels = $z->getFromName('xl/_rels/workbook.xml.rels');
$z->close();
preg_match_all('#<sheet [^>]*name="([^"]+)"[^>]*r:id="([^"]+)"#', $w, $m, PREG_SET_ORDER);
$abas = [];
foreach ($m as $s) {
    preg_match('#Id="' . $s[2] . '"[^>]*Target="([^"]+)"|Target="([^"]+)"[^>]*Id="' . $s[2] . '"#', $rels, $t);
    $abas[html_entity_decode($s[1])] = 'xl/' . ($t[1] ?: $t[2]);
}

function linhas(string $arq, string $parte, array $ss): Generator
{
    $r = new XMLReader();
    $r->open('zip://' . $arq . '#' . $parte);
    $col = fn($ref) => array_reduce(str_split(preg_replace('/\d/', '', $ref)), fn($a, $c) => $a * 26 + ord($c) - 64, 0);
    while ($r->read()) {
        if ($r->nodeType !== XMLReader::ELEMENT || $r->localName !== 'row') continue;
        $row = new SimpleXMLElement($r->readOuterXML());
        $cel = [];
        foreach ($row->c as $c) {
            $v = isset($c->v) ? (string)$c->v : (isset($c->is) ? (string)$c->is->t : '');
            if ((string)$c['t'] === 's') $v = $ss[(int)$v] ?? '';
            $v = trim($v);
            if ($v !== '') $cel[$col((string)$c['r'])] = $v;
        }
        if ($cel) yield (int)$row['r'] => $cel;
    }
}
// número de série do Excel → Y-m-d; também aceita "21.05.2025", "21/05/2025"
function data_xl(?string $v): ?string
{
    $v = trim((string)$v);
    if ($v === '') return null;
    if (is_numeric($v) && (float)$v > 20000 && (float)$v < 80000) return date('Y-m-d', (int)round(((float)$v - 25569) * 86400));
    if (preg_match('#^(\d{1,2})[./-](\d{1,2})[./-](\d{2,4})$#', $v, $m)) { $a = (int)$m[3] < 100 ? 2000 + (int)$m[3] : (int)$m[3]; return checkdate((int)$m[2], (int)$m[1], $a) ? sprintf('%04d-%02d-%02d', $a, $m[2], $m[1]) : null; }
    return null;
}
$num = fn($v) => is_numeric($v) && (float)$v == floor((float)$v) ? (string)(int)$v : (string)$v;

$ag = [];
$val = ['empresa' => [], 'uf' => [], 'entregue' => [], 'email' => []];
foreach (linhas($arq, $abas['AGENDAMENTO'], $ss) as $n => $c) {
    if ($n === 1) continue; // cabeçalho
    if (($c[5] ?? '') === '' && ($c[8] ?? '') === '' && ($c[4] ?? '') === '') continue; // linha sem fornecedor, NF e transportadora
    $emp = mb_strtoupper(trim($c[2] ?? ''));
    // nome da empresa como no portal; com erro de digitação, descobre pela filial (19 Green Med, 16 Estevia, 15 Essencial)
    $porFilial = ['19' => 'GREEN MED', '16' => 'ESTEVIA', '15' => 'ESSENCIAL'];
    $emp = match (true) { $emp === 'GREEN' || $emp === 'GREEN MED' => 'GREEN MED', in_array($emp, ['ESTEVIA', 'ESSENCIAL', 'RAL'], true) => $emp, default => $porFilial[isset($c[6]) ? (string)(int)$c[6] : ''] ?? '' };
    $uf = mb_strtoupper(trim($c[3] ?? ''));
    $ent = mb_strtoupper(trim($c[13] ?? ''));
    foreach (['empresa' => $emp, 'uf' => $uf, 'entregue' => $ent, 'email' => mb_strtoupper($c[15] ?? '')] as $k => $vv) $val[$k][$vv] = ($val[$k][$vv] ?? 0) + 1;
    $vol = isset($c[10]) ? $num($c[10]) : '';
    $prod = $c[7] ?? '';
    $ag[] = [
        $n, data_xl($c[1] ?? ''), $emp, $uf === 'ES' ? 'ES' : 'RJ', $c[4] ?? '', $c[5] ?? '', (preg_match('/^\s*(\d+)/', (string)($c[6] ?? ''), $fm) ? $fm[1] : ''), $prod,
        categoria_de($prod), isset($c[8]) ? $num($c[8]) : '', $vol, preg_match('/^(\d+)/', $vol, $mm) ? (int)$mm[1] : null,
        data_xl($c[11] ?? ''), $c[12] ?? '', in_array($ent, ['SIM', 'S', 'OK', 'ENTREGUE', 'RECEBIDO', 'RECEBIDA'], true) ? 'S' : (str_starts_with($ent, 'DEVOLV') ? 'D' : 'N'),
        $c[14] ?? '', $c[15] ?? '', $c[16] ?? '',
    ];
}
if ($soValores) { foreach ($val as $k => $v) { arsort($v); echo "$k: " . json_encode(array_slice($v, 0, 15, true), JSON_UNESCAPED_UNICODE) . "\n"; } }

$rec = [];
foreach (linhas($arq, $abas['RECEBIDAS'], $ss) as $n => $c) {
    if ($n === 1) { if ($soValores) echo 'RECEBIDAS cabeçalho: ' . json_encode($c, JSON_UNESCAPED_UNICODE) . "\n"; continue; }
    if (($c[3] ?? '') === '' && ($c[5] ?? '') === '') continue;
    $rec[] = [$n, data_xl($c[1] ?? ''), $c[2] ?? '', $c[3] ?? '', $c[4] ?? '', isset($c[5]) ? $num($c[5]) : '', isset($c[6]) ? $num($c[6]) : '', $c[7] ?? '', data_xl($c[8] ?? ''), $c[9] ?? ''];
}
if ($saida) file_put_contents($saida, json_encode(['agendamentos' => $ag, 'recebidas' => $rec], JSON_UNESCAPED_UNICODE));
echo count($ag) . " agendamentos, " . count($rec) . " recebidas\n";
