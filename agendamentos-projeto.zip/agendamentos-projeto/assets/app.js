// Linhas clicáveis (agenda e tabela) sem atrapalhar botões e links internos.
document.addEventListener('click', function (e) {
  if (e.target.closest('a,button,input,select,textarea,label,form,summary')) return;
  var row = e.target.closest('[data-href]');
  if (row) window.location.href = row.getAttribute('data-href');
});
document.addEventListener('keydown', function (e) {
  var row = e.target.closest && e.target.closest('[data-href]');
  if (row && e.target === row && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); window.location.href = row.getAttribute('data-href'); }
});
// Evita clique duplo nos botões de envio (e pede confirmação quando o formulário tem data-confirma).
document.addEventListener('submit', function (e) {
  var conf = e.target.getAttribute('data-confirma');
  if (conf && !e.target.classList.contains('ajax') && !window.confirm(conf)) { e.preventDefault(); return; }
  var b = e.target.querySelector('button[type="submit"],button:not([type])');
  if (b) setTimeout(function () { b.disabled = true; }, 0);
});
// Fecha o menu do usuário ao clicar fora.
document.addEventListener('click', function (e) {
  document.querySelectorAll('details.user[open],details.del[open]').forEach(function (d) { if (!d.contains(e.target)) d.removeAttribute('open'); });
});
// No celular, ao escolher um dia, rola até a lista.
if (window.innerWidth <= 860 && location.search.indexOf('dia=') > -1) {
  var p = document.getElementById('painel'); if (p) p.scrollIntoView({ block: 'start' });
}
// "Voltar" sem javascript: (a política de segurança do site bloqueia esse tipo de link).
document.addEventListener('click', function (e) {
  var a = e.target.closest('a[data-voltar]');
  if (a && history.length > 1) { e.preventDefault(); history.back(); }
});

// ---------- Site sempre atual, sem F5 ----------
// Versão nova do site (subiram arquivos novos): a página se recarrega sozinha assim que ninguém estiver mexendo nela.
// Registros, Filial ES, Recebidas ES e o admin: quando os dados mudam, troca só as partes marcadas com data-vivo,
// sem mexer no que a pessoa está digitando. A agenda e o calendário têm a atualização própria (mais abaixo).
var siteAoVivo = (function () {
  var body = document.body, versao = body.getAttribute('data-versao');
  if (!versao) return { versao: function () {} };

  function aviso(msg) {
    var box = document.getElementById('toast');
    if (!box) { box = document.createElement('div'); box.id = 'toast'; box.setAttribute('role', 'status'); document.body.appendChild(box); }
    box.innerHTML = '';
    var t = document.createElement('span'); t.textContent = msg; box.appendChild(t);
    box.classList.add('on');
    clearTimeout(box._t);
    box._t = setTimeout(function () { box.classList.remove('on'); }, 4500);
  }
  try { if (sessionStorage.getItem('site-atualizado')) { sessionStorage.removeItem('site-atualizado'); aviso('O site foi atualizado para a versão nova.'); } } catch (e) {}

  // Formulário de envio (POST) com algo digitado: não recarrega por cima, espera a pessoa salvar ou sair da página.
  var digitou = false;
  function marcar(e) { var f = e.target.closest && e.target.closest('form'); if (f && (f.getAttribute('method') || '').toLowerCase() === 'post') digitou = true; }
  document.addEventListener('input', marcar, true);
  document.addEventListener('change', marcar, true);
  function digitando(raiz) {
    var a = document.activeElement;
    return !!(a && raiz.contains(a) && /^(INPUT|SELECT|TEXTAREA)$/.test(a.tagName));
  }
  function podeRecarregar() {
    if (digitou || digitando(document) || document.querySelector('dialog[open], .cal-mover[open], .arrastando, #toast.on button')) return false;
    return ![].some.call(document.querySelectorAll('video'), function (v) { return !v.paused; }); // câmera lendo código
  }
  var nova = false;
  function tentar() {
    if (!nova || !podeRecarregar()) return;
    try { sessionStorage.setItem('site-atualizado', '1'); } catch (e) {}
    location.reload();
  }
  function versaoDoServidor(v) { if (v && v !== versao) { nova = true; tentar(); } }

  var api = { versao: versaoDoServidor };
  window.__site = api; // gancho para os testes no navegador
  if (document.getElementById('painel') || document.getElementById('cal')) return api;

  var regioes = [].slice.call(document.querySelectorAll('[data-vivo][id]'));
  var fp = body.getAttribute('data-fp-site'), estado = body.getAttribute('data-estado') || 'estado.php';
  var INTERVALO = (parseInt(body.getAttribute('data-intervalo'), 10) || 8) * 1000;
  if (INTERVALO < 3000 || INTERVALO > 300000) INTERVALO = 8000;
  var timer = null, falhas = 0, parado = false;

  // Busca a página de novo e troca as partes marcadas. A parte onde a pessoa está digitando ou com algo aberto fica para a próxima vez.
  function trocar() {
    return fetch(location.href, { credentials: 'same-origin', cache: 'no-store', headers: { 'X-Vivo': '1' } })
      .then(function (r) { return r.text(); })
      .then(function (html) {
        var doc = new DOMParser().parseFromString(html, 'text/html'), novoFp = doc.body && doc.body.getAttribute('data-fp-site');
        if (!novoFp) { parado = true; return; } // voltou a tela de login: a sessão acabou
        var y = window.scrollY, todas = true;
        regioes.forEach(function (el) {
          var n = doc.getElementById(el.id);
          if (!n) return;
          if (digitando(el) || el.querySelector('details[open], dialog[open]')) { todas = false; return; }
          if (el.innerHTML !== n.innerHTML) el.innerHTML = n.innerHTML;
        });
        if (todas) fp = novoFp;
        window.scrollTo(0, y);
      });
  }
  function checar() {
    if (parado) return Promise.resolve();
    if (document.hidden) { agendar(); return Promise.resolve(); }
    return fetch(estado, { credentials: 'same-origin', cache: 'no-store' })
      .then(function (r) { if (r.status === 401) { parado = true; return null; } return r.json(); })
      .then(function (j) {
        if (!j || !j.ok) return;
        falhas = 0;
        versaoDoServidor(j.v);
        if (regioes.length && j.tudo !== fp) return trocar(); // mesmo esperando para recarregar, os dados continuam em dia
      })
      .catch(function () { falhas++; })
      .then(agendar);
  }
  function agendar() {
    clearTimeout(timer);
    if (parado) return;
    timer = setTimeout(checar, INTERVALO * Math.pow(2, Math.min(falhas, 3)) + Math.random() * 1500);
  }
  document.addEventListener('visibilitychange', function () { if (!document.hidden && !parado) { clearTimeout(timer); checar(); } });
  window.addEventListener('online', function () { falhas = 0; clearTimeout(timer); checar(); });
  document.addEventListener('focusout', function () { setTimeout(tentar, 300); });
  agendar();
  api.checar = checar;
  return api;
})();

// ---------- Agenda: filtro, grupos, baixa sem recarregar (com "Desfazer") e atualização ao vivo ----------
(function () {
  var painel = document.getElementById('painel');
  if (!painel) return;

  var ocupado = 0;          // pedidos da própria pessoa em andamento (não atualiza por cima)
  var INTERVALO = 8000;     // consulta de mudanças a cada 8 s (aba visível); config 'agenda_intervalo' ajusta
  (function () { var p = document.getElementById('painel'), s = p && parseInt(p.getAttribute('data-intervalo'), 10); if (s >= 3 && s <= 300) INTERVALO = s * 1000; })();

  function plural(n, um, varios) { return n.toLocaleString('pt-BR') + ' ' + (n === 1 ? um : varios); }
  function grupos() { return [].slice.call(painel.querySelectorAll('.grp')); }

  function toast(msg, acao) {
    var box = document.getElementById('toast');
    if (!box) { box = document.createElement('div'); box.id = 'toast'; box.setAttribute('role', 'status'); document.body.appendChild(box); }
    box.innerHTML = '';
    var t = document.createElement('span'); t.textContent = msg; box.appendChild(t);
    if (acao) {
      var b = document.createElement('button'); b.type = 'button'; b.textContent = acao.rotulo;
      b.addEventListener('click', function () { box.classList.remove('on'); acao.fazer(); });
      box.appendChild(b);
    }
    box.classList.add('on');
    clearTimeout(box._t);
    box._t = setTimeout(function () { box.classList.remove('on'); }, acao ? 9000 : 4500);
  }

  // ----- filtro do dia e recolher/expandir grupos -----
  function rotulo() {
    var all = document.getElementById('alterna-grupos');
    if (!all) return;
    var algumAberto = grupos().some(function (g) { return !g.classList.contains('shut') && g.style.display !== 'none'; });
    all.textContent = algumAberto ? 'Recolher tudo' : 'Expandir tudo';
  }
  function aplicarFiltro() {
    var box = document.getElementById('filtro-agenda');
    var t = box ? box.value.trim().toLowerCase() : '';
    grupos().forEach(function (g) {
      var vis = 0;
      [].forEach.call(g.querySelectorAll('.row'), function (r) {
        var ok = !t || (r.getAttribute('data-busca') || '').indexOf(t) > -1;
        r.style.display = ok ? '' : 'none'; if (ok) vis++;
      });
      g.style.display = vis ? '' : 'none';
    });
    rotulo();
  }
  document.addEventListener('input', function (e) { if (e.target && e.target.id === 'filtro-agenda') aplicarFiltro(); });
  document.addEventListener('click', function (e) {
    var tog = e.target.closest && e.target.closest('.gh .tog');
    if (tog) {
      var g = tog.closest('.grp'); g.classList.toggle('shut');
      tog.setAttribute('aria-expanded', g.classList.contains('shut') ? 'false' : 'true'); rotulo(); return;
    }
    if (e.target.id === 'alterna-grupos') {
      var fechar = e.target.textContent === 'Recolher tudo';
      grupos().forEach(function (gr) {
        gr.classList.toggle('shut', fechar);
        var tg = gr.querySelector('.tog'); if (tg) tg.setAttribute('aria-expanded', fechar ? 'false' : 'true');
      });
      rotulo(); return;
    }
    if (e.target.id === 'imprimir-dia') window.print();
  });

  // ----- recalcula contadores depois de uma baixa feita aqui -----
  function recalcular() {
    var notas = 0, vols = 0, gr = 0;
    grupos().forEach(function (g) {
      var rows = g.querySelectorAll('.row'), v = 0;
      [].forEach.call(rows, function (r) { v += parseInt(r.getAttribute('data-vol') || '0', 10); });
      if (!rows.length) { g.remove(); return; }
      gr++; notas += rows.length; vols += v;
      var m = g.querySelector('.tmeta'); if (m) m.textContent = plural(rows.length, 'nota', 'notas') + (v ? ' · ' + v.toLocaleString('pt-BR') + ' vol' : '');
      var all = g.querySelector('.gh-all'); if (all && rows.length < 2) all.remove();
    });
    var meta = document.getElementById('meta-painel');
    if (meta) meta.innerHTML = notas ? '<span><b>' + plural(notas, 'nota', 'notas') + '</b></span>' + (vols ? '<span><b>' + vols.toLocaleString('pt-BR') + '</b> volumes</span>' : '') + '<span><b>' + gr + '</b> ' + (gr === 1 ? 'transportadora' : 'transportadoras') + '</span>' : '';
    var ct = document.querySelector('.day[aria-current="true"] .ct');
    if (ct && ct.firstChild) ct.firstChild.nodeValue = notas.toLocaleString('pt-BR');
    if (!notas && !painel.querySelector('.empty')) {
      var tools = painel.querySelector('.tools'), ch = painel.querySelector('.colhead');
      if (tools) tools.remove(); if (ch) ch.remove();
      var d = document.createElement('div'); d.className = 'empty'; d.innerHTML = '<b>Tudo recebido neste dia</b>Escolha outro dia na lista.'; painel.appendChild(d);
    }
  }

  // ----- baixa / receber todas / desfazer (formulários com class="ajax") -----
  function enviar(form) {
    return fetch(form.action, { method: 'POST', body: new FormData(form), credentials: 'same-origin', headers: { 'X-Requested-With': 'fetch' } })
      .then(function (r) { return r.json().catch(function () { return { ok: false, msg: 'Resposta inesperada do servidor.' }; }); });
  }

  // Remove as linhas da tela e mostra o aviso com "Desfazer".
  function concluir(r, csrf) {
    (r.ids || []).forEach(function (id) {
      var row = painel.querySelector('.row[data-id="' + id + '"]');
      if (row) row.remove();
    });
    recalcular();
    var ids = r.ids || [];
    toast(r.msg, { rotulo: 'Desfazer', fazer: function () {
      var fd = new FormData(); fd.set('csrf', csrf); fd.set('acao', 'desfazer');
      ids.forEach(function (i) { fd.append('ids[]', i); });
      fetch('acao.php', { method: 'POST', body: fd, credentials: 'same-origin', headers: { 'X-Requested-With': 'fetch' } })
        .then(function () { location.reload(); });
    } });
  }

  // Janela de conferência por cima da agenda. O ✓ abre a de uma nota; "Receber todas", a do grupo.
  // url = formulário (HTML); iniciar = prepara o formulário; reserva = página para abrir se a janela não funcionar.
  function abrirJanela(url, btn, iniciar, reserva) {
    if (btn) btn.disabled = true;
    fetch(url, { credentials: 'same-origin', headers: { 'X-Requested-With': 'fetch' } })
      .then(function (r) {
        return r.ok ? r.text().then(function (html) { return { html: html }; })
          : r.json().then(function (j) { return { erro: j.msg }; }).catch(function () { return { erro: 'Não foi possível abrir a conferência.' }; });
      })
      .then(function (res) {
        if (btn) btn.disabled = false;
        if (res.erro) { toast(res.erro); return; }
        var dlg = document.createElement('dialog');
        dlg.className = 'rec-modal';
        dlg.innerHTML = res.html;
        document.body.appendChild(dlg);
        var f = dlg.querySelector('form');
        if (!f || !window.HTMLDialogElement) { dlg.remove(); if (reserva) location.href = reserva; return; }
        iniciar(f);
        dlg.addEventListener('close', function () { dlg.remove(); if (btn) btn.focus(); });
        dlg.addEventListener('click', function (e) { if (e.target === dlg) dlg.close(); }); // clique fora fecha
        [].forEach.call(f.querySelectorAll('[data-fechar]'), function (b) { b.addEventListener('click', function () { dlg.close(); }); });
        f.addEventListener('submit', function (e) {
          e.preventDefault();
          var enviar = f.querySelector('button[type="submit"]'), caixa = f.querySelector('#rec-erros');
          enviar.disabled = true;
          ocupado++;
          [].forEach.call(f.querySelectorAll('.rg-item'), function (it) { it.classList.remove('com-erro'); it.querySelector('.rg-erro').hidden = true; });
          fetch(f.action, { method: 'POST', body: new FormData(f), credentials: 'same-origin', headers: { 'X-Requested-With': 'fetch' } })
            .then(function (r) { return r.json(); })
            .then(function (r) {
              if (!r.ok) {
                // no grupo, o erro aparece na própria nota
                var primeira = null;
                Object.keys(r.erros_itens || {}).forEach(function (id) {
                  var it = f.querySelector('.rg-item[data-id="' + id + '"]');
                  if (!it) return;
                  it.classList.add('com-erro');
                  var box = it.querySelector('.rg-erro'); box.textContent = r.erros_itens[id]; box.hidden = false;
                  primeira = primeira || it;
                });
                caixa.textContent = (r.erros || [r.msg || 'Não foi possível salvar.']).join(' ');
                caixa.hidden = false;
                (primeira || caixa).scrollIntoView({ block: 'nearest' });
                enviar.disabled = false;
                return;
              }
              dlg.close();
              concluir(r, f.querySelector('input[name="csrf"]').value);
            })
            .catch(function () { enviar.disabled = false; caixa.textContent = 'Sem conexão. Tente de novo.'; caixa.hidden = false; })
            .then(function () { ocupado--; });
        });
        dlg.showModal();
        var foco = f.querySelector('input[name="tudo_ok"][value="sim"]') || f.querySelector('button[type="submit"]');
        if (foco) foco.focus();
      })
      .catch(function () { if (btn) btn.disabled = false; if (reserva) location.href = reserva; else toast('Sem conexão. Tente de novo.'); });
  }
  document.addEventListener('submit', function (e) {
    var form = e.target, acao = form.querySelector && form.querySelector('input[name="acao"]');
    if (!acao || !form.classList.contains('ajax') || (acao.value !== 'entregue' && acao.value !== 'entregue_grupo')) return;
    e.preventDefault(); e.stopImmediatePropagation();
    var btn = form.querySelector('button');
    if (acao.value === 'entregue') {
      var id = form.querySelector('input[name="id"]').value, volta = location.pathname.split('/').pop() + location.search;
      var pagina = 'receber.php?id=' + encodeURIComponent(id) + '&volta=' + encodeURIComponent(volta);
      abrirJanela(pagina + '&modal=1', btn, iniciarConferencia, pagina);
    } else {
      var q = [].map.call(form.querySelectorAll('input[name="ids[]"]'), function (i) { return 'ids[]=' + encodeURIComponent(i.value); }).join('&');
      abrirJanela('receber_grupo.php?' + q, btn, iniciarGrupo, null);
    }
  }, true);

  document.addEventListener('submit', function (e) {
    var form = e.target;
    if (!form.classList || !form.classList.contains('ajax')) return;
    e.preventDefault(); e.stopPropagation();
    var conf = form.getAttribute('data-confirma');
    if (conf && !window.confirm(conf)) return;
    var btn = form.querySelector('button'); if (btn) btn.disabled = true;
    ocupado++;
    enviar(form).then(function (r) {
      if (!r.ok) { if (btn) btn.disabled = false; toast(r.msg || 'Não foi possível salvar.'); return; }
      concluir(r, form.querySelector('input[name="csrf"]').value);
    }).catch(function () { if (btn) btn.disabled = false; toast('Sem conexão. Tente de novo.'); })
      .then(function () { ocupado--; });
  }, true);

  // ----- atualização ao vivo -----
  var timer = null, falhas = 0, parado = false, atualizando = false, aviso = null;

  // Selo discreto que só aparece quando a agenda deixa de acompanhar o servidor.
  function selo(offline) {
    if (offline && !aviso) {
      aviso = document.createElement('div');
      aviso.className = 'offline';
      aviso.setAttribute('role', 'status');
      aviso.textContent = 'Sem conexão. A agenda pode estar desatualizada; tentando de novo…';
      document.body.appendChild(aviso);
    } else if (!offline && aviso) { aviso.remove(); aviso = null; }
  }

  function ids(raiz) {
    return [].map.call(raiz.querySelectorAll('.row[data-id]'), function (r) { return r.getAttribute('data-id'); }).sort().join(',');
  }
  function trocarFilhos(destino, origem) { if (destino && origem) destino.innerHTML = origem.innerHTML; }

  function atualizar(info) {
    if (atualizando || ocupado > 0) return Promise.resolve(false);
    atualizando = true;
    // Pede sempre o mesmo dia que está aberto (sem ?dia o servidor escolheria outro quando este esvazia).
    var url = new URL(location.href);
    if (!url.searchParams.get('dia')) url.searchParams.set('dia', painel.getAttribute('data-dia'));
    return fetch(url.toString(), { credentials: 'same-origin', cache: 'no-store', headers: { 'X-Requested-With': 'fetch' } })
      .then(function (r) { return r.text(); })
      .then(function (html) {
        if (ocupado > 0) return false; // a pessoa fez algo enquanto buscávamos; tenta no próximo ciclo
        var doc = new DOMParser().parseFromString(html, 'text/html');
        var novo = doc.getElementById('painel');
        if (!novo) { parado = true; toast('Sua sessão expirou. Recarregue a página para entrar de novo.'); return false; }

        var antes = ids(painel);
        var filtro = (document.getElementById('filtro-agenda') || {}).value || '';
        var fechados = grupos().filter(function (g) { return g.classList.contains('shut'); })
          .map(function (g) { var n = g.querySelector('.tname'); return n ? n.textContent : ''; });
        var y = window.scrollY;

        trocarFilhos(document.querySelector('.rail'), doc.querySelector('.rail'));
        trocarFilhos(document.querySelector('section.summary'), doc.querySelector('section.summary'));

        if (novo.getAttribute('data-dia') !== painel.getAttribute('data-dia')) {
          // O dia que estava aberto não existe mais (tudo recebido): não troca o conteúdo por baixo da pessoa.
          painel.setAttribute('data-fp', novo.getAttribute('data-fp'));
          toast('Todas as notas deste dia foram recebidas por outra pessoa. Escolha outro dia na lista.');
          return true;
        }
        painel.innerHTML = novo.innerHTML;
        painel.setAttribute('data-fp', novo.getAttribute('data-fp'));

        var box = document.getElementById('filtro-agenda');
        if (box && filtro) box.value = filtro;
        grupos().forEach(function (g) {
          var n = g.querySelector('.tname');
          if (n && fechados.indexOf(n.textContent) > -1) { g.classList.add('shut'); var tg = g.querySelector('.tog'); if (tg) tg.setAttribute('aria-expanded', 'false'); }
        });
        aplicarFiltro();
        window.scrollTo(0, y);

        if (ids(painel) !== antes && info && info.autor_id && info.autor_id !== info.eu) toast(info.autor + ' atualizou a agenda.');
        return true;
      })
      .catch(function () { return false; })
      .then(function (r) { atualizando = false; return r; });
  }

  function checar() {
    if (parado) return;
    if (document.hidden) { agendar(); return; }
    fetch('estado.php', { credentials: 'same-origin', cache: 'no-store' })
      .then(function (r) {
        if (r.status === 401) { parado = true; toast('Sua sessão expirou. Recarregue a página para entrar de novo.'); return null; }
        return r.json();
      })
      .then(function (j) {
        if (!j) return;
        falhas = 0; selo(false);
        siteAoVivo.versao(j.v);
        if (j.ok && j.fp !== painel.getAttribute('data-fp')) return atualizar(j);
      })
      .catch(function () { falhas++; if (falhas >= 2) selo(true); })
      .then(agendar);
  }
  function agendar() {
    clearTimeout(timer);
    if (parado) return;
    timer = setTimeout(checar, INTERVALO * Math.pow(2, Math.min(falhas, 3)) + Math.random() * 1500);
  }
  document.addEventListener('visibilitychange', function () { if (!document.hidden && !parado) { clearTimeout(timer); checar(); } });
  window.addEventListener('online', function () { falhas = 0; clearTimeout(timer); checar(); });
  agendar();

  // Gancho para testes automatizados no navegador.
  window.__agenda = { checar: checar, atualizar: atualizar };
})();

// ---------- Importar notas ----------
(function () {
  // Arrastar e soltar arquivos.
  var dz = document.getElementById('dz'), input = document.getElementById('arquivos'), lista = document.getElementById('dz-lista');
  function mostra() {
    if (!input || !lista) return;
    var n = input.files ? input.files.length : 0, nomes = [].slice.call(input.files || []).slice(0, 4).map(function (f) { return f.name; });
    lista.textContent = n ? n + (n === 1 ? ' arquivo: ' : ' arquivos: ') + nomes.join(', ') + (n > 4 ? '…' : '') : '';
    dz.classList.toggle('tem', n > 0);
  }
  if (dz && input) {
    input.addEventListener('change', mostra);
    ['dragenter', 'dragover'].forEach(function (ev) { dz.addEventListener(ev, function (e) { e.preventDefault(); dz.classList.add('over'); }); });
    ['dragleave', 'drop'].forEach(function (ev) { dz.addEventListener(ev, function (e) { e.preventDefault(); dz.classList.remove('over'); }); });
    dz.addEventListener('drop', function (e) { if (e.dataTransfer && e.dataTransfer.files.length) { input.files = e.dataTransfer.files; mostra(); } });
  }

  // Prévia: ferramentas em massa, contagem e envio em JSON (evita o limite de campos do servidor).
  var form = document.getElementById('form-importar');
  if (!form) return;
  var linhas = [].slice.call(form.querySelectorAll('tbody tr'));
  function campo(tr, f) { return tr.querySelector('[data-f="' + f + '"]'); }
  // "baixa" = nota que já existe no portal e a planilha diz que chegou (vai receber entrada, não é criada de novo)
  function baixa(tr) { var b = campo(tr, 'baixa'); return !!(b && b.checked); }
  function contar() {
    var n = linhas.filter(function (tr) { return campo(tr, 'inc').checked; }).length;
    var nb = linhas.filter(baixa).length;
    document.getElementById('imp-contagem').textContent = n + ' de ' + linhas.length + ' marcada' + (n === 1 ? '' : 's') + ' para gravar'
      + (nb ? ' · ' + nb + (nb === 1 ? ' vai receber entrada' : ' vão receber entrada') : '');
    document.getElementById('imp-gravar').disabled = n === 0 && nb === 0;
    linhas.forEach(function (tr) { tr.classList.toggle('off', !campo(tr, 'inc').checked && !baixa(tr)); });
  }
  form.addEventListener('change', function (e) {
    // Nota com destino ES só pode ser gravada pelo RJ se a pessoa corrigir a UF para RJ.
    var tr = e.target.closest('tr'), c = tr && campo(tr, 'inc');
    if (c && c.hasAttribute('data-so-es') && e.target.getAttribute('data-f') === 'uf') { c.disabled = e.target.value === 'ES'; c.checked = !c.disabled; }
    contar();
  });
  document.getElementById('imp-marcar').addEventListener('change', function (e) {
    linhas.forEach(function (tr) { var c = campo(tr, 'inc'); if (!tr.querySelector('a[href*="agendamento.php"]') && !c.disabled) c.checked = e.target.checked; });
    contar();
  });
  document.getElementById('imp-aplicar-data').addEventListener('click', function () {
    var v = document.getElementById('imp-data-todas').value;
    linhas.forEach(function (tr) { campo(tr, 'data_receber').value = v; });
  });
  document.getElementById('imp-aplicar-emp').addEventListener('click', function () {
    var v = document.getElementById('imp-emp-todas').value;
    linhas.forEach(function (tr) { campo(tr, 'empresa').value = v; });
  });
  form.addEventListener('submit', function () {
    var dados = linhas.map(function (tr) {
      var o = {};
      [].forEach.call(tr.querySelectorAll('[data-f]'), function (el) { o[el.getAttribute('data-f')] = el.type === 'checkbox' ? el.checked : el.value; });
      return o;
    });
    document.getElementById('imp-dados').value = JSON.stringify(dados);
  });
  contar();
})();

// ---------- Dar entrada (conferência) — na página receber.php e na janela aberta pelo ✓ da agenda ----------
function iniciarConferencia(form) {
  var bloco = form.querySelector('#rec-div'), vol = form.querySelector('#vol_recebidos');
  function radio(v) { return form.querySelector('input[name="tudo_ok"][value="' + v + '"]'); }
  function tipo(v) { return form.querySelector('input[name="tipos[]"][value="' + v + '"]'); }
  function mostrar() { bloco.hidden = !radio('nao').checked; }
  form.addEventListener('change', function (e) { if (e.target.name === 'tudo_ok') mostrar(); });
  // Volumes diferentes do esperado: já marca "teve problema" e falta/sobra.
  vol.addEventListener('input', function () {
    var esp = parseInt(vol.getAttribute('data-esperado'), 10), rec = parseInt(vol.value, 10);
    if (isNaN(esp) || isNaN(rec)) return;
    tipo('falta').checked = rec < esp;
    tipo('sobra').checked = rec > esp;
    if (rec !== esp) { radio('nao').checked = true; mostrar(); }
  });
  prepararFotos(form.querySelector('#rec-fotos'), form.querySelector('#rec-prev'));
}
if (document.getElementById('form-receber')) iniciarConferencia(document.getElementById('form-receber'));

// "Receber todas" com conferência: cada nota tem volumes e "Teve problema" (que abre o que houve e as fotos).
function iniciarGrupo(form) {
  [].forEach.call(form.querySelectorAll('.rg-item'), function (it) {
    var prob = it.querySelector('.rg-prob input'), bloco = it.querySelector('.rg-div'), vol = it.querySelector('input[name$="[vol_recebidos]"]');
    function tipo(v) { return it.querySelector('input[name$="[tipos][]"][value="' + v + '"]'); }
    function mostrar() { bloco.hidden = !prob.checked; it.classList.toggle('com-problema', prob.checked); }
    prob.addEventListener('change', mostrar);
    // ao mexer na nota, some o aviso de erro dela
    function limpar() { it.classList.remove('com-erro'); it.querySelector('.rg-erro').hidden = true; }
    it.addEventListener('input', limpar);
    it.addEventListener('change', limpar);
    vol.addEventListener('input', function () {
      var esp = parseInt(vol.getAttribute('data-esperado'), 10), rec = parseInt(vol.value, 10);
      if (isNaN(esp) || isNaN(rec)) return;
      tipo('falta').checked = rec < esp;
      tipo('sobra').checked = rec > esp;
      if (rec !== esp) { prob.checked = true; mostrar(); }
    });
    prepararFotos(it.querySelector('.rg-fotos'), it.querySelector('.rec-prev'));
  });
}

// Fotos: mostra miniaturas e reduz para no máximo 1600 px (fotos de celular têm vários MB).
function prepararFotos(input, prev) {
  if (!input) return;
  function reduzir(arq) {
    return new Promise(function (ok) {
      if (!/^image\//.test(arq.type) || !window.createImageBitmap) return ok(arq);
      createImageBitmap(arq).then(function (img) {
        var esc = Math.min(1, 1600 / Math.max(img.width, img.height));
        var c = document.createElement('canvas'); c.width = Math.round(img.width * esc); c.height = Math.round(img.height * esc);
        c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
        c.toBlob(function (b) { ok(b && b.size < arq.size ? new File([b], arq.name.replace(/\.\w+$/, '') + '.jpg', { type: 'image/jpeg' }) : arq); }, 'image/jpeg', 0.82);
      }).catch(function () { ok(arq); });
    });
  }
  input.addEventListener('change', function () {
    var arqs = [].slice.call(input.files || []).slice(0, 5);
    prev.textContent = arqs.length ? 'Preparando…' : '';
    Promise.all(arqs.map(reduzir)).then(function (novos) {
      try { var dt = new DataTransfer(); novos.forEach(function (f) { dt.items.add(f); }); input.files = dt.files; } catch (e) { /* navegador antigo: envia o original */ }
      prev.textContent = '';
      novos.forEach(function (f) { var i = document.createElement('img'); i.alt = ''; i.src = URL.createObjectURL(f); prev.appendChild(i); });
    });
  });
}

// ---------- Portaria: leitura do código de barras do DANFE ----------
(function () {
  var bt = document.getElementById('ent-cam');
  if (!bt) return;
  var caixa = document.getElementById('ent-camera'), video = document.getElementById('ent-video');
  var status = document.getElementById('ent-status'), campo = document.getElementById('ent-q'), form = document.getElementById('ent-form');
  var fluxo = null, parar = function () {}, lido = false;

  function avisar(t) { status.textContent = t; }
  function fechar() {
    parar(); parar = function () {};
    if (fluxo) { fluxo.getTracks().forEach(function (t) { t.stop(); }); fluxo = null; }
    caixa.hidden = true; bt.hidden = false;
  }
  function achou(texto) {
    if (lido) return;
    var dig = String(texto || '').replace(/\D/g, '');
    if (!dig) return;
    lido = true;
    if (navigator.vibrate) navigator.vibrate(80);
    campo.value = dig.length >= 44 ? dig.slice(0, 44) : dig;
    avisar('Código lido. Procurando a nota…');
    fechar();
    form.submit();
  }
  function erroCamera(e) {
    fechar();
    var n = e && e.name;
    avisar(!window.isSecureContext ? 'A câmera só funciona com o site em https.'
      : n === 'NotAllowedError' ? 'A câmera foi bloqueada. Libere a câmera para este site nas configurações do navegador.'
      : n === 'NotFoundError' ? 'Nenhuma câmera encontrada neste aparelho. Use o leitor ou digite o número.'
      : 'Não consegui abrir a câmera. Use o leitor ou digite o número.');
  }

  function abrirVideo() {
    return navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment', width: { ideal: 1280 } } }).then(function (s) {
      fluxo = s; video.srcObject = s; return video.play();
    });
  }
  // Tenta ler um quadro a cada pouco, até achar ou fechar. "ler" devolve uma Promise com o texto (ou vazio).
  function repetir(ler) {
    var vivo = true; parar = function () { vivo = false; };
    (function laco() {
      if (!vivo) return;
      ler().then(function (t) { if (t) achou(t); else setTimeout(laco, 150); }).catch(function () { setTimeout(laco, 250); });
    })();
  }
  // 1º: leitor do próprio navegador (Chrome no Android); 2º: biblioteca ZXing (iPhone e outros).
  function comNativo() {
    var det = new window.BarcodeDetector({ formats: ['code_128', 'itf', 'ean_13', 'qr_code'] });
    return abrirVideo().then(function () {
      repetir(function () { return det.detect(video).then(function (cods) { return cods.length ? cods[0].rawValue : ''; }); });
    });
  }
  function carregarZXing() {
    return new Promise(function (ok, falha) {
      if (window.ZXing) return ok();
      var s = document.createElement('script'); s.src = 'assets/vendor/zxing.min.js'; s.onload = ok; s.onerror = falha;
      document.head.appendChild(s);
    });
  }
  function comZXing() {
    return Promise.all([carregarZXing(), abrirVideo()]).then(function () {
      var Z = window.ZXing, dicas = new Map(), leitor = new Z.MultiFormatReader();
      dicas.set(Z.DecodeHintType.POSSIBLE_FORMATS, [Z.BarcodeFormat.CODE_128, Z.BarcodeFormat.ITF, Z.BarcodeFormat.QR_CODE]);
      dicas.set(Z.DecodeHintType.TRY_HARDER, true);
      leitor.setHints(dicas);
      var tela = document.createElement('canvas'), ctx = tela.getContext('2d', { willReadFrequently: true });
      repetir(function () {
        var w = video.videoWidth, h = video.videoHeight;
        if (!w) return Promise.resolve('');
        // só a faixa do meio (onde fica a mira): mais rápido no celular
        var y0 = Math.round(h * 0.2), alt = Math.round(h * 0.6);
        tela.width = w; tela.height = alt;
        ctx.drawImage(video, 0, y0, w, alt, 0, 0, w, alt);
        try {
          return Promise.resolve(leitor.decodeWithState(new Z.BinaryBitmap(new Z.HybridBinarizer(new Z.HTMLCanvasElementLuminanceSource(tela)))).getText());
        } catch (e) { return Promise.resolve(''); } // nenhum código neste quadro
      });
    });
  }

  bt.addEventListener('click', function () {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) return erroCamera({});
    lido = false; caixa.hidden = false; bt.hidden = true;
    avisar('Aponte para o código de barras da nota, na horizontal, bem perto.');
    var nativo = 'BarcodeDetector' in window
      ? window.BarcodeDetector.getSupportedFormats().then(function (f) { return f.indexOf('code_128') > -1; }).catch(function () { return false; })
      : Promise.resolve(false);
    nativo.then(function (tem) { return tem ? comNativo() : comZXing(); }).catch(erroCamera);
  });
  document.getElementById('ent-fechar').addEventListener('click', function () { fechar(); avisar(''); campo.focus(); });
  window.addEventListener('pagehide', fechar);
  // Leitor USB "digita" o código e manda Enter: o formulário já cuida disso. Mantém o foco no campo.
  if (!campo.value) campo.focus();
})();

// ---------- Calendário (semana): arrastar a nota para outro dia ----------
(function () {
  var cal = document.getElementById('cal');
  if (!cal) return;
  var arrastada = null;
  function aviso(msg) {
    var box = document.getElementById('toast');
    if (!box) { box = document.createElement('div'); box.id = 'toast'; box.setAttribute('role', 'status'); document.body.appendChild(box); }
    box.textContent = msg;
    box.classList.add('on');
    clearTimeout(box._t);
    box._t = setTimeout(function () { box.classList.remove('on'); }, 4500);
  }
  function limpar() { [].forEach.call(cal.querySelectorAll('.cal-col.alvo'), function (c) { c.classList.remove('alvo'); }); }
  function alvo(e) { var c = e.target.closest && e.target.closest('.cal-col[data-alvo]'); return arrastada && c ? c : null; }
  // Busca a página de novo e troca só o calendário e os números do topo (contagens e bandeja certas),
  // mantendo os grupos da bandeja abertos/fechados como a pessoa deixou e a posição da tela.
  function recarregar() {
    return fetch(location.href, { credentials: 'same-origin', cache: 'no-store' }).then(function (r) { return r.text(); }).then(function (html) {
      var doc = new DOMParser().parseFromString(html, 'text/html'), novo = doc.getElementById('cal');
      if (!novo) { parado = true; aviso('Sua sessão expirou. Recarregue a página para entrar de novo.'); return; }
      var abertos = {};
      [].forEach.call(cal.querySelectorAll('.cal-grupo'), function (g) { abertos[g.querySelector('summary').textContent.split('(')[0].trim()] = g.open; });
      var y = window.scrollY;
      cal.innerHTML = novo.innerHTML;
      cal.setAttribute('data-fp', novo.getAttribute('data-fp'));
      [].forEach.call(cal.querySelectorAll('.cal-grupo'), function (g) {
        var k = g.querySelector('summary').textContent.split('(')[0].trim();
        if (k in abertos) g.open = abertos[k];
      });
      var resumo = document.querySelector('section.summary'), resumoNovo = doc.querySelector('section.summary');
      if (resumo && resumoNovo) resumo.innerHTML = resumoNovo.innerHTML;
      window.scrollTo(0, y);
    });
  }

  // ----- ao vivo: a cada poucos segundos pergunta se algo mudou (consulta leve) e atualiza sozinho -----
  var INTERVALO = (parseInt(cal.getAttribute('data-intervalo'), 10) || 8) * 1000;
  var timer = null, falhas = 0, parado = false;
  // Não troca a tela enquanto a pessoa está mexendo (arrastando, com "Mudar dia" aberto ou digitando).
  function mexendo() {
    var a = document.activeElement;
    return !!arrastada || !!cal.querySelector('.cal-mover[open]') || !!(a && cal.contains(a) && /^(INPUT|SELECT|TEXTAREA)$/.test(a.tagName));
  }
  function checar() {
    if (parado) return Promise.resolve();
    if (document.hidden) { agendar(); return Promise.resolve(); }
    return fetch('estado.php', { credentials: 'same-origin', cache: 'no-store' })
      .then(function (r) {
        if (r.status === 401) { parado = true; aviso('Sua sessão expirou. Recarregue a página para entrar de novo.'); return null; }
        return r.json();
      })
      .then(function (j) {
        if (!j) return;
        falhas = 0;
        siteAoVivo.versao(j.v);
        if (!j.ok || j.fp === cal.getAttribute('data-fp') || mexendo()) return;
        return recarregar().then(function () {
          if (j.autor_id && j.autor_id !== j.eu) aviso(j.autor + ' atualizou o calendário.');
        });
      })
      .catch(function () { falhas++; })
      .then(agendar);
  }
  function agendar() {
    clearTimeout(timer);
    if (parado) return;
    timer = setTimeout(checar, INTERVALO * Math.pow(2, Math.min(falhas, 3)) + Math.random() * 1500);
  }
  document.addEventListener('visibilitychange', function () { if (!document.hidden && !parado) { clearTimeout(timer); checar(); } });
  window.addEventListener('online', function () { falhas = 0; clearTimeout(timer); checar(); });
  agendar();
  window.__cal = { checar: checar }; // gancho para os testes no navegador
  cal.addEventListener('dragstart', function (e) {
    var n = e.target.closest && e.target.closest('.cal-nota.movel');
    if (!n) return;
    arrastada = n;
    n.classList.add('arrastando');
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', n.getAttribute('data-id'));
  });
  cal.addEventListener('dragend', function () { if (arrastada) arrastada.classList.remove('arrastando'); arrastada = null; limpar(); });
  cal.addEventListener('dragover', function (e) {
    var c = alvo(e);
    if (!c) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    if (!c.classList.contains('alvo')) { limpar(); c.classList.add('alvo'); }
  });
  cal.addEventListener('dragleave', function (e) {
    var c = e.target.closest && e.target.closest('.cal-col');
    if (c && !c.contains(e.relatedTarget)) c.classList.remove('alvo');
  });
  cal.addEventListener('drop', function (e) {
    var c = alvo(e);
    if (!c) return;
    e.preventDefault();
    limpar();
    var n = arrastada, dia = c.getAttribute('data-dia');
    if (n.getAttribute('data-de') === dia) return;
    var csrf = cal.querySelector('input[name="csrf"]');
    var fd = new FormData();
    fd.set('csrf', csrf ? csrf.value : ''); fd.set('acao', 'reagendar'); fd.set('id', n.getAttribute('data-id'));
    fd.set('de', n.getAttribute('data-de')); fd.set('data_receber', dia);
    // move na tela na hora; se o servidor recusar, volta para onde estava
    var origem = n.parentNode, depois = n.nextSibling;
    c.querySelector('.cal-lista').appendChild(n);
    fetch('acao.php', { method: 'POST', body: fd, credentials: 'same-origin', headers: { 'X-Requested-With': 'fetch' } })
      .then(function (r) { return r.json(); })
      .then(function (r) {
        aviso(r.msg || (r.ok ? 'Pronto.' : 'Não foi possível mudar o dia.'));
        if (!r.ok) { origem.insertBefore(n, depois); return; }
        recarregar();
      })
      .catch(function () { origem.insertBefore(n, depois); aviso('Sem conexão. Tente de novo.'); });
  });
})();

// ---------- App no celular: instalar e avisos (notificações) ----------
(function () {
  if ('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch(function () { /* sem https ou navegador antigo */ });
  // Aviso chegando com o portal aberto: mostra o recado na tela (a notificação do sistema também aparece).
  window.__avisos = [];
  if ('serviceWorker' in navigator) navigator.serviceWorker.addEventListener('message', function (ev) {
    var d = ev.data || {};
    if (d.tipo !== 'aviso') return;
    window.__avisos.push(d);
    var box = document.getElementById('toast');
    if (!box) { box = document.createElement('div'); box.id = 'toast'; box.setAttribute('role', 'status'); document.body.appendChild(box); }
    box.innerHTML = '';
    var t = document.createElement('span'); t.textContent = d.titulo + (d.corpo ? ': ' + d.corpo : ''); box.appendChild(t);
    var b = document.createElement('button'); b.type = 'button'; b.textContent = 'Ver';
    b.addEventListener('click', function () { location.href = d.url; }); box.appendChild(b);
    box.classList.add('on'); clearTimeout(box._t); box._t = setTimeout(function () { box.classList.remove('on'); }, 9000);
  });
  var caixa = document.getElementById('app-itens');
  if (!caixa) return;
  var btInst = document.getElementById('app-instalar'), dicaIos = document.getElementById('app-ios');
  var btAv = document.getElementById('avisos-bt'), btTeste = document.getElementById('avisos-teste'), dicaAv = document.getElementById('avisos-dica');
  var csrf = caixa.getAttribute('data-csrf');
  var ios = /iphone|ipad|ipod/i.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  var instalado = window.matchMedia('(display-mode: standalone)').matches || navigator.standalone === true;

  function aviso(msg) {
    var box = document.getElementById('toast');
    if (!box) { box = document.createElement('div'); box.id = 'toast'; box.setAttribute('role', 'status'); document.body.appendChild(box); }
    box.textContent = msg; box.classList.add('on');
    clearTimeout(box._t); box._t = setTimeout(function () { box.classList.remove('on'); }, 5000);
  }
  function dica(t) { dicaAv.textContent = t || ''; dicaAv.hidden = !t; }
  function post(dados) {
    var fd = new FormData(); fd.set('csrf', csrf);
    Object.keys(dados).forEach(function (k) { fd.set(k, dados[k]); });
    return fetch('push.php', { method: 'POST', body: fd, credentials: 'same-origin' }).then(lerResposta);
  }
  // Resposta do servidor: JSON; se vier outra coisa (erro do servidor, bloqueio da hospedagem), diz isso em vez de "sem conexão".
  function lerResposta(r) {
    return r.text().then(function (t) {
      try { return JSON.parse(t); } catch (e) { return { ok: false, msg: 'O servidor respondeu com erro (código ' + r.status + '). Veja o arquivo error_log da pasta agendamentos.' }; }
    });
  }
  // sem o "https://": o firewall da hospedagem bloqueia (erro 406) formulário com endereço https; o servidor recoloca
  function semEsquema(url) { return String(url || '').replace(/^https?:\/\//, ''); }
  function chaveBytes(b64) {
    var s = atob((b64 + '==='.slice((b64.length + 3) % 4)).replace(/-/g, '+').replace(/_/g, '/'));
    var a = new Uint8Array(s.length); for (var i = 0; i < s.length; i++) a[i] = s.charCodeAt(i); return a;
  }

  // Instalar: Android/Chrome oferece o próprio botão; no iPhone é pelo menu Compartilhar.
  var pedido = null;
  window.addEventListener('beforeinstallprompt', function (e) { e.preventDefault(); pedido = e; btInst.hidden = false; });
  window.addEventListener('appinstalled', function () { btInst.hidden = true; aviso('App instalado. Procure o ícone "Agendamentos" na tela inicial.'); });
  btInst.addEventListener('click', function () {
    if (!pedido) return;
    pedido.prompt();
    pedido.userChoice.then(function () { pedido = null; btInst.hidden = true; });
  });
  if (ios && !instalado) dicaIos.hidden = false;

  // Avisos neste aparelho
  var suporta = 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window;
  if (!suporta) {
    if (ios && !instalado) dica('Para receber avisos no iPhone, primeiro instale o app (veja acima) e abra por ele.');
    return;
  }
  function inscricao() { return navigator.serviceWorker.ready.then(function (reg) { return reg.pushManager.getSubscription().then(function (s) { return [reg, s]; }); }); }
  function mostrarEstado() {
    inscricao().then(function (par) {
      var ativo = !!par[1] && Notification.permission === 'granted';
      btAv.hidden = false;
      btAv.textContent = ativo ? 'Desativar avisos neste aparelho' : 'Ativar avisos neste aparelho';
      btAv.setAttribute('data-ativo', ativo ? '1' : '');
      btTeste.hidden = !ativo;
      dica(Notification.permission === 'denied' ? 'Os avisos estão bloqueados neste navegador. Libere nas configurações do site (cadeado ao lado do endereço).' : '');
      // Aparelho inscrito: reenvia a inscrição uma vez por sessão, para o servidor nunca ficar sem ela
      // (ex.: um envio anterior bloqueado pela hospedagem, ou o navegador trocou o endereço).
      if (ativo) {
        var marca = 'push-sync:' + par[1].endpoint.slice(-24);
        var feita = false;
        try { feita = sessionStorage.getItem(marca) === '1'; } catch (e) { /* modo privado */ }
        if (!feita) {
          var k = par[1].toJSON().keys || {};
          post({ acao: 'inscrever', ep: semEsquema(par[1].endpoint), p256dh: k.p256dh, auth: k.auth })
            .then(function (r) { if (r.ok) { try { sessionStorage.setItem(marca, '1'); } catch (e) { /* modo privado */ } } })
            .catch(function () { /* tenta de novo na próxima página */ });
        }
      }
    });
  }
  btAv.addEventListener('click', function () {
    btAv.disabled = true;
    var feito = function () { btAv.disabled = false; mostrarEstado(); };
    if (btAv.getAttribute('data-ativo')) {
      inscricao().then(function (par) {
        var sub = par[1]; if (!sub) return;
        return post({ acao: 'cancelar', ep: semEsquema(sub.endpoint) }).then(function () { return sub.unsubscribe(); }).then(function () { aviso('Avisos desativados neste aparelho.'); });
      }).catch(function () { aviso('Não foi possível desativar. Tente de novo.'); }).then(feito);
      return;
    }
    // se já tem permissão, não pergunta de novo
    (Notification.permission === 'granted' ? Promise.resolve('granted') : Notification.requestPermission()).then(function (perm) {
      if (perm !== 'granted') { aviso('Sem permissão, o celular não mostra os avisos.'); return; }
      return fetch('push.php', { credentials: 'same-origin' }).then(lerResposta).then(function (j) {
        if (!j.chave) throw new Error(j.msg || 'sem chave');
        return navigator.serviceWorker.ready.then(function (reg) {
          return reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: chaveBytes(j.chave) });
        });
      }).then(function (sub) {
        var k = sub.toJSON().keys || {};
        return post({ acao: 'inscrever', ep: semEsquema(sub.endpoint), p256dh: k.p256dh, auth: k.auth });
      }).then(function (r) { aviso(r.msg || (r.ok ? 'Avisos ativados.' : 'Não foi possível ativar.')); });
    }).catch(function (e) { aviso('Não foi possível ativar os avisos: ' + ((e && e.message) || 'erro desconhecido')); }).then(feito);
  });
  btTeste.addEventListener('click', function () {
    btTeste.disabled = true;
    inscricao().then(function (par) { return post({ acao: 'teste', ep: par[1] ? semEsquema(par[1].endpoint) : '' }); })
      .then(function (r) { aviso(r.msg); })
      .catch(function () { aviso(navigator.onLine === false ? 'Sem conexão. Tente de novo.' : 'Não consegui falar com o servidor. Tente de novo.'); })
      .then(function () { btTeste.disabled = false; });
  });
  mostrarEstado();
})();
