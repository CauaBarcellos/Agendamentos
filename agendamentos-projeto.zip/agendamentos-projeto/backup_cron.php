<?php
/**
 * Backup automático do banco. Só roda pela linha de comando (cron do cPanel).
 * Salva em backups/ (pasta bloqueada para o navegador) e guarda os 14 mais recentes.
 *
 * cPanel → Tarefas Cron → "Uma vez por dia", comando (ajuste o caminho):
 *   /usr/local/bin/php /home/SUACONTA/public_html/backup_cron.php
 */
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require __DIR__ . '/inc/bootstrap.php';
require __DIR__ . '/inc/backup.php';

$dir = __DIR__ . '/backups';
if (!is_dir($dir)) mkdir($dir, 0750, true);
$arq = $dir . '/backup_' . date('Y-m-d_His') . '.sql' . (function_exists('gzopen') ? '.gz' : '');
$h = function_exists('gzopen') ? gzopen($arq, 'wb9') : fopen($arq, 'wb');
$n = backup_sql($h);
function_exists('gzopen') ? gzclose($h) : fclose($h);
echo "Backup salvo: " . basename($arq) . " (" . number_format($n / 1024, 0, ',', '.') . " KB sem compactar)\n";

$todos = glob($dir . '/backup_*.sql*') ?: [];
rsort($todos);
foreach (array_slice($todos, 14) as $velho) unlink($velho);
