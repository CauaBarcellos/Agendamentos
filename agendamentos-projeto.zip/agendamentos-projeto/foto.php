<?php
// Mostra uma foto do recebimento. As fotos ficam em uploads/ (bloqueada para o navegador) e só saem por aqui, para quem está logado.
require __DIR__ . '/inc/bootstrap.php';
exigir_login();

$f = q('SELECT f.*, a.uf FROM fotos f JOIN agendamentos a ON a.id = f.agendamento_id WHERE f.id = ?', [(int)($_GET['id'] ?? 0)])->fetch();
$caminho = $f ? realpath(uploads_dir() . '/' . $f['arquivo']) : false;
// A filial do ES só vê fotos das notas do ES; e o arquivo tem que estar mesmo dentro de uploads/.
if (!$f || !$caminho || !str_starts_with($caminho, realpath(uploads_dir())) || (e_filial_es() && $f['uf'] !== 'ES') || !isset(FOTO_TIPOS[$f['tipo']])) {
    http_response_code(404);
    exit('Foto não encontrada.');
}
header('Content-Type: ' . $f['tipo']);
header('Content-Length: ' . filesize($caminho));
header('Cache-Control: private, max-age=86400');
header('Content-Disposition: inline; filename="foto-' . (int)$f['id'] . '.' . FOTO_TIPOS[$f['tipo']] . '"');
readfile($caminho);
