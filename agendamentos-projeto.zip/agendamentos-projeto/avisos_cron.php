<?php
/**
 * Resumo da manhã: avisa no celular do RJ quantas notas ficaram para trás. Só roda pela linha de comando (cron do cPanel).
 *
 * cPanel → Tarefas Cron → todo dia às 7h (minuto 0, hora 7, resto *), comando (ajuste o caminho):
 *   /usr/local/bin/php /home2/SUACONTA/public_html/agendamentos/avisos_cron.php
 */
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
$_SERVER['SCRIPT_NAME'] = 'avisos_cron.php';
$_SERVER['HTTP_HOST'] = $_SERVER['HTTP_HOST'] ?? 'localhost';
require __DIR__ . '/inc/bootstrap.php';

$h = hoje();
if (ajuste('ultimo_resumo_atrasadas') === $h && !in_array('--forcar', $argv ?? [], true)) { echo "Resumo de hoje já enviado.\n"; exit; }
$r = q("SELECT COUNT(*) AS n, MIN(data_receber) AS mais_antiga, COALESCE(SUM(volumes_num), 0) AS vol FROM agendamentos WHERE entregue = 'N' AND data_receber < ?", [$h])->fetch();
$n = (int)$r['n'];
if ($n === 0) { echo "Nenhuma nota atrasada.\n"; ajuste_gravar('ultimo_resumo_atrasadas', $h); exit; }

$corpo = plural($n, 'nota ficou', 'notas ficaram') . ' para trás' . ((int)$r['vol'] ? ' (' . n($r['vol']) . ' volumes)' : '') . '. A mais antiga era para ' . br($r['mais_antiga']) . '.';
$destino = usuarios_com_perfil(['admin', 'operador']);
avisar($destino, 'Notas atrasadas', $corpo, 'index.php?dia=atrasados', 'resumo-atrasadas');
ajuste_gravar('ultimo_resumo_atrasadas', $h);
$aparelhos = $destino ? (int)q('SELECT COUNT(*) FROM push_inscricoes WHERE usuario_id IN (' . implode(',', array_fill(0, count($destino), '?')) . ')', $destino)->fetchColumn() : 0;
echo "Resumo: $corpo Enviando para $aparelhos aparelho(s).\n";
// (o envio acontece no fim do script, em push_despachar)
