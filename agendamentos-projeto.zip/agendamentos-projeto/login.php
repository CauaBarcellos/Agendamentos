<?php
require __DIR__ . '/inc/bootstrap.php';

$erro = '';
$volta = volta_segura($_GET['volta'] ?? $_POST['volta'] ?? '');
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim((string)($_POST['login'] ?? ''));
    $senha = (string)($_POST['senha'] ?? '');
    $u = login_bloqueado() ? null : q('SELECT * FROM usuarios WHERE login = ?', [$login])->fetch();
    if ($u && (int)$u['ativo'] === 1 && password_verify($senha, $u['senha_hash'])) {
        login_ok();
        if (senha_invalida($senha, $login)) q('UPDATE usuarios SET trocar_senha = 1 WHERE id = ?', [$u['id']]);
        session_regenerate_id(true);
        $_SESSION['u'] = ['id' => (int)$u['id'], 'nome' => $u['nome'], 'login' => $u['login'], 'perfil' => $u['perfil'], 'ativo' => 1];
        q('UPDATE usuarios SET ultimo_acesso = ? WHERE id = ?', [agora(), $u['id']]);
        redirecionar($volta);
    }
    usleep(600000);
    if (login_bloqueado()) $erro = 'Muitas tentativas erradas. Aguarde 15 minutos e tente de novo.';
    else { login_falhou(); $erro = 'Usuário ou senha incorretos.'; }
}
if (usuario()) redirecionar('index.php');
?><!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Entrar · Agendamentos</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Geist:wght@400;500;600;700&display=swap">
<link rel="icon" type="image/svg+xml" href="favicon.svg?v=3">
<link rel="icon" href="favicon.ico?v=3" sizes="any">
<link rel="icon" type="image/png" sizes="32x32" href="assets/favicon-32.png?v=3">
<link rel="apple-touch-icon" href="assets/apple-touch-icon.png?v=3">
<link rel="manifest" href="manifest.webmanifest">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="Agendamentos">
<link rel="stylesheet" href="assets/style.css?v=10">
</head>
<body class="loginpage">
<main class="logincard">
  <div class="brand"><span class="mark"><?= icone('caminhao', 18) ?></span><b>Agendamentos</b></div>
  <h1>Entrar</h1>
  <p class="muted">Recebimento de fornecedores · Green Med, Estevia e Essencial</p>
  <?php if ($erro): ?><div class="flash erro"><?= e($erro) ?></div><?php endif; ?>
  <form method="post" class="form1">
    <input type="hidden" name="volta" value="<?= e($volta) ?>">
    <div class="field"><label for="login">Usuário</label><input id="login" name="login" required autofocus autocomplete="username" value="<?= e($_POST['login'] ?? '') ?>"></div>
    <div class="field"><label for="senha">Senha</label><input id="senha" name="senha" type="password" required autocomplete="current-password"></div>
    <button class="btn primary full" type="submit">Entrar</button>
  </form>
  <p class="muted small">Esqueceu a senha? Peça a um administrador para redefinir.</p>
</main>
</body>
</html>
