// Service worker do app: recebe os avisos (push) mesmo com o portal fechado e mostra a página
// "Sem conexão" quando o celular está sem internet. Não guarda páginas do portal (dados sempre atuais).
const CACHE = 'agend-v4';
const OFFLINE = 'offline.html';

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll([OFFLINE, 'assets/icon-192.png', 'assets/badge-96.png'])));
  self.skipWaiting();
});

self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys()
    .then((ks) => Promise.all(ks.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
    .then(() => self.clients.claim()));
});

// Só abrir páginas (GET): se a rede falhar, mostra a página "Sem conexão".
// Envio de formulário (POST) segue direto, sem passar por aqui (no iPhone repassar POST pelo service worker falha).
self.addEventListener('fetch', (e) => {
  if (e.request.mode !== 'navigate' || e.request.method !== 'GET') return;
  e.respondWith(fetch(e.request).catch(() => caches.match(OFFLINE)));
});

// Aviso chegando do servidor (já decifrado pelo navegador).
self.addEventListener('push', (e) => {
  let d = {};
  try { d = e.data ? e.data.json() : {}; } catch (err) { d = { corpo: e.data ? e.data.text() : '' }; }
  const titulo = d.titulo || 'Agendamentos';
  e.waitUntil(Promise.all([
    self.registration.showNotification(titulo, {
      body: d.corpo || '',
      icon: 'assets/icon-192.png',
      badge: 'assets/badge-96.png',
      tag: d.tag || undefined,
      renotify: !!d.tag,
      data: { url: d.url || 'index.php' },
    }).catch(() => {}),
    // se o portal estiver aberto, avisa a página também (mostra o recado na tela)
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((lista) => {
      lista.forEach((c) => c.postMessage({ tipo: 'aviso', titulo, corpo: d.corpo || '', url: d.url || 'index.php' }));
    }),
  ]));
});

// Toque no aviso: abre (ou traz para frente) o portal na página certa — sempre dentro do próprio portal.
self.addEventListener('notificationclick', (e) => {
  e.notification.close();
  let alvo = new URL((e.notification.data && e.notification.data.url) || 'index.php', self.registration.scope).href;
  if (!alvo.startsWith(self.registration.scope)) alvo = self.registration.scope + 'index.php';
  e.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((lista) => {
    for (const c of lista) {
      if (c.url.startsWith(self.registration.scope) && 'focus' in c) return c.navigate(alvo).then((cc) => (cc || c).focus());
    }
    return self.clients.openWindow(alvo);
  }));
});
