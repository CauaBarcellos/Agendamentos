<?php
// Filial do ES: registra as notas que chegaram lá, vê o dia em que o RJ pediu para enviar cada uma
// e confirma quando chegaram no RJ. Quem cadastra e altera notas do ES é só a filial; o RJ escolhe o dia e dá entrada.
require __DIR__ . '/inc/bootstrap.php';
require __DIR__ . '/inc/layout.php';
exigir_login();
if (!pode_filial_es()) { flash('Esta tela é da filial do ES.', 'erro'); redirecionar('index.php'); }

$h = hoje();
$minimo = soma_dias($h, -120);
// Data de chegada: formato certo, não no futuro e no máximo 120 dias atrás.
$data_chegada = function (string $v) use ($h, $minimo): ?string {
    return preg_match('/^\d{4}-\d{2}-\d{2}$/', $v) && strtotime($v) && $v <= $h && $v >= $minimo ? $v : null;
};
$erros = [];
$v = ['chegou_es_em' => $h, 'empresa' => 'GREEN MED'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validar();
    $acao = (string)($_POST['acao'] ?? '');
    $uid = usuario()['id'];

    if ($acao === 'nova') {
        $d = [];
        foreach (['fornecedor', 'transportadora', 'nota_fiscal', 'volumes', 'produto', 'observacao'] as $k) {
            $x = imp_cortar(maiusc($_POST[$k] ?? ''), $k === 'observacao' ? 2000 : ($k === 'volumes' ? 40 : 150));
            $d[$k] = $x === '' ? null : $x;
        }
        $d['empresa'] = in_array($_POST['empresa'] ?? '', EMPRESAS, true) ? $_POST['empresa'] : 'GREEN MED';
        $d['chegou_es_em'] = $data_chegada((string)($_POST['chegou_es_em'] ?? ''));
        $v = $d + ['chegou_es_em' => (string)($_POST['chegou_es_em'] ?? '')];
        if (!$d['fornecedor']) $erros[] = 'Informe o fornecedor.';
        if (!$d['produto']) $erros[] = 'Informe o produto.';
        if (!$d['chegou_es_em']) $erros[] = 'Informe o dia em que chegou (hoje ou um dia que já passou).';
        if (!$erros && $d['nota_fiscal'] && ($outra = imp_duplicada('', $d['fornecedor'], $d['nota_fiscal']))) {
            $o = q('SELECT chegou_es_em FROM agendamentos WHERE id = ?', [$outra['id']])->fetch();
            $erros[] = $o['chegou_es_em'] ? 'Essa nota já foi registrada: chegou em ' . br($o['chegou_es_em']) . '.' : 'Essa NF deste fornecedor já está cadastrada no portal. Confira com o RJ.';
        }
        if (!$erros) {
            $d['volumes_num'] = ($d['volumes'] !== null && preg_match('/^(\d+)/', $d['volumes'], $m)) ? (int)$m[1] : null;
            $d += [
                'uf' => 'ES', 'filial' => FILIAL_EMP[$d['empresa']] ?? null, 'categoria' => categoria_de($d['produto'] ?? ''),
                'data_agendamento' => $h, 'data_receber' => null, 'entregue' => 'N', 'origem' => 'es', 'chegou_es_por' => $uid,
                'criado_por' => $uid, 'criado_em' => agora(), 'atualizado_por' => $uid, 'atualizado_em' => agora(),
            ];
            $cols = array_keys($d);
            q('INSERT INTO agendamentos (' . implode(',', $cols) . ') VALUES (' . implode(',', array_fill(0, count($cols), '?')) . ')', array_values($d));
            registrar_historico((int)db()->lastInsertId(), 'criou', ['chegou_es_em' => [null, $d['chegou_es_em']]]);
            $nfTxt = $d['nota_fiscal'] ? ' · NF ' . $d['nota_fiscal'] : '';
            avisar(usuarios_com_perfil(['admin', 'operador'], $uid), 'Chegou nota no ES', (titulo($d['fornecedor']) ?: 'Nota') . $nfTxt . ' chegou na filial em ' . br($d['chegou_es_em']) . '. Escolha o dia de receber.', 'index.php?dia=es', 'es-chegou');
            flash('Pronto! O RJ foi avisado que ' . (titulo($d['fornecedor']) ?: 'a nota') . ' chegou em ' . br($d['chegou_es_em']) . '.');
            redirecionar('es.php');
        }
    } elseif ($acao === 'desfazer') {
        // Registrou por engano: some de vez (fica no histórico), desde que o RJ ainda não tenha escolhido o dia.
        $id = (int)($_POST['id'] ?? 0);
        $r = q("SELECT * FROM agendamentos WHERE id = ? AND uf = 'ES' AND origem = 'es'", [$id])->fetch();
        if (!$r) { flash('Nota não encontrada.', 'erro'); redirecionar('es.php'); }
        $nome = titulo($r['fornecedor']) ?: 'A nota';
        if ($r['entregue'] !== 'N') flash("$nome já chegou no RJ; não dá mais para desfazer.", 'erro');
        elseif ($r['data_receber']) flash("O RJ já pediu $nome para " . br($r['data_receber']) . '. Para mudar, fale com o RJ.', 'erro');
        else {
            q('DELETE FROM agendamentos WHERE id = ?', [$id]);
            registrar_historico($id, 'excluiu', ['fornecedor' => [$r['fornecedor'], null], 'nota_fiscal' => [$r['nota_fiscal'], null], 'chegou_es_em' => [$r['chegou_es_em'], null]]);
            flash("Registro de $nome desfeito.");
        }
        redirecionar('es.php');
    }
}

site_fp(); // antes das consultas: a página aberta se atualiza sozinha quando isso muda
// Todas as notas do ES: as registradas pela filial e as que já vieram da planilha (transferências "FILIAL", etc.).
$base ="SELECT * FROM agendamentos WHERE uf = 'ES'";
// O RJ já escolheu o dia: é o que precisa ser enviado.
$pedidos = q("$base AND entregue = 'N' AND data_receber IS NOT NULL ORDER BY data_receber, fornecedor LIMIT 300")->fetchAll();
$aguardando = q("$base AND entregue = 'N' AND data_receber IS NULL ORDER BY chegou_es_em DESC, id DESC LIMIT 300")->fetchAll();
// Já chegaram no RJ. Nas antigas da planilha não há hora da entrada; vale o dia de receber.
$quandoChegou = 'COALESCE(DATE(entregue_em), data_receber)';
$historico = isset($_GET['historico']);
$busca = trim((string)($_GET['q'] ?? ''));
if ($historico) {
    // Histórico completo: notas do portal/planilha + a planilha antiga de recebidas do ES.
    $wq = $wq2 = '';
    $pq = [];
    if ($busca !== '') {
        $wq = ' AND (fornecedor LIKE :q OR nota_fiscal LIKE :q OR transportadora LIKE :q OR produto LIKE :q)';
        $wq2 = ' AND (fornecedor LIKE :q OR nota_fiscal LIKE :q OR transportadora LIKE :q OR material LIKE :q)';
        $pq[':q'] = '%' . $busca . '%';
    }
    $chegaram = q("SELECT * FROM (
        SELECT fornecedor, transportadora, produto, nota_fiscal, volumes, empresa, data_receber, chegou_es_em, $quandoChegou AS chegou_rj, divergencia, divergencia_obs FROM agendamentos WHERE uf = 'ES' AND entregue = 'S'$wq
        UNION ALL
        SELECT fornecedor, transportadora, material, nota_fiscal, volumes, '', NULL, NULL, data_recebido_rj, NULL, NULL FROM recebidas_es WHERE 1=1$wq2
      ) t ORDER BY chegou_rj DESC LIMIT 1000", $pq)->fetchAll();
} else {
    $chegaram = q("SELECT *, $quandoChegou AS chegou_rj FROM agendamentos WHERE uf = 'ES' AND entregue = 'S' ORDER BY chegou_rj DESC, id DESC LIMIT 15")->fetchAll();
}
$totChegaram = (int)q("SELECT (SELECT COUNT(*) FROM agendamentos WHERE uf = 'ES' AND entregue = 'S') + (SELECT COUNT(*) FROM recebidas_es)")->fetchColumn();

$fornecedores = q("SELECT DISTINCT fornecedor FROM agendamentos WHERE fornecedor <> '' ORDER BY fornecedor")->fetchAll(PDO::FETCH_COLUMN);
$transps = q("SELECT DISTINCT transportadora FROM agendamentos WHERE transportadora <> '' ORDER BY transportadora")->fetchAll(PDO::FETCH_COLUMN);
$val = fn($k) => e($v[$k] ?? '');
$linhaNota = function (array $r): string {
    $nfs = array_values(array_filter(array_map('trim', preg_split('#[/;,]#', (string)$r['nota_fiscal']))));
    $nf = !$nfs ? 'sem NF' : (count($nfs) === 1 ? 'NF ' . $nfs[0] : 'NF ' . $nfs[0] . ' e mais ' . (count($nfs) - 1));
    $extra = array_filter([frase($r['produto']), $nf, $r['volumes'] ? $r['volumes'] . ' vol' : '', titulo($r['transportadora']), $r['empresa'] ? emp_nome($r['empresa']) : '']);
    return '<div class="who"><b>' . e(titulo($r['fornecedor']) ?: 'Fornecedor não informado') . '</b><small>' . e(implode(' · ', $extra)) . '</small></div>';
};
$quando = function (string $d) use ($h): string {
    return ($d === $h ? 'hoje, ' : ($d === soma_dias($h, 1) ? 'amanhã, ' : '')) . mb_strtolower(DIAS[(int)date('w', strtotime($d))]) . ' ' . br($d);
};

topo('Filial ES', 'es');
?>
<div class="es-col">
<div class="pagehead"><h1>Filial ES</h1><p class="muted">Registre as notas que chegaram na filial. O RJ escolhe o dia em que quer receber e você vê abaixo o que enviar.</p></div>

<section class="card">
  <details class="es-nova-box" <?= $erros ? 'open' : '' ?>>
    <summary><span class="es-mais"><?= icone('mais', 17) ?></span> Chegou nota na filial? Registrar</summary>
    <form method="post" action="es.php" id="es-nova">
      <?= csrf_campo() ?><input type="hidden" name="acao" value="nova">
      <?php if ($erros): ?><div class="flash erro" style="margin:0 0 12px"><?= e(implode(' ', $erros)) ?></div><?php endif; ?>
      <div class="form">
        <div class="field"><label for="fornecedor">Fornecedor</label><input id="fornecedor" name="fornecedor" list="dlFo" required value="<?= $val('fornecedor') ?>" autocomplete="off" placeholder="Ex.: TEUTO"></div>
        <div class="field"><label for="produto">Produto</label><input id="produto" name="produto" list="dlPr" required value="<?= $val('produto') ?>" autocomplete="off" placeholder="Ex.: SORO"></div>
        <div class="field"><label for="nota_fiscal">Nota fiscal</label><input id="nota_fiscal" name="nota_fiscal" value="<?= $val('nota_fiscal') ?>" autocomplete="off"></div>
        <div class="field"><label for="volumes">Volumes</label><input id="volumes" name="volumes" value="<?= $val('volumes') ?>" inputmode="numeric" autocomplete="off"></div>
        <div class="field"><label for="empresa">Empresa</label><select id="empresa" name="empresa"><?php foreach (EMPRESAS as $em) echo '<option value="' . $em . '"' . (($v['empresa'] ?? '') === $em ? ' selected' : '') . '>' . e(emp_nome($em)) . '</option>'; ?></select></div>
        <div class="field"><label for="chegou_es_em">Chegou em</label><input id="chegou_es_em" name="chegou_es_em" type="date" required max="<?= $h ?>" min="<?= $minimo ?>" value="<?= $val('chegou_es_em') ?>"></div>
        <div class="field"><label for="transportadora">Transportadora <span class="muted">(opcional)</span></label><input id="transportadora" name="transportadora" list="dlTr" value="<?= $val('transportadora') ?>" autocomplete="off"></div>
        <div class="field"><label for="observacao">Observação <span class="muted">(opcional)</span></label><input id="observacao" name="observacao" value="<?= $val('observacao') ?>" placeholder="Ex.: falta 1 volume"></div>
      </div>
      <div class="es-nova-pe"><button class="btn primary" type="submit"><?= icone('check', 15) ?> Registrar chegada</button></div>
    </form>
  </details>
</section>

<div id="es-listas" data-vivo>
<section class="card es-pedidos" aria-labelledby="t-pedidos">
  <div class="es-head"><h2 id="t-pedidos">O RJ pediu para enviar <span class="muted">(<?= count($pedidos) ?>)</span></h2></div>
  <?php if (!$pedidos): ?><p class="es-vazio">Nenhum pedido do RJ no momento.</p><?php endif; ?>
  <?php foreach ($pedidos as $r): $urg = $r['data_receber'] <= soma_dias($h, 1); ?>
    <div class="esitem">
      <?= $linhaNota($r) ?>
      <div class="es-st"><span class="st s-<?= $urg ? 'hoje' : 'agendado' ?>">Chegar no RJ <?= e($quando($r['data_receber'])) ?></span><?php if ($r['chegou_es_em']): ?><small>chegou no ES em <?= br($r['chegou_es_em']) ?></small><?php endif; ?></div>
    </div>
  <?php endforeach; ?>
</section>

<?php if ($aguardando): ?>
<section class="card es-aguardando" aria-labelledby="t-aguardando">
  <div class="es-head"><h2 id="t-aguardando">Aguardando o RJ escolher o dia <span class="muted">(<?= count($aguardando) ?>)</span></h2></div>
  <?php foreach ($aguardando as $r): ?>
    <div class="esitem">
      <?= $linhaNota($r) ?>
      <div class="es-st"><small><?= $r['chegou_es_em'] ? 'chegou no ES em ' . br($r['chegou_es_em']) : 'sem dia definido' ?></small></div>
      <?php if ($r['origem'] === 'es'): ?>
      <form method="post" action="es.php" class="es-acao es-desfazer" data-confirma="Desfazer o registro de <?= e(titulo($r['fornecedor']) ?: 'esta nota') ?>?">
        <?= csrf_campo() ?><input type="hidden" name="acao" value="desfazer"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
        <button class="btn ghost sm" type="submit">Desfazer</button>
      </form>
      <?php endif; ?>
    </div>
  <?php endforeach; ?>
</section>
<?php endif; ?>

<section class="card es-chegaram" aria-labelledby="t-chegaram">
  <div class="es-head">
    <h2 id="t-chegaram">Chegaram no RJ <span class="muted">(<?= $historico ? n(count($chegaram)) . ($busca !== '' ? ' encontradas' : '') : 'mais recentes' ?>)</span></h2>
    <?php if ($historico): ?>
    <form class="search" method="get" action="es.php" role="search"><input type="hidden" name="historico" value="1"><?= icone('busca', 15) ?><input type="search" name="q" value="<?= e($busca) ?>" placeholder="Procurar fornecedor ou NF" autocomplete="off" aria-label="Procurar no histórico"></form>
    <?php endif; ?>
  </div>
  <?php if (!$chegaram): ?><p class="es-vazio"><?= $busca !== '' ? 'Nada encontrado.' : 'Quando o RJ der entrada numa nota, ela aparece aqui.' ?></p><?php endif; ?>
  <?php foreach ($chegaram as $r): ?>
    <div class="esitem">
      <?= $linhaNota($r) ?>
      <div class="es-st"><span class="st s-<?= empty($r['divergencia']) ? 'entregue' : 'divergencia' ?>">Chegou no RJ em <?= br($r['chegou_rj']) ?><?= empty($r['divergencia']) ? '' : ' com divergência' ?></span><?php if (!empty($r['divergencia'])): ?><small class="es-div"><?= e(divergencia_txt($r['divergencia']) . ($r['divergencia_obs'] ? ': ' . $r['divergencia_obs'] : '')) ?></small><?php endif; ?><?php if ($r['chegou_es_em']): ?><small>chegou no ES em <?= br($r['chegou_es_em']) ?></small><?php endif; ?></div>
    </div>
  <?php endforeach; ?>
  <?php if (!$historico && $totChegaram > count($chegaram)): ?><p class="es-vazio"><a href="es.php?historico=1#t-chegaram">Ver todas as <?= n($totChegaram) ?> que já chegaram no RJ</a></p><?php endif; ?>
  <?php if ($historico): ?><p class="es-vazio"><a href="es.php">Voltar para as recentes</a></p><?php endif; ?>
</section>
</div>
</div>

<datalist id="dlFo"><?php foreach ($fornecedores as $x) echo '<option value="' . e($x) . '">'; ?></datalist>
<datalist id="dlTr"><?php foreach ($transps as $x) echo '<option value="' . e($x) . '">'; ?></datalist>
<datalist id="dlPr"><?php foreach (['MATERIAL', 'MEDICAMENTO', 'FRALDA', 'SORO', 'LUVA', 'SANEANTES', 'AVENTAL', 'SERINGA', 'DIVERSOS'] as $x) echo '<option value="' . $x . '">'; ?></datalist>
<?php rodape();
