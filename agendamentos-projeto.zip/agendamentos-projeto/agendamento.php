<?php
// Detalhe, edição, criação e exclusão de um agendamento.
require __DIR__ . '/inc/bootstrap.php';
require __DIR__ . '/inc/layout.php';
exigir_login();

$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$r = $id ? q('SELECT * FROM agendamentos WHERE id = ?', [$id])->fetch() : null;
if ($id && !$r) { flash('Agendamento não encontrado.', 'erro'); redirecionar('registros.php'); }
$novo = !$r;
if ($novo) exigir_edicao();
// Notas do ES: quem cadastra e altera é só a filial do ES. O RJ vê, escolhe o dia de receber e dá entrada quando chega.
$doES = $r && $r['uf'] === 'ES';
$travadoES = $doES && !e_admin();
$editando = $novo || (isset($_GET['editar']) && pode_editar() && !$travadoES);
$erros = [];
$CAMPOS = ['fornecedor', 'transportadora', 'empresa', 'uf', 'data_receber', 'data_agendamento', 'nota_fiscal', 'volumes', 'produto', 'email_enviado', 'entregue', 'observacao', 'obs_vianna'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validar();
    exigir_edicao();
    $acao = $_POST['acao'] ?? 'salvar';
    if ($travadoES && !in_array($acao, ['entregue', 'desfazer'], true)) {
        flash('Notas do ES só a filial do ES altera. Aqui você escolhe o dia de receber e dá entrada quando chegar.', 'erro');
        redirecionar("agendamento.php?id=$id");
    }

    if ($acao === 'excluir' && $r) {
        exigir_admin();
        if (($_POST['confirmar'] ?? '') !== 'sim') { flash('Marque a confirmação para excluir.', 'erro'); redirecionar("agendamento.php?id=$id"); }
        $snap = array_intersect_key($r, array_flip($CAMPOS));
        q('DELETE FROM agendamentos WHERE id = ?', [$id]);
        registrar_historico($id, 'excluiu', $snap);
        flash('Agendamento excluído.');
        redirecionar('registros.php');
    }

    if ($acao === 'entregue' && $r) {
        if ($doES && !$r['data_receber']) { flash('Escolha primeiro o dia de receber esta nota do ES.', 'erro'); redirecionar("agendamento.php?id=$id"); }
        if ($r['entregue'] !== 'S') {
            q("UPDATE agendamentos SET entregue='S', entregue_em=?, vol_recebidos=volumes_num, atualizado_por=?, atualizado_em=? WHERE id=?", [agora(), usuario()['id'], agora(), $id]);
            registrar_historico($id, 'entregue', ['entregue' => [$r['entregue'], 'S']]);
        }
        flash('Marcado como entregue.');
        redirecionar("agendamento.php?id=$id");
    }

    if ($acao === 'desfazer' && $r) {
        if ($r['entregue'] === 'S') {
            q("UPDATE agendamentos SET entregue='N', entregue_em=NULL, vol_recebidos=NULL, divergencia=NULL, divergencia_obs=NULL, atualizado_por=?, atualizado_em=? WHERE id=?", [usuario()['id'], agora(), $id]);
            registrar_historico($id, 'reabriu', ['entregue' => ['S', 'N']]);
        }
        flash('Nota reaberta: voltou para aguardando.');
        redirecionar("agendamento.php?id=$id");
    }

    // salvar (novo ou edição)
    $d = [];
    foreach (['fornecedor', 'transportadora', 'nota_fiscal', 'volumes', 'produto', 'observacao', 'obs_vianna'] as $k) {
        $v = maiusc($_POST[$k] ?? '');
        $d[$k] = $v === '' ? null : $v;
    }
    $d['empresa'] = in_array($_POST['empresa'] ?? '', EMPRESAS, true) ? $_POST['empresa'] : ($r['empresa'] ?? 'GREEN MED');
    // Só o administrador muda a UF; notas do ES nascem pela tela da filial.
    $d['uf'] = e_admin() && in_array($_POST['uf'] ?? '', ['RJ', 'ES'], true) ? $_POST['uf'] : ($r['uf'] ?? 'RJ');
    $d['email_enviado'] = in_array($_POST['email_enviado'] ?? '', ['SIM', 'NÃO'], true) ? $_POST['email_enviado'] : null;
    $d['entregue'] = in_array($_POST['entregue'] ?? 'N', ['N', 'S', 'D'], true) ? ($_POST['entregue'] ?? 'N') : 'N';
    foreach (['data_receber', 'data_agendamento'] as $k) {
        $v = (string)($_POST[$k] ?? '');
        $d[$k] = preg_match('/^\d{4}-\d{2}-\d{2}$/', $v) ? $v : null;
    }
    if (!$d['fornecedor']) $erros[] = 'Informe o fornecedor.';
    if (!$d['data_receber'] && $novo) $erros[] = 'Informe a data para receber.';
    $dup = false;
    if (!$erros && $d['nota_fiscal'] && $d['fornecedor'] && ($novo || $d['nota_fiscal'] !== ($r['nota_fiscal'] ?? null) || $d['fornecedor'] !== ($r['fornecedor'] ?? null))) {
        $outra = q('SELECT id, data_receber FROM agendamentos WHERE fornecedor = ? AND nota_fiscal = ? AND id <> ? LIMIT 1', [$d['fornecedor'], $d['nota_fiscal'], $id])->fetch();
        if ($outra && ($_POST['confirma_dup'] ?? '') !== 'sim') {
            $dup = true;
            $erros[] = 'Já existe a NF ' . $d['nota_fiscal'] . ' deste fornecedor' . ($outra['data_receber'] ? ' (receber em ' . br($outra['data_receber']) . ')' : '') . '. Confira antes de salvar.';
        }
    }

    if (!$erros) {
        $d['volumes_num'] = ($d['volumes'] !== null && preg_match('/^(\d+)/', $d['volumes'], $m)) ? (int)$m[1] : null;
        $d['categoria'] = categoria_de($d['produto'] ?? '');
        if ($novo || $d['empresa'] !== $r['empresa']) $d['filial'] = FILIAL_EMP[$d['empresa']] ?? null;
        $uid = usuario()['id'];
        if ($novo) {
            $d += ['origem' => 'portal', 'criado_por' => $uid, 'criado_em' => agora(), 'atualizado_por' => $uid, 'atualizado_em' => agora()];
            if ($d['entregue'] === 'S') $d['entregue_em'] = agora();
            $cols = array_keys($d);
            q('INSERT INTO agendamentos (' . implode(',', $cols) . ') VALUES (' . implode(',', array_fill(0, count($cols), '?')) . ')', array_values($d));
            $novoId = (int)db()->lastInsertId();
            registrar_historico($novoId, 'criou');
            flash('Agendamento salvo para ' . br($d['data_receber']) . '.');
            redirecionar('index.php?dia=' . $d['data_receber']);
        } else {
            $dif = [];
            foreach ($CAMPOS as $k) {
                if ((string)($r[$k] ?? '') !== (string)($d[$k] ?? '')) $dif[$k] = [$r[$k], $d[$k]];
            }
            if ($dif) {
                if ($d['entregue'] === 'S' && $r['entregue'] !== 'S') $d['entregue_em'] = agora();
                if ($d['entregue'] !== 'S') $d['entregue_em'] = null;
                $d['atualizado_por'] = $uid;
                $d['atualizado_em'] = agora();
                $set = implode(',', array_map(fn($k) => "$k = ?", array_keys($d)));
                q("UPDATE agendamentos SET $set WHERE id = ?", array_merge(array_values($d), [$id]));
                registrar_historico($id, 'editou', $dif);
                flash('Alterações salvas.');
            } else {
                flash('Nada foi alterado.');
            }
            redirecionar("agendamento.php?id=$id");
        }
    }
    // Com erro: reapresenta o formulário com o que foi digitado
    $r = array_merge($r ?: [], $d);
    $editando = true;
}

$v = $r ?: ['empresa' => $EMP ?: 'GREEN MED', 'uf' => 'RJ', 'data_receber' => soma_dias(hoje(), 1), 'data_agendamento' => hoje(), 'produto' => 'MATERIAL', 'email_enviado' => 'SIM', 'entregue' => 'N'];
$st = $novo ? null : status_de($r);
$forn = titulo($v['fornecedor'] ?? '') ?: 'Fornecedor não informado';

topo($novo ? 'Novo agendamento' : $forn, 'outro');
?>
<a class="back" href="<?= $novo ? 'index.php' : 'registros.php' ?>" <?= $novo ? '' : 'data-voltar' ?>><?= icone('voltar', 15) ?> Voltar</a>

<?php if ($editando): ?>
  <?php
  $fornecedores = q("SELECT DISTINCT fornecedor FROM agendamentos WHERE fornecedor <> '' ORDER BY fornecedor")->fetchAll(PDO::FETCH_COLUMN);
  $transps = q("SELECT DISTINCT transportadora FROM agendamentos WHERE transportadora <> '' ORDER BY transportadora")->fetchAll(PDO::FETCH_COLUMN);
  $val = fn($k) => e($v[$k] ?? '');
  ?>
  <form class="card formcard" method="post" action="agendamento.php<?= $novo ? '' : '?id=' . $id ?>">
    <?= csrf_campo() ?><input type="hidden" name="acao" value="salvar"><?php if (!$novo): ?><input type="hidden" name="id" value="<?= $id ?>"><?php endif; ?>
    <div class="cardhead">
      <div class="eyebrow"><?= $novo ? 'Registrar entrega prevista' : 'Editando' ?></div>
      <h1><?= $novo ? 'Novo agendamento' : e($forn) ?></h1>
    </div>
    <?php if ($erros): ?><div class="flash erro"><?= e(implode(' ', $erros)) ?><?php if (!empty($dup)): ?> <?php if (!empty($outra['id'])): ?><a href="agendamento.php?id=<?= (int)$outra['id'] ?>" target="_blank" rel="noopener">Ver a nota existente</a><?php endif; ?><label class="checkline" style="margin-top:8px"><input type="checkbox" name="confirma_dup" value="sim"> É outra nota mesmo, salvar assim</label><?php endif; ?></div><?php endif; ?>

    <div class="blk"><h5>Quem entrega</h5><div class="form">
      <div class="field full"><label for="fornecedor">Fornecedor</label><input id="fornecedor" name="fornecedor" list="dlFo" required value="<?= $val('fornecedor') ?>" autocomplete="off" placeholder="Ex.: TEUTO" <?= $novo ? 'autofocus' : '' ?>></div>
      <div class="field full"><label for="transportadora">Transportadora</label><input id="transportadora" name="transportadora" list="dlTr" value="<?= $val('transportadora') ?>" autocomplete="off" placeholder="Ex.: TELECARGA"></div>
    </div></div>

    <div class="blk"><h5>Para onde e quando</h5><div class="form">
      <div class="field"><label for="empresa">Empresa</label><select id="empresa" name="empresa"><?php foreach (EMPRESAS as $em) echo '<option value="' . $em . '"' . (($v['empresa'] ?? '') === $em ? ' selected' : '') . '>' . emp_nome($em) . '</option>'; ?></select></div>
      <?php if (e_admin()): ?><div class="field"><label for="uf">UF</label><select id="uf" name="uf"><?php foreach (['RJ', 'ES'] as $u) echo '<option' . (($v['uf'] ?? 'RJ') === $u ? ' selected' : '') . '>' . $u . '</option>'; ?></select></div><?php endif; ?>
      <div class="field"><label for="data_receber">Data para receber</label><input id="data_receber" name="data_receber" type="date" value="<?= $val('data_receber') ?>" <?= $novo ? 'required' : '' ?>></div>
      <div class="field"><label for="data_agendamento">Agendado em</label><input id="data_agendamento" name="data_agendamento" type="date" value="<?= $val('data_agendamento') ?>"></div>
    </div></div>

    <div class="blk"><h5>Carga</h5><div class="form">
      <div class="field"><label for="nota_fiscal">Nota fiscal</label><input id="nota_fiscal" name="nota_fiscal" value="<?= $val('nota_fiscal') ?>" autocomplete="off"></div>
      <div class="field"><label for="volumes">Volumes</label><input id="volumes" name="volumes" value="<?= $val('volumes') ?>" inputmode="numeric" autocomplete="off"></div>
      <div class="field"><label for="produto">Produto</label><input id="produto" name="produto" list="dlPr" value="<?= $val('produto') ?>" autocomplete="off"></div>
      <div class="field"><label for="email_enviado">E-mail enviado</label><select id="email_enviado" name="email_enviado"><?php foreach (['SIM' => 'Sim', 'NÃO' => 'Não'] as $k => $l) echo '<option value="' . $k . '"' . (($v['email_enviado'] ?? '') === $k ? ' selected' : '') . '>' . $l . '</option>'; ?></select></div>
      <?php if (!$novo): ?>
      <div class="field"><label for="entregue">Situação</label><select id="entregue" name="entregue"><?php foreach (ENT_LABEL as $k => $l) echo '<option value="' . $k . '"' . (($v['entregue'] ?? 'N') === $k ? ' selected' : '') . '>' . $l . '</option>'; ?></select></div>
      <?php endif; ?>
      <div class="field full"><label for="observacao">Observação</label><textarea id="observacao" name="observacao" placeholder="Ex.: empenho pendente, será entregue na Smart"><?= $val('observacao') ?></textarea></div>
      <?php if (!$novo): ?>
      <div class="field full"><label for="obs_vianna">Obs. Vianna</label><textarea id="obs_vianna" name="obs_vianna"><?= $val('obs_vianna') ?></textarea></div>
      <?php endif; ?>
    </div></div>

    <div class="cardfoot">
      <span class="sp"></span>
      <a class="btn" href="<?= $novo ? 'index.php' : 'agendamento.php?id=' . $id ?>">Cancelar</a>
      <button class="btn primary" type="submit"><?= $novo ? 'Salvar agendamento' : 'Salvar alterações' ?></button>
    </div>
  </form>
  <datalist id="dlFo"><?php foreach ($fornecedores as $x) echo '<option value="' . e($x) . '">'; ?></datalist>
  <datalist id="dlTr"><?php foreach ($transps as $x) echo '<option value="' . e($x) . '">'; ?></datalist>
  <datalist id="dlPr"><?php foreach (['MATERIAL', 'MEDICAMENTO', 'FRALDA', 'SORO', 'LUVA', 'SANEANTES', 'AVENTAL', 'SERINGA', 'DIVERSOS'] as $x) echo '<option value="' . $x . '">'; ?></datalist>

<?php else:
  $hist = q('SELECT h.*, u.nome FROM historico h LEFT JOIN usuarios u ON u.id = h.usuario_id WHERE h.agendamento_id = ? ORDER BY h.id DESC LIMIT 50', [$id])->fetchAll();
  $kv = function (array $linhas) { echo '<dl class="kv">'; foreach ($linhas as [$a, $b]) if ($b !== '' && $b !== null) echo '<dt>' . $a . '</dt><dd>' . $b . '</dd>'; echo '</dl>'; };
  ?>
  <div class="detail">
    <div class="card">
      <div class="cardhead">
        <div class="eyebrow"><?= $r['nota_fiscal'] ? 'NF ' . e($r['nota_fiscal']) : 'Sem nota fiscal' ?> · <?= e(emp_nome($r['empresa'])) ?></div>
        <h1><?= e($forn) ?></h1>
        <span class="st s-<?= $st ?>"><?= ST_LABEL[$st] ?></span>
      </div>
      <div class="blk"><h5>Entrega</h5><?php $kv([
          ['Receber em', $r['data_receber'] ? br($r['data_receber']) . ' · ' . DIAS[(int)date('w', strtotime($r['data_receber']))] : 'Sem data'],
          ['Agendado em', br($r['data_agendamento'])],
          ['Transportadora', e(titulo($r['transportadora']) ?: '—')],
          ['Volumes', e($r['volumes'] ?: '—')],
          ['Destino', e(emp_nome($r['empresa']) . ($r['filial'] ? ' · filial ' . $r['filial'] : '') . ' · ' . $r['uf'])],
          ['Chegou no ES em', $r['chegou_es_em'] ? br($r['chegou_es_em']) . ($r['data_receber'] ? '' : ' · <span class="st s-hoje">aguardando o Rio escolher a data</span>') : ''],
      ]); ?></div>
      <div class="blk"><h5>Nota</h5><?php $kv([
          ['Nota fiscal', '<span class="mono">' . e($r['nota_fiscal'] ?: '—') . '</span>'],
          ['Produto', e(frase($r['produto']) ?: '—')],
          ['E-mail enviado', e(frase($r['email_enviado']))],
          ['Ref. interna', e($r['ref_interna'])],
          ['Chave da NF-e', $r['chave_nfe'] ? '<span class="mono" style="word-break:break-all">' . e(trim(chunk_split($r['chave_nfe'], 4, ' '))) . '</span>' : ''],
      ]); ?></div>
      <?php if ($r['entregue'] === 'S'):
          $fotos = fotos_de($id);
          $volTxt = $r['vol_recebidos'] !== null ? n($r['vol_recebidos']) . ($r['volumes_num'] !== null && (int)$r['vol_recebidos'] !== (int)$r['volumes_num'] ? ' de ' . n($r['volumes_num']) . ' esperados' : '') : ''; ?>
      <div class="blk"><h5>Recebimento</h5><?php $kv([
          ['Entrada em', $r['entregue_em'] ? br_hora($r['entregue_em']) : ''],
          ['Volumes recebidos', e($volTxt)],
          ['Conferência', $r['divergencia'] ? '' : ($r['vol_recebidos'] !== null || $fotos ? '<span class="st s-entregue">Chegou tudo certo</span>' : '')],
      ]); ?>
        <?php if ($r['divergencia']): ?><div class="divbox"><b><?= e(divergencia_txt($r['divergencia'])) ?></b><?php if ($r['divergencia_obs']): ?><div><?= e($r['divergencia_obs']) ?></div><?php endif; ?></div><?php endif; ?>
        <?php if ($fotos): ?><div class="fotos-nota"><?php foreach ($fotos as $fo): ?><a href="foto.php?id=<?= (int)$fo['id'] ?>" target="_blank" rel="noopener"><img src="foto.php?id=<?= (int)$fo['id'] ?>" alt="Foto do recebimento" loading="lazy"></a><?php endforeach; ?></div><?php endif; ?>
      </div>
      <?php endif; ?>
      <?php if ($r['observacao'] || $r['obs_vianna']): ?>
      <div class="blk"><h5>Observações</h5>
        <?php if ($r['observacao']): ?><div class="notebox"><small>Observação</small><?= e(frase($r['observacao'])) ?></div><?php endif; ?>
        <?php if ($r['obs_vianna']): ?><div class="notebox"><small>Obs. Vianna</small><?= e(frase($r['obs_vianna'])) ?></div><?php endif; ?>
      </div>
      <?php endif; ?>
      <div class="audit"><?= match ($r['origem']) {
          'planilha' => 'Importado da planilha, linha ' . (int)$r['linha_planilha'],
          'xml' => 'Importado de XML da NF-e em ' . br_hora($r['criado_em']),
          'csv' => 'Importado de planilha em ' . br_hora($r['criado_em']),
          'es' => 'Cadastrado pela filial do ES em ' . br_hora($r['criado_em']),
          default => 'Criado no portal em ' . br_hora($r['criado_em']),
      } ?></div>
      <?php if ($doES && $r['chegou_es_em'] && $r['entregue'] === 'N' && pode_editar()): ?>
      <form method="post" action="acao.php" class="es-receber es-receber-det">
        <?= csrf_campo() ?><input type="hidden" name="acao" value="receber_es"><input type="hidden" name="id" value="<?= $id ?>"><input type="hidden" name="de" value="<?= e($r['data_receber']) ?>"><input type="hidden" name="volta" value="agendamento.php?id=<?= $id ?>">
        <label for="rec-det"><?= $r['data_receber'] ? 'Mudar o dia de receber no RJ' : 'Escolha o dia de receber no RJ' ?></label>
        <input id="rec-det" type="date" name="data_receber" value="<?= e($r['data_receber'] ?: soma_dias(hoje(), 1)) ?>" min="<?= e(hoje()) ?>" required>
        <button class="btn<?= $r['data_receber'] ? '' : ' primary' ?>" type="submit"><?= $r['data_receber'] ? 'Salvar dia' : 'Agendar' ?></button>
      </form>
      <?php endif; ?>
      <?php if ($travadoES): ?><p class="muted small" style="margin:0">Nota da filial ES: os dados só são alterados pela filial. O RJ escolhe o dia e dá entrada quando chega.</p><?php endif; ?>
      <?php if (pode_editar()): ?>
      <div class="cardfoot">
        <?php if (e_admin()): ?>
        <details class="del">
          <summary class="btn ghost danger">Excluir</summary>
          <form method="post" class="delbox"><?= csrf_campo() ?><input type="hidden" name="acao" value="excluir"><input type="hidden" name="id" value="<?= $id ?>">
            <label><input type="checkbox" name="confirmar" value="sim" required> Confirmo que quero excluir este agendamento</label>
            <button class="btn danger" type="submit">Excluir definitivamente</button>
          </form>
        </details>
        <?php endif; ?>
        <span class="sp"></span>
        <?php if (!$travadoES): ?><a class="btn" href="agendamento.php?id=<?= $id ?>&amp;editar=1"><?= icone('editar', 15) ?>Editar</a><?php endif; ?>
        <?php if ($r['entregue'] === 'S'): ?>
        <form method="post" class="inline"><?= csrf_campo() ?><input type="hidden" name="acao" value="desfazer"><input type="hidden" name="id" value="<?= $id ?>"><button class="btn" type="submit">Reabrir (desfazer baixa)</button></form>
        <?php endif; ?>
        <?php if ($r['entregue'] === 'N' && (!$doES || $r['data_receber'])): ?>
        <a class="btn primary" href="receber.php?id=<?= $id ?>"><?= icone('check', 15) ?>Dar entrada</a>
        <?php endif; ?>
      </div>
      <?php endif; ?>
    </div>

    <aside class="card hist">
      <div class="cardhead"><h2>Histórico</h2></div>
      <?php if (!$hist): ?><p class="muted small">Nenhuma alteração feita no portal ainda.</p><?php endif; ?>
      <ol class="timeline">
      <?php foreach ($hist as $hh):
          $det = $hh['detalhes'] ? json_decode($hh['detalhes'], true) : null;
          $txt = ['criou' => 'criou o agendamento', 'editou' => 'editou', 'entregue' => 'deu entrada', 'reabriu' => 'reabriu a nota', 'excluiu' => 'excluiu'][$hh['acao']] ?? $hh['acao'];
          // Fotos: "adicionou 2 fotos" em vez de "fotos: vazio → 2 fotos"
          if ($hh['acao'] === 'editou' && $det && array_keys($det) === ['fotos']) { $txt = 'adicionou ' . $det['fotos'][1]; $det = null; }
          // Na entrada, mostra a conferência (volumes e divergência), não a troca de situação
          if ($hh['acao'] === 'entregue' && $det) unset($det['entregue']);
          $novos = ['vol_recebidos', 'divergencia', 'divergencia_obs']; ?>
        <li>
          <div><b><?= e($hh['nome'] ?: 'Usuário removido') ?></b> <?= e($txt) ?></div>
          <?php if (in_array($hh['acao'], ['editou', 'entregue'], true) && $det): ?>
            <ul class="changes"><?php foreach ($det as $campo => [$a, $b]): ?>
              <?php if ($hh['acao'] === 'entregue' && in_array($campo, $novos, true)): ?>
              <li><?= e(CAMPOS_LABEL[$campo] ?? $campo) ?>: <?= e(valor_legivel($campo, $b)) ?></li>
              <?php else: ?>
              <li><?= e(CAMPOS_LABEL[$campo] ?? $campo) ?>: <s><?= e(valor_legivel($campo, $a)) ?></s> → <?= e(valor_legivel($campo, $b)) ?></li>
              <?php endif; ?>
            <?php endforeach; ?></ul>
          <?php endif; ?>
          <small><?= br_hora($hh['criado_em']) ?></small>
        </li>
      <?php endforeach; ?>
      </ol>
    </aside>
  </div>
<?php endif; ?>
<?php rodape();
