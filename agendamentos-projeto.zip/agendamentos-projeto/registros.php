<?php
require __DIR__ . '/inc/bootstrap.php';
require __DIR__ . '/inc/layout.php';
require __DIR__ . '/inc/filtros.php';
exigir_login();
site_fp(); // antes das consultas: a página aberta se atualiza sozinha quando isso muda

$f = filtros_registros($_GET, $EMP);
$porPag = (int)($CONFIG['por_pagina'] ?? 50);
$total = (int)q("SELECT COUNT(*) FROM agendamentos WHERE {$f['where']}", $f['params'])->fetchColumn();
$paginas = max(1, (int)ceil($total / $porPag));
$pag = min($paginas, max(1, (int)($_GET['p'] ?? 1)));
$ini = ($pag - 1) * $porPag;
$linhas = q("SELECT * FROM agendamentos WHERE {$f['where']} ORDER BY {$f['order']} LIMIT $porPag OFFSET $ini", $f['params'])->fetchAll();

$transps = q("SELECT DISTINCT transportadora FROM agendamentos WHERE transportadora <> '' ORDER BY transportadora")->fetchAll(PDO::FETCH_COLUMN);

$g = fn($k) => (string)($_GET[$k] ?? '');
$ativos = [];
if ($g('st') !== '' && isset(ST_FILTRO[$g('st')])) $ativos['st'] = ['Status', ST_FILTRO[$g('st')]];
if ($g('cat') !== '') $ativos['cat'] = ['Produto', $g('cat')];
if ($g('tr') !== '') $ativos['tr'] = ['Transportadora', titulo($g('tr'))];
if ($g('uf') !== '') $ativos['uf'] = ['UF', $g('uf')];
if ($g('de') !== '') $ativos['de'] = ['A partir de', br($g('de'))];
if ($g('ate') !== '') $ativos['ate'] = ['Até', br($g('ate'))];

$ordAtual = $g('ord') ?: 'rc';
$dirAtual = $g('dir') ?: 'desc';
function th_ord(string $k, string $label, string $atual, string $dir, string $extra = ''): string
{
    $novoDir = $atual === $k ? ($dir === 'asc' ? 'desc' : 'asc') : ($k === 'forn' ? 'asc' : 'desc');
    $seta = $atual === $k ? ' <span class="ar">' . ($dir === 'asc' ? '↑' : '↓') . '</span>' : '';
    return '<th' . $extra . '><a class="sort" href="' . e(url_com(['ord' => $k, 'dir' => $novoDir, 'p' => null])) . '">' . e($label) . $seta . '</a></th>';
}

topo('Registros', 'registros', true);
?>
<form class="toolbar" method="get" action="registros.php">
  <div class="search"><?= icone('busca') ?><input name="q" type="search" value="<?= e($g('q')) ?>" placeholder="Buscar fornecedor, nota fiscal, transportadora ou observação" autocomplete="off"></div>
  <?php foreach (['st', 'cat', 'tr', 'uf', 'de', 'ate', 'ord', 'dir'] as $k) if ($g($k) !== '') echo '<input type="hidden" name="' . $k . '" value="' . e($g($k)) . '">'; ?>
  <button class="btn" type="submit">Buscar</button>
  <a class="btn" href="exportar.php?<?= e(http_build_query(array_diff_key($_GET, ['p' => 1]))) ?>"><?= icone('baixar', 15) ?>Exportar CSV</a>
</form>

<details class="filters-box">
  <summary class="btn"><?= icone('filtro', 15) ?>Filtros <?php if ($ativos): ?><span class="badge"><?= count($ativos) ?></span><?php endif; ?></summary>
  <form class="filters" method="get" action="registros.php">
    <?php if ($g('q') !== '') echo '<input type="hidden" name="q" value="' . e($g('q')) . '">'; ?>
    <div class="field"><label for="fSt">Status</label><select id="fSt" name="st"><?php foreach (ST_FILTRO as $k => $v) echo '<option value="' . $k . '"' . ($g('st') === $k ? ' selected' : '') . '>' . e($v) . '</option>'; ?></select></div>
    <div class="field"><label for="fCat">Produto</label><select id="fCat" name="cat"><option value="">Todos</option><?php foreach (CATEGORIAS as $c) echo '<option' . ($g('cat') === $c ? ' selected' : '') . '>' . $c . '</option>'; ?></select></div>
    <div class="field"><label for="fTr">Transportadora</label><input id="fTr" name="tr" list="dlTr" value="<?= e($g('tr')) ?>" placeholder="Todas"></div>
    <div class="field"><label for="fUf">UF</label><select id="fUf" name="uf"><option value="">RJ e ES</option><option <?= $g('uf') === 'RJ' ? 'selected' : '' ?>>RJ</option><option <?= $g('uf') === 'ES' ? 'selected' : '' ?>>ES</option></select></div>
    <div class="field"><label for="fDe">Receber de</label><input id="fDe" name="de" type="date" value="<?= e($g('de')) ?>"></div>
    <div class="field"><label for="fAte">Receber até</label><input id="fAte" name="ate" type="date" value="<?= e($g('ate')) ?>"></div>
    <div class="field acts"><button class="btn primary" type="submit">Aplicar</button></div>
  </form>
</details>
<datalist id="dlTr"><?php foreach ($transps as $t) echo '<option value="' . e($t) . '">'; ?></datalist>

<?php if ($ativos): ?>
<div class="chipsrow">
  <?php foreach ($ativos as $k => [$l, $v]): ?>
    <a class="fchip" href="<?= e(url_com([$k => null, 'p' => null])) ?>" title="Remover filtro"><span><?= e($l) ?>:</span> <?= e($v) ?> ✕</a>
  <?php endforeach; ?>
  <?php if (count($ativos) > 1): ?><a class="btn ghost sm" href="<?= e(url_com(['st' => null, 'cat' => null, 'tr' => null, 'uf' => null, 'de' => null, 'ate' => null, 'p' => null])) ?>">Limpar tudo</a><?php endif; ?>
</div>
<?php endif; ?>

<div class="tablebox" id="reg-tabela" data-vivo><table class="cards reg">
  <thead><tr>
    <?= th_ord('rc', 'Receber', $ordAtual, $dirAtual) ?>
    <?= th_ord('forn', 'Fornecedor', $ordAtual, $dirAtual) ?>
    <th>Nota fiscal</th>
    <?= th_ord('vol', 'Volumes', $ordAtual, $dirAtual, ' class="r"') ?>
    <th>Empresa</th><th>Status</th><th>Observação</th>
  </tr></thead>
  <tbody>
  <?php foreach ($linhas as $r):
      $st = status_de($r);
      $obs = implode(' · ', array_filter([frase($r['observacao']), frase($r['obs_vianna'])])); ?>
    <tr class="click" data-href="agendamento.php?id=<?= (int)$r['id'] ?>">
      <td class="num"><?= br($r['data_receber']) ?></td>
      <td><div class="two"><a href="agendamento.php?id=<?= (int)$r['id'] ?>"><?= e(titulo($r['fornecedor']) ?: 'Fornecedor não informado') ?></a><small><?= e(implode(' · ', array_filter([titulo($r['transportadora']), frase($r['produto'])]))) ?></small></div></td>
      <td class="mono"><?= e($r['nota_fiscal'] ?: '—') ?></td>
      <td class="num r"><?= e($r['volumes'] ?: '—') ?></td>
      <td><span class="tag"><?= e(emp_nome($r['empresa'])) ?><?= $r['uf'] === 'ES' ? ' · ES' : '' ?></span></td>
      <td><span class="st s-<?= $st ?>"><?= ST_LABEL[$st] ?></span></td>
      <td class="obs" title="<?= e($obs) ?>"><?= e($obs) ?></td>
    </tr>
  <?php endforeach; ?>
  <?php if (!$linhas): ?>
    <tr><td colspan="7"><div class="empty"><b>Nada encontrado</b>Tente outra busca ou limpe os filtros.</div></td></tr>
  <?php endif; ?>
  </tbody>
</table></div>

<div class="foot" id="reg-pe" data-vivo>
  <span class="num"><?= $total ? 'Mostrando ' . n($ini + 1) . '–' . n(min($ini + $porPag, $total)) . ' de ' . plural($total, 'registro', 'registros') : '' ?></span>
  <?php if ($paginas > 1): ?>
  <nav class="pager" aria-label="Páginas">
    <?php if ($pag > 1): ?><a class="btn sm" href="<?= e(url_com(['p' => $pag - 1])) ?>">Anterior</a><?php endif; ?>
    <span class="num">Página <?= $pag ?> de <?= $paginas ?></span>
    <?php if ($pag < $paginas): ?><a class="btn sm" href="<?= e(url_com(['p' => $pag + 1])) ?>">Próxima</a><?php endif; ?>
  </nav>
  <?php endif; ?>
</div>
<?php rodape();
