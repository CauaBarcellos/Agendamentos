<?php
// Avisos no celular: o aparelho busca a chave pública, se inscreve, cancela ou pede um aviso de teste. Responde JSON.
require __DIR__ . '/inc/bootstrap.php';

header('Content-Type: application/json; charset=utf-8');
// Qualquer erro vira uma resposta JSON clara (e o motivo vai para o error_log), em vez de página em branco.
set_exception_handler(function (Throwable $e): void {
    error_log('push.php: ' . get_class($e) . ': ' . $e->getMessage() . ' em ' . basename($e->getFile()) . ':' . $e->getLine());
    http_response_code(500);
    echo json_encode(['ok' => false, 'msg' => 'Erro no servidor ao enviar o aviso (' . $e->getMessage() . '). O motivo ficou registrado no error_log.'], JSON_UNESCAPED_UNICODE);
});
$responder = function (int $status, array $dados): void {
    http_response_code($status);
    exit(json_encode($dados, JSON_UNESCAPED_UNICODE));
};
if (!usuario()) $responder(401, ['ok' => false, 'msg' => 'Sua sessão expirou. Entre de novo.']);
exigir_login();
$eu = (int)usuario()['id'];

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    [, $pub] = vapid_chaves();
    $n = (int)q('SELECT COUNT(*) FROM push_inscricoes WHERE usuario_id = ?', [$eu])->fetchColumn();
    $responder(200, ['ok' => true, 'chave' => $pub, 'aparelhos' => $n]);
}

if (!hash_equals($_SESSION['csrf'] ?? '', (string)($_POST['csrf'] ?? ''))) $responder(400, ['ok' => false, 'msg' => 'A página expirou. Atualize e tente de novo.']);
$acao = (string)($_POST['acao'] ?? '');
// O endereço do serviço de avisos vem SEM o "https://" (campo ep): o firewall da hospedagem (ModSecurity) bloqueia
// com erro 406 formulários que levam um endereço https. Todo serviço de push é https; o prefixo é recolocado aqui.
$ep = (string)($_POST['ep'] ?? '');
$endpoint = $ep !== '' ? 'https://' . preg_replace('#^[a-z]+://#i', '', $ep) : (string)($_POST['endpoint'] ?? '');

if ($acao === 'inscrever') {
    $p256 = (string)($_POST['p256dh'] ?? '');
    $auth = (string)($_POST['auth'] ?? '');
    if (!push_endpoint_ok($endpoint) || strlen($endpoint) > 700) $responder(400, ['ok' => false, 'msg' => 'Este navegador usa um serviço de avisos que o portal não reconhece.']);
    if (strlen(b64u_dec($p256)) !== 65 || strlen(b64u_dec($auth)) < 16) $responder(400, ['ok' => false, 'msg' => 'Inscrição inválida.']);
    $aparelho = mb_substr(preg_replace('/\s+/', ' ', (string)($_SERVER['HTTP_USER_AGENT'] ?? '')), 0, 120);
    // o mesmo aparelho pode ter sido de outra pessoa (celular compartilhado): passa a ser de quem ativou agora
    q('INSERT INTO push_inscricoes (usuario_id, endpoint, p256dh, auth, aparelho, criado_em) VALUES (?,?,?,?,?,?)
       ON DUPLICATE KEY UPDATE usuario_id = VALUES(usuario_id), p256dh = VALUES(p256dh), auth = VALUES(auth), aparelho = VALUES(aparelho), falhas = 0',
        [$eu, $endpoint, $p256, $auth, $aparelho, agora()]);
    $responder(200, ['ok' => true, 'msg' => 'Avisos ativados neste aparelho.']);
}

if ($acao === 'cancelar') {
    q('DELETE FROM push_inscricoes WHERE endpoint = ? AND usuario_id = ?', [$endpoint, $eu]);
    $responder(200, ['ok' => true, 'msg' => 'Avisos desativados neste aparelho.']);
}

if ($acao === 'teste') {
    // envia na hora (não depois da resposta) para dizer se deu certo
    $lista = q('SELECT * FROM push_inscricoes WHERE usuario_id = ?' . ($endpoint !== '' ? ' AND endpoint = ?' : ''), $endpoint !== '' ? [$eu, $endpoint] : [$eu])->fetchAll();
    if (!$lista) $responder(404, ['ok' => false, 'msg' => 'Este aparelho não está com os avisos ativados.']);
    $ok = 0;
    foreach ($lista as $insc) {
        $cod = push_enviar_um($insc, ['titulo' => 'Aviso de teste', 'corpo' => 'Se você está vendo isto, os avisos do portal estão funcionando ✓', 'url' => 'index.php', 'tag' => 'teste']);
        if ($cod >= 200 && $cod < 300) { $ok++; q('UPDATE push_inscricoes SET ultimo_envio = ?, falhas = 0 WHERE id = ?', [agora(), $insc['id']]); }
        elseif (in_array($cod, [404, 410], true)) q('DELETE FROM push_inscricoes WHERE id = ?', [$insc['id']]);
    }
    $responder($ok ? 200 : 502, $ok ? ['ok' => true, 'msg' => 'Aviso de teste enviado. Deve aparecer em alguns segundos.'] : ['ok' => false, 'msg' => 'O serviço de avisos não aceitou o envio. Desative e ative de novo neste aparelho.']);
}

$responder(400, ['ok' => false, 'msg' => 'Ação desconhecida.']);
