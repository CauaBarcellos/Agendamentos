<?php
// Dar entrada numa nota no RJ com conferência: volumes recebidos, se chegou tudo certo e, se não, o que houve (com fotos).
// Funciona como página (portaria) e como janela por cima da agenda (?modal=1, enviada pelo JavaScript e respondida em JSON).
require __DIR__ . '/inc/bootstrap.php';
require __DIR__ . '/inc/layout.php';

$ajax = ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'fetch';
$modal = isset($_GET['modal']) || isset($_POST['modal']);
// Resposta para a janela da agenda: JSON (envio) ou texto curto (erro ao abrir).
$falhar = function (string $msg, string $ir) use ($ajax): void {
    if ($ajax) {
        http_response_code(409);
        header('Content-Type: application/json; charset=utf-8');
        exit(json_encode(['ok' => false, 'msg' => $msg], JSON_UNESCAPED_UNICODE));
    }
    flash($msg, 'erro');
    redirecionar($ir);
};

if ($ajax && !usuario()) $falhar('Sua sessão expirou. Entre de novo.', 'login.php');
exigir_login();
if (!pode_editar()) $falhar('Seu perfil é só de consulta.', 'index.php');

$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$r = q('SELECT * FROM agendamentos WHERE id = ?', [$id])->fetch();
if (!$r) $falhar('Nota não encontrada.', 'entrada.php');
$volta = volta_segura($_GET['volta'] ?? $_POST['volta'] ?? '', 'agendamento.php?id=' . $id);
$forn = titulo($r['fornecedor']) ?: 'Fornecedor não informado';
$esperado = $r['volumes_num'] !== null ? (int)$r['volumes_num'] : null;
$erros = [];
$v = ['vol_recebidos' => $esperado, 'tudo_ok' => '', 'tipos' => [], 'obs' => ''];

if ($r['entregue'] === 'S') $falhar("$forn já teve entrada em " . br_hora($r['entregue_em']) . '.', 'agendamento.php?id=' . $id);
if ($r['uf'] === 'ES' && !$r['data_receber']) $falhar('Escolha primeiro o dia de receber esta nota do ES.', 'agendamento.php?id=' . $id);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($ajax && !hash_equals($_SESSION['csrf'] ?? '', (string)($_POST['csrf'] ?? ''))) $falhar('A página expirou. Atualize e tente de novo.', 'index.php');
    if (!$ajax) csrf_validar();
    [$c, $erros] = conferencia_validar($r, $_POST);
    $v = ['vol_recebidos' => $c['vol'], 'tudo_ok' => $c['tudo_ok'], 'tipos' => $c['tipos'], 'obs' => $c['obs_digitada']];
    if ($erros && $ajax) {
        http_response_code(422);
        header('Content-Type: application/json; charset=utf-8');
        exit(json_encode(['ok' => false, 'erros' => $erros], JSON_UNESCAPED_UNICODE));
    }
    if (!$erros) {
        $div = $c['div'];
        if (!receber_registrar($r, $c['vol'], $div, $c['obs'])) $falhar('Outra pessoa já deu entrada nesta nota.', 'agendamento.php?id=' . $id);
        [$nFotos, $probs] = fotos_salvar($id, imp_lista_arquivos($_FILES['fotos'] ?? null));
        $msg = $div ? "Entrada de $forn registrada com divergência (" . mb_strtolower(divergencia_txt($div)) . ').' : "Entrada de $forn registrada.";
        if ($nFotos) $msg .= $nFotos === 1 ? ' 1 foto salva.' : " $nFotos fotos salvas.";
        if ($probs) $msg .= ' Fotos não salvas: ' . implode(' ', $probs);
        if ($ajax) {
            header('Content-Type: application/json; charset=utf-8');
            exit(json_encode(['ok' => true, 'msg' => $msg, 'ids' => [$id]], JSON_UNESCAPED_UNICODE));
        }
        flash($msg, $probs ? 'erro' : 'ok');
        redirecionar($volta);
    }
}

$extra = array_filter([titulo($r['transportadora']), frase($r['produto']), emp_nome($r['empresa']), $r['uf'] === 'ES' ? 'vem do ES' : '']);
if (!$modal) {
    topo('Dar entrada', 'receber');
    echo '<a class="back" href="' . e($volta) . '">' . icone('voltar', 15) . ' Voltar</a>';
}
?>
<form class="<?= $modal ? 'rec-janela' : 'card formcard' ?> receber" method="post" action="receber.php" enctype="multipart/form-data" id="form-receber">
  <?= csrf_campo() ?><input type="hidden" name="id" value="<?= $id ?>"><input type="hidden" name="volta" value="<?= e($volta) ?>"><?php if ($modal): ?><input type="hidden" name="modal" value="1"><?php endif; ?>
  <div class="cardhead">
    <div class="eyebrow">Dar entrada · <?= $r['nota_fiscal'] ? 'NF ' . e($r['nota_fiscal']) : 'sem NF' ?></div>
    <h1><?= e($forn) ?></h1>
    <p class="muted" style="margin:0"><?= e(implode(' · ', $extra)) ?><?= $r['data_receber'] ? ' · previsto ' . br($r['data_receber']) : '' ?></p>
    <?php if ($modal): ?><button type="button" class="rec-x" data-fechar aria-label="Fechar">×</button><?php endif; ?>
  </div>
  <div class="flash erro" id="rec-erros" style="margin:0" <?= $erros ? '' : 'hidden' ?>><?= e(implode(' ', $erros)) ?></div>

  <div class="blk"><h5>Volumes</h5>
    <div class="rec-vol">
      <div><small>Esperado</small><b><?= $esperado !== null ? n($esperado) : e($r['volumes'] ?: '—') ?></b></div>
      <div class="field"><label for="vol_recebidos">Recebido</label><input id="vol_recebidos" name="vol_recebidos" inputmode="numeric" pattern="[0-9]*" autocomplete="off" value="<?= $v['vol_recebidos'] !== null && $v['vol_recebidos'] >= 0 ? (int)$v['vol_recebidos'] : '' ?>" data-esperado="<?= $esperado ?? '' ?>"></div>
    </div>
  </div>

  <div class="blk"><h5>Chegou tudo certo?</h5>
    <div class="rec-ok" role="radiogroup">
      <label class="rec-op sim"><input type="radio" name="tudo_ok" value="sim" required <?= $v['tudo_ok'] === 'sim' ? 'checked' : '' ?>><span><?= icone('check', 18) ?> Sim, tudo certo</span></label>
      <label class="rec-op nao"><input type="radio" name="tudo_ok" value="nao" <?= $v['tudo_ok'] === 'nao' ? 'checked' : '' ?>><span>! Não, teve problema</span></label>
    </div>
  </div>

  <div class="blk rec-div" id="rec-div" <?= $v['tudo_ok'] === 'nao' ? '' : 'hidden' ?>><h5>O que aconteceu?</h5>
    <div class="rec-tipos">
      <?php foreach (DIVERG as $k => $l): ?><label class="chip"><input type="checkbox" name="tipos[]" value="<?= $k ?>" <?= in_array($k, $v['tipos'], true) ? 'checked' : '' ?>><span><?= e($l) ?></span></label><?php endforeach; ?>
    </div>
    <div class="field" style="margin-top:12px"><label for="obs">Explique</label><textarea id="obs" name="obs" placeholder="Ex.: 2 caixas amassadas, faltou 1 volume de luva"><?= e($v['obs']) ?></textarea></div>
  </div>

  <div class="blk"><h5>Fotos <span class="muted">(opcional: avaria, canhoto assinado)</span></h5>
    <label class="rec-fotos-bt btn"><input type="file" name="fotos[]" id="rec-fotos" accept="image/*" capture="environment" multiple hidden> <?= icone('mais', 15) ?> Tirar ou escolher fotos</label>
    <div class="rec-prev" id="rec-prev"></div>
    <p class="muted small" style="margin:6px 0 0">Até <?= FOTO_MAX_POR_VEZ ?> fotos. Elas são reduzidas antes de enviar.</p>
  </div>

  <div class="cardfoot">
    <span class="sp"></span>
    <?php if ($modal): ?><button type="button" class="btn" data-fechar>Cancelar</button><?php else: ?><a class="btn" href="<?= e($volta) ?>">Cancelar</a><?php endif; ?>
    <button class="btn primary" type="submit"><?= icone('check', 15) ?> Confirmar entrada</button>
  </div>
</form>
<?php if (!$modal) rodape();
