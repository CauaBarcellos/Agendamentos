-- Portal de Agendamentos de Fornecedor — estrutura do banco (MySQL 5.7+ / MariaDB 10.3+)
-- O install.php executa este arquivo automaticamente. Use-o manualmente só se preferir criar pelo phpMyAdmin.

CREATE TABLE IF NOT EXISTS usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL,
  login VARCHAR(50) NOT NULL UNIQUE,
  senha_hash VARCHAR(255) NOT NULL,
  perfil ENUM('admin','operador','leitor','filial_es') NOT NULL DEFAULT 'operador',
  ativo TINYINT(1) NOT NULL DEFAULT 1,
  trocar_senha TINYINT(1) NOT NULL DEFAULT 0,
  criado_em DATETIME NOT NULL,
  ultimo_acesso DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS agendamentos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  data_agendamento DATE NULL,
  empresa VARCHAR(20) NOT NULL DEFAULT '',
  uf CHAR(2) NOT NULL DEFAULT 'RJ',
  filial VARCHAR(5) NULL,
  transportadora VARCHAR(120) NULL,
  fornecedor VARCHAR(150) NULL,
  produto VARCHAR(120) NULL,
  categoria VARCHAR(20) NULL,
  nota_fiscal VARCHAR(255) NULL,
  chave_nfe CHAR(44) NULL COMMENT 'chave de acesso da NF-e (importação por XML)',
  volumes VARCHAR(40) NULL,
  volumes_num INT NULL,
  data_receber DATE NULL,
  entregue CHAR(1) NOT NULL DEFAULT 'N' COMMENT 'N = aguardando, S = entregue, D = devolvida',
  entregue_em DATETIME NULL,
  vol_recebidos INT NULL COMMENT 'volumes conferidos na entrada',
  divergencia VARCHAR(60) NULL COMMENT 'tipos separados por vírgula: falta, avaria, sobra, errado, outro (NULL = chegou tudo certo)',
  divergencia_obs TEXT NULL,
  chegou_es_em DATE NULL COMMENT 'dia em que a nota chegou na filial do ES (avisado pela filial)',
  chegou_es_por INT NULL,
  observacao TEXT NULL,
  obs_vianna TEXT NULL,
  email_enviado VARCHAR(3) NULL,
  ref_interna VARCHAR(20) NULL,
  origem VARCHAR(10) NOT NULL DEFAULT 'portal' COMMENT 'planilha = Excel inicial, portal = digitado, xml = NF-e, csv = importação em lote, es = cadastrada pela filial do ES',
  linha_planilha INT NULL,
  criado_por INT NULL,
  criado_em DATETIME NULL,
  atualizado_por INT NULL,
  atualizado_em DATETIME NULL,
  KEY idx_receber (data_receber),
  KEY idx_entregue (entregue, data_receber),
  KEY idx_empresa (empresa),
  KEY idx_fornecedor (fornecedor),
  KEY idx_nf (nota_fiscal(40)),
  KEY idx_chave (chave_nfe),
  KEY idx_es (uf, chegou_es_em)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS recebidas_es (
  id INT AUTO_INCREMENT PRIMARY KEY,
  data_emissao DATE NULL,
  transportadora VARCHAR(120) NULL,
  fornecedor VARCHAR(150) NULL,
  material VARCHAR(120) NULL,
  nota_fiscal VARCHAR(150) NULL,
  volumes VARCHAR(40) NULL,
  status VARCHAR(20) NULL,
  data_recebido_rj DATE NULL,
  observacao VARCHAR(255) NULL,
  linha_planilha INT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS historico (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  agendamento_id INT NULL,
  usuario_id INT NULL,
  acao VARCHAR(20) NOT NULL COMMENT 'criou, editou, entregue, reabriu, excluiu',
  detalhes TEXT NULL COMMENT 'JSON com campo => [antes, depois]',
  criado_em DATETIME NOT NULL,
  KEY idx_ag (agendamento_id),
  KEY idx_data (criado_em)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS fotos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  agendamento_id INT NOT NULL,
  arquivo VARCHAR(80) NOT NULL COMMENT 'nome do arquivo em uploads/ (gerado pelo sistema)',
  tipo VARCHAR(20) NOT NULL DEFAULT 'image/jpeg',
  tamanho INT NOT NULL DEFAULT 0,
  criado_por INT NULL,
  criado_em DATETIME NOT NULL,
  KEY idx_ag (agendamento_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS ajustes (
  chave VARCHAR(50) PRIMARY KEY,
  valor TEXT NOT NULL COMMENT 'ajustes internos (ex.: chaves das notificações)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS push_inscricoes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT NOT NULL,
  endpoint VARCHAR(700) NOT NULL COMMENT 'endereço do serviço de push do aparelho',
  p256dh VARCHAR(120) NOT NULL,
  auth VARCHAR(60) NOT NULL,
  aparelho VARCHAR(120) NULL,
  criado_em DATETIME NOT NULL,
  ultimo_envio DATETIME NULL,
  falhas INT NOT NULL DEFAULT 0,
  UNIQUE KEY uq_endpoint (endpoint(255)),
  KEY idx_usuario (usuario_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
