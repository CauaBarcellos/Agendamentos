<?php
require __DIR__ . '/inc/bootstrap.php';
require __DIR__ . '/inc/filtros.php';
exigir_login();

$f = filtros_registros($_GET, $EMP);
$st = q("SELECT * FROM agendamentos WHERE {$f['where']} ORDER BY {$f['order']}", $f['params']);

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="agendamentos_' . date('Y-m-d') . '.csv"');
$out = fopen('php://output', 'w');
fwrite($out, "\xEF\xBB\xBF"); // BOM para o Excel abrir com acentos
fputcsv($out, ['Data p/ receber', 'Agendado em', 'Status', 'Empresa', 'UF', 'Filial', 'Fornecedor', 'Transportadora', 'Produto', 'Nota fiscal', 'Volumes', 'Observação', 'Obs. Vianna', 'E-mail enviado', 'Entrada em', 'Volumes recebidos', 'Divergência', 'Obs. da divergência'], ';');
$cel = fn($v) => (is_string($v) && preg_match('/^[=+\-@\t\r]/', $v)) ? "'" . $v : $v; // evita fórmulas no Excel
while ($r = $st->fetch()) {
    foreach (['fornecedor', 'transportadora', 'produto', 'nota_fiscal', 'volumes', 'observacao', 'obs_vianna', 'divergencia_obs'] as $k) $r[$k] = $cel($r[$k]);
    fputcsv($out, [br($r['data_receber']), br($r['data_agendamento']), ST_LABEL[status_de($r)], emp_nome($r['empresa']), $r['uf'], $r['filial'],
        $r['fornecedor'], $r['transportadora'], $r['produto'], $r['nota_fiscal'], $r['volumes'], $r['observacao'], $r['obs_vianna'], $r['email_enviado'],
        $r['entregue_em'] ? br_hora($r['entregue_em']) : '', $r['vol_recebidos'], divergencia_txt($r['divergencia']), $r['divergencia_obs']], ';');
}
fclose($out);
