<?php
// Importação de notas: XML de NF-e (um ou vários, ou um ZIP), planilha CSV ou texto colado do Excel.
// Fluxo: enviar → conferir a prévia (editável) → gravar.
require __DIR__ . '/inc/bootstrap.php';
require __DIR__ . '/inc/layout.php';
exigir_login();
exigir_edicao();

// Modelo de planilha para baixar.
if (isset($_GET['modelo'])) {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="modelo_importacao.csv"');
    echo "\xEF\xBB\xBF";
    echo "Fornecedor;Transportadora;NF;Volumes;Produto;Empresa;Data;Recebido\r\n";
    echo "TEUTO;TELECARGA;12345;12;MEDICAMENTO;GREEN MED;" . date('d/m/Y', strtotime('+1 day')) . ";\r\n";
    echo "DESCARPACK;BRASPRESS;98765;4;LUVA;ESTEVIA;" . date('d/m/Y', strtotime('-2 day')) . ";" . date('d/m/Y', strtotime('-1 day')) . "\r\n";
    exit;
}

$padrao = [
    'empresa' => $EMP !== '' ? $EMP : 'GREEN MED',
    'uf' => 'RJ',
    'data_receber' => soma_dias(hoje(), 1),
];
$erro = '';
$linhas = null;       // prévia
$problemas = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validar();
    $acao = (string)($_POST['acao'] ?? '');

    // ---------- 1) ler os arquivos e montar a prévia ----------
    if ($acao === 'ler') {
        $d = (string)($_POST['data_receber'] ?? '');
        if ($d !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $d)) $d = '';
        $padrao['data_receber'] = $d !== '' ? $d : null;
        $padrao['empresa'] = in_array($_POST['empresa'] ?? '', EMPRESAS, true) ? $_POST['empresa'] : $padrao['empresa'];
        $padrao['uf'] = in_array($_POST['uf'] ?? '', ['RJ', 'ES'], true) ? $_POST['uf'] : 'RJ';
        @set_time_limit(120);
        [$linhas, $problemas] = imp_coletar(imp_lista_arquivos($_FILES['arquivos'] ?? null), (string)($_POST['texto'] ?? ''), $padrao);
        foreach ($linhas as &$l) {
            $l['dup'] = imp_duplicada($l['chave_nfe'], $l['fornecedor'], $l['nota_fiscal']);
            // Nota com destino ES: quem registra é a filial do ES, quando ela chegar lá.
            $l['so_es'] = $l['uf'] === 'ES' && !e_admin();
            if ($l['so_es']) $l['aviso'][] = 'Destino ES: quem registra é a filial do ES quando a nota chegar lá.';
            // A planilha diz que já chegou e a nota do site ainda está aguardando: oferece dar entrada nela.
            $l['baixa'] = $l['dup'] && !empty($l['recebido']) && pode_receber($l['dup']);
            if ($l['dup'] && !empty($l['recebido']) && !$l['baixa']) {
                $l['aviso'][] = $l['dup']['entregue'] === 'N' ? 'Nota do ES sem dia escolhido: a entrada precisa ser pelo site.' : 'No site ela já está recebida.';
            }
        }
        unset($l);
        if (!$linhas) { $erro = 'Nenhuma nota encontrada para importar.'; $linhas = null; }
    }

    // ---------- 2) gravar o que foi conferido ----------
    if ($acao === 'gravar') {
        $dados = json_decode((string)($_POST['dados'] ?? ''), true);
        if (!is_array($dados) || !$dados) {
            flash('Não recebi as notas da prévia (o JavaScript precisa estar ativo). Tente de novo.', 'erro');
            redirecionar('importar.php');
        }
        $dados = array_slice($dados, 0, IMP_MAX_LINHAS);
        $uid = usuario()['id'];
        $ok = 0; $ign = 0; $inval = []; $baixas = 0;
        $porData = [];
        db()->beginTransaction();
        try {
            foreach ($dados as $i => $r) {
                // dia em que chegou, segundo a planilha (nunca no futuro); sem data, vale agora
                $recEm = (string)($r['recebido_em'] ?? '');
                $recEm = preg_match('/^\d{4}-\d{2}-\d{2}$/', $recEm) && checkdate((int)substr($recEm, 5, 2), (int)substr($recEm, 8, 2), (int)substr($recEm, 0, 4)) && $recEm <= hoje()
                    ? ($recEm === hoje() ? agora() : $recEm . ' 12:00:00') : agora();
                // Nota que já existe no site e a planilha diz que chegou: dá entrada nela (não cria outra).
                if (!empty($r['baixa']) && (int)($r['dup_id'] ?? 0) > 0) {
                    $alvo = q('SELECT * FROM agendamentos WHERE id = ?', [(int)$r['dup_id']])->fetch();
                    $rot = 'NF ' . ($alvo['nota_fiscal'] ?? '?') . ' (' . ($alvo['fornecedor'] ?? '?') . ')';
                    if (!$alvo || $alvo['entregue'] !== 'N') { $inval[] = "$rot já tinha entrada no site."; continue; }
                    if (!pode_receber($alvo)) { $inval[] = "$rot é do ES e ainda não tem dia escolhido."; continue; }
                    $st = q("UPDATE agendamentos SET entregue = 'S', entregue_em = ?, vol_recebidos = COALESCE(vol_recebidos, volumes_num), atualizado_por = ?, atualizado_em = ? WHERE id = ? AND entregue = 'N'",
                        [$recEm, $uid, agora(), $alvo['id']]);
                    if ($st->rowCount() === 1) {
                        registrar_historico((int)$alvo['id'], 'entregue', ['entregue' => ['N', 'S'], 'origem' => [null, 'entrada pela planilha importada']]);
                        $baixas++;
                    }
                    continue;
                }
                if (empty($r['inc'])) { $ign++; continue; }
                $forn = imp_cortar(maiusc((string)($r['fornecedor'] ?? '')), 150);
                $nf = imp_cortar((string)($r['nota_fiscal'] ?? ''), 60);
                if ($forn === '') { $inval[] = 'Linha ' . ($i + 1) . ': fornecedor em branco.'; continue; }
                $emp = (string)($r['empresa'] ?? '');
                if (!in_array($emp, EMPRESAS, true)) { $inval[] = "Linha " . ($i + 1) . " ($forn): empresa inválida."; continue; }
                $dt = (string)($r['data_receber'] ?? '');
                $dt = preg_match('/^\d{4}-\d{2}-\d{2}$/', $dt) && checkdate((int)substr($dt, 5, 2), (int)substr($dt, 8, 2), (int)substr($dt, 0, 4)) ? $dt : null;
                $chave = preg_replace('/\D/', '', (string)($r['chave_nfe'] ?? ''));
                $chave = strlen($chave) === 44 ? $chave : null;
                $prod = imp_cortar(maiusc((string)($r['produto'] ?? '')), 120) ?: 'DIVERSOS';
                $vol = substr(preg_replace('/\D/', '', (string)($r['volumes'] ?? '')), 0, 8);
                $origem = in_array($r['origem'] ?? '', ['xml', 'csv'], true) ? $r['origem'] : 'csv';
                $uf = in_array($r['uf'] ?? '', ['RJ', 'ES'], true) ? $r['uf'] : 'RJ';
                if ($uf === 'ES' && !e_admin()) { $inval[] = "NF $nf ($forn): destino ES, quem registra é a filial do ES."; continue; }
                // Alguém pode ter importado a mesma nota depois que a prévia foi montada: só grava se foi uma escolha consciente (linha marcada como duplicada na prévia).
                if (empty($r['dup']) && imp_duplicada((string)$chave, $forn, $nf)) { $inval[] = "NF $nf ($forn) já foi cadastrada por outra pessoa."; continue; }

                $jaChegou = !empty($r['recebido']); // a planilha diz que essa nota nova já foi recebida
                q('INSERT INTO agendamentos (data_agendamento, empresa, uf, filial, transportadora, fornecedor, produto, categoria, nota_fiscal, chave_nfe, volumes, volumes_num, data_receber, entregue, entregue_em, vol_recebidos, origem, criado_por, criado_em, atualizado_por, atualizado_em)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)', [
                    hoje(), $emp, $uf, FILIAL_EMP[$emp] ?? null, maiusc((string)($r['transportadora'] ?? '')) ?: null, $forn, $prod, categoria_de($prod),
                    $nf !== '' ? $nf : null, $chave, $vol !== '' ? $vol : null, $vol !== '' ? (int)$vol : null, $dt,
                    $jaChegou ? 'S' : 'N', $jaChegou ? $recEm : null, $jaChegou && $vol !== '' ? (int)$vol : null, $origem, $uid, agora(), $uid, agora(),
                ]);
                registrar_historico((int)db()->lastInsertId(), 'criou', ['origem' => [null, $origem === 'xml' ? 'importado de XML' : 'importado de planilha']]);
                $ok++;
                $k = $dt ?? 'semdata';
                $porData[$k] = ($porData[$k] ?? 0) + 1;
            }
            db()->commit();
        } catch (Throwable $e) {
            db()->rollBack();
            error_log('importar.php: ' . $e->getMessage());
            flash('Erro ao gravar; nada foi importado. Tente de novo.', 'erro');
            redirecionar('importar.php');
        }
        $msg = $ok === 1 ? '1 nota importada.' : "$ok notas importadas.";
        if ($baixas) $msg .= $baixas === 1 ? ' 1 nota já existente recebeu entrada pela planilha.' : " $baixas notas já existentes receberam entrada pela planilha.";
        if ($ign) $msg .= " $ign ignorada" . ($ign > 1 ? 's' : '') . '.';
        if ($inval) $msg .= ' Não importei: ' . implode(' ', array_slice($inval, 0, 5)) . (count($inval) > 5 ? ' …' : '');
        flash($msg, $ok || $baixas ? 'ok' : 'erro');
        if ($ok && $porData) {
            arsort($porData);
            $dia = array_key_first($porData);
            redirecionar($dia === 'semdata' ? 'index.php?dia=semdata' : 'index.php?dia=' . $dia);
        }
        redirecionar('importar.php');
    }
}

topo('Importar notas', 'importar');
?>
<a class="back" href="index.php"><?= icone('voltar', 15) ?> Voltar</a>

<?php if ($linhas === null): ?>
<form class="card formcard" method="post" enctype="multipart/form-data" action="importar.php" style="max-width:820px">
  <?= csrf_campo() ?><input type="hidden" name="acao" value="ler">
  <div class="cardhead">
    <div class="eyebrow">Várias notas de uma vez</div>
    <h1>Importar notas</h1>
    <p class="muted" style="margin:6px 0 0">Envie os XMLs das NF-e (um por nota, ou um ZIP com todos) ou uma planilha. Você confere tudo antes de gravar.</p>
  </div>
  <?php if ($erro): ?><div class="flash erro"><?= e($erro) ?></div><?php endif; ?>

  <div class="blk">
    <h5>1. Arquivos</h5>
    <label class="dz" id="dz">
      <input type="file" name="arquivos[]" id="arquivos" multiple accept=".xml,.zip,.csv,.xlsx,.txt,.tsv">
      <b>Arraste os arquivos aqui</b>
      <span>ou clique para escolher · XML da NF-e, ZIP com XMLs, planilha (.xlsx ou .csv)</span>
      <em id="dz-lista"></em>
    </label>
  </div>

  <div class="blk">
    <h5>ou cole da planilha</h5>
    <div class="field full"><textarea name="texto" rows="6" placeholder="Copie as linhas no Excel (com a linha de cabeçalho: Fornecedor, Transportadora, NF, Volumes, Produto, Empresa, Data) e cole aqui."></textarea></div>
    <p class="muted small" style="margin:8px 0 0"><a href="importar.php?modelo=1">Baixar modelo de planilha</a> · colunas aceitas: Fornecedor (obrigatória), Transportadora, NF, Volumes, Produto, Empresa, UF, Data e Recebido (data em que chegou, ou "sim"): se a nota já existe no portal e ainda está aguardando, a prévia oferece dar entrada nela.</p>
  </div>

  <div class="blk">
    <h5>2. Valores padrão</h5>
    <div class="form">
      <div class="field"><label for="data_receber">Data para receber</label><input id="data_receber" name="data_receber" type="date" value="<?= e($padrao['data_receber']) ?>"></div>
      <div class="field"><label for="empresa">Empresa (quando não der para identificar)</label><select id="empresa" name="empresa"><?php foreach (EMPRESAS as $em) echo '<option value="' . $em . '"' . ($padrao['empresa'] === $em ? ' selected' : '') . '>' . e(emp_nome($em)) . '</option>'; ?></select></div>
    </div>
    <input type="hidden" name="uf" value="RJ">
  </div>

  <div class="cardfoot"><span class="sp"></span><a class="btn" href="index.php">Cancelar</a><button class="btn primary" type="submit">Ler arquivos e mostrar prévia</button></div>
</form>

<?php else:
    $novas = count(array_filter($linhas, fn($l) => !$l['dup']));
    $dups = count($linhas) - $novas; ?>
<div class="card" style="margin-bottom:48px;gap:16px">
  <div class="cardhead">
    <div class="eyebrow">Confira antes de gravar</div>
    <h1><?= plural(count($linhas), 'nota encontrada', 'notas encontradas') ?></h1>
    <p class="muted" style="margin:6px 0 0"><?= n($novas) ?> nova<?= $novas === 1 ? '' : 's' ?><?= $dups ? ' · ' . n($dups) . ' já cadastrada' . ($dups === 1 ? '' : 's') . ' (desmarcada' . ($dups === 1 ? '' : 's') . ')' : '' ?>. Edite o que precisar; só as marcadas serão gravadas.</p>
  </div>

  <?php if ($problemas): ?>
  <div class="flash erro" style="margin:0"><b>Atenção:</b>
    <ul style="margin:6px 0 0;padding-left:18px"><?php foreach (array_slice($problemas, 0, 15) as $p) echo '<li>' . e($p) . '</li>'; ?><?php if (count($problemas) > 15) echo '<li>… e mais ' . (count($problemas) - 15) . '</li>'; ?></ul>
  </div>
  <?php endif; ?>

  <div class="imp-tools">
    <label class="checkline" style="flex:1 1 100%"><input type="checkbox" id="imp-marcar" checked> Marcar todas as novas</label>
    <span class="sp"></span>
    <div class="field imp-aplic" style="flex-direction:row;align-items:center;gap:6px"><label for="imp-data-todas" style="white-space:nowrap">Receber em</label><input id="imp-data-todas" type="date" style="width:auto" value="<?= e($padrao['data_receber']) ?>"><button class="btn sm" type="button" id="imp-aplicar-data">Aplicar a todas</button></div>
    <div class="field imp-aplic" style="flex-direction:row;align-items:center;gap:6px"><select id="imp-emp-todas" style="width:auto"><?php foreach (EMPRESAS as $em) echo '<option value="' . $em . '">' . e(emp_nome($em)) . '</option>'; ?></select><button class="btn sm" type="button" id="imp-aplicar-emp">Empresa p/ todas</button></div>
  </div>

  <form method="post" action="importar.php" id="form-importar">
    <?= csrf_campo() ?><input type="hidden" name="acao" value="gravar"><input type="hidden" name="dados" id="imp-dados" value="">
    <div class="tablebox"><table class="imp cards" style="min-width:1260px">
      <thead><tr><th></th><th>Situação</th><th>Fornecedor</th><th>NF</th><th>Vol.</th><th>Transportadora</th><th>Produto</th><th>Empresa</th><th>UF</th><th>Receber em</th></tr></thead>
      <tbody>
      <?php foreach ($linhas as $i => $l): $dup = $l['dup']; ?>
        <tr data-i="<?= $i ?>" class="<?= $dup || $l['so_es'] ? 'off' : '' ?>">
          <td><input type="checkbox" data-f="inc" aria-label="Importar esta nota" <?= $dup || $l['so_es'] ? '' : 'checked' ?><?= $l['so_es'] ? ' disabled data-so-es="1"' : '' ?>></td>
          <td class="imp-st">
            <?php if ($dup): ?><span class="st s-atrasado">Já cadastrada</span><br><a class="small" target="_blank" rel="noopener" href="agendamento.php?id=<?= (int)$dup['id'] ?>">ver nota</a>
            <?php if ($l['baixa']): ?><label class="imp-baixa"><input type="checkbox" data-f="baixa" checked> Dar entrada: <b><?= e(ST_LABEL[status_de($dup)]) ?></b> → <b>Recebida<?= $l['recebido']['data'] ? ' em ' . br($l['recebido']['data']) : '' ?></b> <small class="muted">(a planilha diz que chegou)</small></label><?php endif; ?>
            <?php else: ?><span class="st s-entregue">Nova</span><?php if (!empty($l['recebido'])): ?><br><small class="muted">já entra como recebida<?= $l['recebido']['data'] ? ' em ' . br($l['recebido']['data']) : '' ?></small><?php endif; ?><?php endif; ?>
            <?php if ($l['info']): ?><br><small class="muted"><?= e($l['info']) ?></small><?php endif; ?>
            <?php foreach ($l['aviso'] as $a): ?><br><small style="color:var(--today)"><?= e($a) ?></small><?php endforeach; ?>
            <input type="hidden" data-f="dup" value="<?= $dup ? '1' : '' ?>"><input type="hidden" data-f="dup_id" value="<?= $dup ? (int)$dup['id'] : '' ?>"><input type="hidden" data-f="recebido" value="<?= empty($l['recebido']) ? '' : '1' ?>"><input type="hidden" data-f="recebido_em" value="<?= e($l['recebido']['data'] ?? '') ?>"><input type="hidden" data-f="chave_nfe" value="<?= e($l['chave_nfe']) ?>"><input type="hidden" data-f="origem" value="<?= e($l['origem']) ?>">
          </td>
          <td><input data-f="fornecedor" value="<?= e($l['fornecedor']) ?>" aria-label="Fornecedor"></td>
          <td><input data-f="nota_fiscal" value="<?= e($l['nota_fiscal']) ?>" style="width:90px" aria-label="Nota fiscal"></td>
          <td><input data-f="volumes" value="<?= e($l['volumes']) ?>" style="width:56px" inputmode="numeric" aria-label="Volumes"></td>
          <td><input data-f="transportadora" value="<?= e($l['transportadora']) ?>" aria-label="Transportadora"></td>
          <td><input data-f="produto" value="<?= e($l['produto']) ?>" style="width:110px" aria-label="Produto"></td>
          <td><select data-f="empresa" aria-label="Empresa"><?php foreach (EMPRESAS as $em) echo '<option value="' . $em . '"' . ($l['empresa'] === $em ? ' selected' : '') . '>' . e(emp_nome($em)) . '</option>'; ?></select></td>
          <td><select data-f="uf" aria-label="UF"><?php foreach (['RJ', 'ES'] as $u) echo '<option' . ($l['uf'] === $u ? ' selected' : '') . '>' . $u . '</option>'; ?></select></td>
          <td><input data-f="data_receber" type="date" value="<?= e($l['data_receber']) ?>" aria-label="Data para receber"></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
    <div class="cardfoot" style="margin-top:16px"><span class="muted small" id="imp-contagem"></span><span class="sp"></span><a class="btn" href="importar.php">Recomeçar</a><button class="btn primary" type="submit" id="imp-gravar">Gravar notas marcadas</button></div>
  </form>
</div>
<?php endif; ?>
<?php rodape();
