<?php
// "Receber todas" de uma transportadora com conferência: cada nota com volumes recebidos e, se teve problema, o que houve e fotos.
// Abre como janela por cima da agenda (o JavaScript busca o formulário e envia em JSON).
require __DIR__ . '/inc/bootstrap.php';
require __DIR__ . '/inc/layout.php';

const GRUPO_MAX = 100;
$json = function (int $status, array $dados): void {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    exit(json_encode($dados, JSON_UNESCAPED_UNICODE));
};
if (!usuario()) $json(401, ['ok' => false, 'msg' => 'Sua sessão expirou. Entre de novo.']);
exigir_login();
if (!pode_editar()) $json(403, ['ok' => false, 'msg' => 'Seu perfil é só de consulta.']);

$ids = array_slice(array_values(array_unique(array_filter(array_map('intval', (array)($_GET['ids'] ?? $_POST['ids'] ?? []))))), 0, GRUPO_MAX);
if (!$ids) $json(400, ['ok' => false, 'msg' => 'Nenhuma nota selecionada.']);
$marcas = implode(',', array_fill(0, count($ids), '?'));
$notas = q("SELECT * FROM agendamentos WHERE id IN ($marcas) ORDER BY fornecedor IS NULL, fornecedor, id", $ids)->fetchAll();
$prontas = array_values(array_filter($notas, 'pode_receber'));
$fora = count($ids) - count($prontas);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($_SESSION['csrf'] ?? '', (string)($_POST['csrf'] ?? ''))) $json(400, ['ok' => false, 'msg' => 'A página expirou. Atualize e tente de novo.']);
    $itens = (array)($_POST['itens'] ?? []);
    $conf = [];
    $errosItens = [];
    foreach ($prontas as $r) {
        $in = (array)($itens[$r['id']] ?? []);
        $in['tudo_ok'] = !empty($in['problema']) ? 'nao' : 'sim';
        [$c, $err] = conferencia_validar($r, $in);
        if ($err) $errosItens[$r['id']] = implode(' ', $err);
        $conf[$r['id']] = $c;
    }
    // Tudo ou nada: se alguma nota tem erro, nada é gravado e a janela mostra onde corrigir.
    if ($errosItens) $json(422, ['ok' => false, 'erros_itens' => $errosItens, 'msg' => 'Confira as notas marcadas em vermelho.']);
    $feitas = [];
    $comDiv = 0;
    $fotosTot = 0;
    $probs = [];
    foreach ($prontas as $r) {
        $c = $conf[$r['id']];
        if (!receber_registrar($r, $c['vol'], $c['div'], $c['obs'])) continue; // outra pessoa deu entrada nesse meio-tempo
        $feitas[] = (int)$r['id'];
        if ($c['div']) $comDiv++;
        [$nf, $pr] = fotos_salvar((int)$r['id'], imp_lista_arquivos($_FILES['fotos_' . $r['id']] ?? null));
        $fotosTot += $nf;
        $probs = array_merge($probs, $pr);
    }
    $n = count($feitas);
    $msg = $n === 1 ? '1 nota recebida' : "$n notas recebidas";
    $msg .= $comDiv ? ($comDiv === 1 ? ', 1 com divergência.' : ", $comDiv com divergência.") : ', tudo certo.';
    if ($fotosTot) $msg .= $fotosTot === 1 ? ' 1 foto salva.' : " $fotosTot fotos salvas.";
    if ($n < count($prontas)) $msg .= ' ' . (count($prontas) - $n) . ' já tinham entrada por outra pessoa.';
    if ($probs) $msg .= ' Fotos não salvas: ' . implode(' ', $probs);
    $json(200, ['ok' => true, 'msg' => $msg, 'ids' => $feitas, 'n' => $n]);
}

if (!$prontas) $json(409, ['ok' => false, 'msg' => 'Essas notas já tiveram entrada (ou são do ES sem dia escolhido).']);
$transp = titulo($prontas[0]['transportadora']) ?: 'Transportadora não informada';
$totVol = array_sum(array_map(fn($r) => (int)$r['volumes_num'], $prontas));
?>
<form class="rec-janela receber rec-grupo" method="post" action="receber_grupo.php" enctype="multipart/form-data" id="form-receber-grupo">
  <?= csrf_campo() ?>
  <?php foreach ($prontas as $r): ?><input type="hidden" name="ids[]" value="<?= (int)$r['id'] ?>"><?php endforeach; ?>
  <div class="cardhead">
    <div class="eyebrow">Receber todas · <?= e($transp) ?></div>
    <h1><?= plural(count($prontas), 'nota', 'notas') ?><?= $totVol ? ' · ' . n($totVol) . ' volumes' : '' ?></h1>
    <p class="muted" style="margin:0">Confira os volumes. Se alguma nota chegou com problema, marque "Teve problema" nela.<?= $fora ? ' (' . $fora . ' já tinham entrada e ficaram de fora.)' : '' ?></p>
    <button type="button" class="rec-x" data-fechar aria-label="Fechar">×</button>
  </div>
  <div class="flash erro" id="rec-erros" style="margin:0" hidden></div>

  <div class="rg-lista">
  <?php foreach ($prontas as $r):
      $id = (int)$r['id'];
      $esp = $r['volumes_num'] !== null ? (int)$r['volumes_num'] : null;
      $sub = array_filter([$r['nota_fiscal'] ? 'NF ' . $r['nota_fiscal'] : 'sem NF', frase($r['produto']), $r['uf'] === 'ES' ? 'vem do ES' : '']); ?>
    <div class="rg-item" data-id="<?= $id ?>">
      <div class="rg-top">
        <div class="who"><b><?= e(titulo($r['fornecedor']) ?: 'Fornecedor não informado') ?></b><small><?= e(implode(' · ', $sub)) ?></small></div>
        <div class="rg-vol"><label for="vol-<?= $id ?>">Recebido <small>de <?= $esp !== null ? n($esp) : e($r['volumes'] ?: '—') ?></small></label>
          <input id="vol-<?= $id ?>" name="itens[<?= $id ?>][vol_recebidos]" inputmode="numeric" pattern="[0-9]*" autocomplete="off" value="<?= $esp ?? '' ?>" data-esperado="<?= $esp ?? '' ?>"></div>
        <label class="chip rg-prob"><input type="checkbox" name="itens[<?= $id ?>][problema]" value="1"><span>Teve problema</span></label>
      </div>
      <div class="rg-erro" hidden></div>
      <div class="rg-div rec-div" hidden>
        <div class="rec-tipos">
          <?php foreach (DIVERG as $k => $l): ?><label class="chip"><input type="checkbox" name="itens[<?= $id ?>][tipos][]" value="<?= $k ?>"><span><?= e($l) ?></span></label><?php endforeach; ?>
        </div>
        <div class="field" style="margin-top:10px"><label for="obs-<?= $id ?>">Explique</label><textarea id="obs-<?= $id ?>" name="itens[<?= $id ?>][obs]" rows="2" placeholder="Ex.: 1 caixa amassada"></textarea></div>
        <label class="rec-fotos-bt btn sm" style="margin-top:10px"><input type="file" name="fotos_<?= $id ?>[]" class="rg-fotos" accept="image/*" capture="environment" multiple hidden> <?= icone('mais', 14) ?> Fotos</label>
        <div class="rec-prev"></div>
      </div>
    </div>
  <?php endforeach; ?>
  </div>

  <div class="cardfoot">
    <span class="sp"></span>
    <button type="button" class="btn" data-fechar>Cancelar</button>
    <button class="btn primary" type="submit"><?= icone('check', 15) ?> Confirmar <?= plural(count($prontas), 'nota', 'notas') ?></button>
  </div>
</form>
